--
-- PostgreSQL database dump
--

\restrict emc4E2QxdUg7PJSMyNpFR6h0T6hfav7zNQEuRjDRCiN4NCkHpAQ378f0xYnKsOa

-- Dumped from database version 16.11
-- Dumped by pg_dump version 16.11

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: AccountLayer; Type: TYPE; Schema: public; Owner: user
--

CREATE TYPE public."AccountLayer" AS ENUM (
    'CORE',
    'EXTENSION',
    'INDUSTRY'
);


ALTER TYPE public."AccountLayer" OWNER TO "user";

--
-- Name: AccountType; Type: TYPE; Schema: public; Owner: user
--

CREATE TYPE public."AccountType" AS ENUM (
    'ASSET',
    'CONTRA_ASSET',
    'LIABILITY',
    'CONTRA_LIABILITY',
    'ACTIVE_PASSIVE',
    'TRANSIT',
    'OFF_BALANCE'
);


ALTER TYPE public."AccountType" OWNER TO "user";

--
-- Name: CharterCapitalFundingType; Type: TYPE; Schema: public; Owner: user
--

CREATE TYPE public."CharterCapitalFundingType" AS ENUM (
    'FULLY_PAID_CASH',
    'PARTIALLY_PAID',
    'PAID_IN_KIND',
    'NOT_PAID'
);


ALTER TYPE public."CharterCapitalFundingType" OWNER TO "user";

--
-- Name: DocumentStatus; Type: TYPE; Schema: public; Owner: user
--

CREATE TYPE public."DocumentStatus" AS ENUM (
    'POSTED',
    'VOIDED'
);


ALTER TYPE public."DocumentStatus" OWNER TO "user";

--
-- Name: Frequency; Type: TYPE; Schema: public; Owner: user
--

CREATE TYPE public."Frequency" AS ENUM (
    'MONTHLY',
    'QUARTERLY',
    'ANNUALLY'
);


ALTER TYPE public."Frequency" OWNER TO "user";

--
-- Name: OpenItemStatus; Type: TYPE; Schema: public; Owner: user
--

CREATE TYPE public."OpenItemStatus" AS ENUM (
    'OPEN',
    'CLOSED',
    'RISK'
);


ALTER TYPE public."OpenItemStatus" OWNER TO "user";

--
-- Name: OrgRole; Type: TYPE; Schema: public; Owner: user
--

CREATE TYPE public."OrgRole" AS ENUM (
    'OWNER',
    'ACCOUNTANT',
    'ADMIN'
);


ALTER TYPE public."OrgRole" OWNER TO "user";

--
-- Name: PeriodMode; Type: TYPE; Schema: public; Owner: user
--

CREATE TYPE public."PeriodMode" AS ENUM (
    'HISTORICAL',
    'ACTIVE'
);


ALTER TYPE public."PeriodMode" OWNER TO "user";

--
-- Name: PeriodStatus; Type: TYPE; Schema: public; Owner: user
--

CREATE TYPE public."PeriodStatus" AS ENUM (
    'OPEN',
    'CLOSED'
);


ALTER TYPE public."PeriodStatus" OWNER TO "user";

--
-- Name: PlanType; Type: TYPE; Schema: public; Owner: user
--

CREATE TYPE public."PlanType" AS ENUM (
    'FREE',
    'PRO'
);


ALTER TYPE public."PlanType" OWNER TO "user";

--
-- Name: RuleMatchType; Type: TYPE; Schema: public; Owner: user
--

CREATE TYPE public."RuleMatchType" AS ENUM (
    'INN',
    'KEYWORD',
    'AMOUNT_RANGE',
    'TREASURY_ACCOUNT'
);


ALTER TYPE public."RuleMatchType" OWNER TO "user";

--
-- Name: RuleSource; Type: TYPE; Schema: public; Owner: user
--

CREATE TYPE public."RuleSource" AS ENUM (
    'USER_ANSWER',
    'MANUAL',
    'AI_SUGGESTED'
);


ALTER TYPE public."RuleSource" OWNER TO "user";

--
-- Name: StagedTransactionStatus; Type: TYPE; Schema: public; Owner: user
--

CREATE TYPE public."StagedTransactionStatus" AS ENUM (
    'IMPORTED',
    'AUTO_MATCHED',
    'NEEDS_CLARIFICATION',
    'CONFIRMED',
    'POSTED',
    'SKIPPED'
);


ALTER TYPE public."StagedTransactionStatus" OWNER TO "user";

--
-- Name: TaxEventStatus; Type: TYPE; Schema: public; Owner: user
--

CREATE TYPE public."TaxEventStatus" AS ENUM (
    'PENDING',
    'DONE'
);


ALTER TYPE public."TaxEventStatus" OWNER TO "user";

--
-- Name: TaxEventType; Type: TYPE; Schema: public; Owner: user
--

CREATE TYPE public."TaxEventType" AS ENUM (
    'VAT',
    'PERSONAL_INCOME_TAX',
    'TURNOVER_TAX',
    'PROFIT_TAX',
    'STATISTICS',
    'SOCIAL_TAX',
    'INPS'
);


ALTER TYPE public."TaxEventType" OWNER TO "user";

--
-- Name: TaxRegime; Type: TYPE; Schema: public; Owner: user
--

CREATE TYPE public."TaxRegime" AS ENUM (
    'VAT',
    'TURNOVER_TAX'
);


ALTER TYPE public."TaxRegime" OWNER TO "user";

--
-- Name: TransactionDirection; Type: TYPE; Schema: public; Owner: user
--

CREATE TYPE public."TransactionDirection" AS ENUM (
    'CREDIT',
    'DEBIT'
);


ALTER TYPE public."TransactionDirection" OWNER TO "user";

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: Account; Type: TABLE; Schema: public; Owner: user
--

CREATE TABLE public."Account" (
    id text NOT NULL,
    code text NOT NULL,
    name text NOT NULL,
    type public."AccountType" NOT NULL,
    "parentId" text,
    "isSystem" boolean DEFAULT true NOT NULL,
    "group" text,
    "isDeprecated" boolean DEFAULT false NOT NULL,
    layer public."AccountLayer" DEFAULT 'CORE'::public."AccountLayer" NOT NULL
);


ALTER TABLE public."Account" OWNER TO "user";

--
-- Name: AuditLog; Type: TABLE; Schema: public; Owner: user
--

CREATE TABLE public."AuditLog" (
    id text NOT NULL,
    "orgId" text NOT NULL,
    "userId" text NOT NULL,
    action text NOT NULL,
    "entityType" text,
    "entityId" text,
    "oldValue" jsonb,
    "newValue" jsonb,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."AuditLog" OWNER TO "user";

--
-- Name: BankAccount; Type: TABLE; Schema: public; Owner: user
--

CREATE TABLE public."BankAccount" (
    id text NOT NULL,
    "orgId" text NOT NULL,
    name text NOT NULL,
    currency text DEFAULT 'UZS'::text NOT NULL,
    "bankName" text,
    "accountNumber" text,
    "lastBalance" numeric(20,2) DEFAULT 0 NOT NULL,
    "lastSyncedAt" timestamp(3) without time zone
);


ALTER TABLE public."BankAccount" OWNER TO "user";

--
-- Name: ClassificationJob; Type: TABLE; Schema: public; Owner: user
--

CREATE TABLE public."ClassificationJob" (
    id text NOT NULL,
    "orgId" text NOT NULL,
    status text DEFAULT 'running'::text NOT NULL,
    matched integer DEFAULT 0 NOT NULL,
    "needsClarification" integer DEFAULT 0 NOT NULL,
    error text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    processed integer DEFAULT 0 NOT NULL,
    total integer DEFAULT 0 NOT NULL
);


ALTER TABLE public."ClassificationJob" OWNER TO "user";

--
-- Name: ClosingJob; Type: TABLE; Schema: public; Owner: user
--

CREATE TABLE public."ClosingJob" (
    id text NOT NULL,
    "periodId" text NOT NULL,
    "orgId" text NOT NULL,
    status text DEFAULT 'DRAFT'::text NOT NULL,
    step integer DEFAULT 1 NOT NULL,
    data jsonb DEFAULT '{}'::jsonb NOT NULL,
    error text,
    "startedAt" timestamp(3) without time zone,
    "completedAt" timestamp(3) without time zone,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."ClosingJob" OWNER TO "user";

--
-- Name: Counterparty; Type: TABLE; Schema: public; Owner: user
--

CREATE TABLE public."Counterparty" (
    id text NOT NULL,
    "orgId" text NOT NULL,
    name text NOT NULL,
    inn text
);


ALTER TABLE public."Counterparty" OWNER TO "user";

--
-- Name: Document; Type: TABLE; Schema: public; Owner: user
--

CREATE TABLE public."Document" (
    id text NOT NULL,
    "orgId" text NOT NULL,
    "periodId" text NOT NULL,
    "typeId" text NOT NULL,
    date timestamp(3) without time zone NOT NULL,
    status public."DocumentStatus" DEFAULT 'POSTED'::public."DocumentStatus" NOT NULL,
    payload jsonb NOT NULL,
    "sourceTransactionId" text,
    "correctionForPeriodId" text,
    "taxCalendarSyncError" text,
    "taxCalendarSyncStatus" text
);


ALTER TABLE public."Document" OWNER TO "user";

--
-- Name: DocumentType; Type: TABLE; Schema: public; Owner: user
--

CREATE TABLE public."DocumentType" (
    id text NOT NULL,
    code text NOT NULL,
    name text NOT NULL,
    "postingTemplate" jsonb NOT NULL,
    mode text DEFAULT 'BANK_AUTO'::text NOT NULL
);


ALTER TABLE public."DocumentType" OWNER TO "user";

--
-- Name: JournalEntry; Type: TABLE; Schema: public; Owner: user
--

CREATE TABLE public."JournalEntry" (
    id text NOT NULL,
    "documentId" text NOT NULL,
    "accountId" text NOT NULL,
    debit numeric(20,2) NOT NULL,
    credit numeric(20,2) NOT NULL,
    date timestamp(3) without time zone NOT NULL,
    "counterpartyId" text,
    "contractId" text
);


ALTER TABLE public."JournalEntry" OWNER TO "user";

--
-- Name: OpenItem; Type: TABLE; Schema: public; Owner: user
--

CREATE TABLE public."OpenItem" (
    id text NOT NULL,
    "orgId" text NOT NULL,
    "accountId" text NOT NULL,
    "counterpartyId" text,
    "openingDocumentId" text NOT NULL,
    amount numeric(20,2) NOT NULL,
    "dateOpened" timestamp(3) without time zone NOT NULL,
    status public."OpenItemStatus" DEFAULT 'OPEN'::public."OpenItemStatus" NOT NULL,
    "riskDeadline" timestamp(3) without time zone,
    "closingDocumentId" text,
    "dateClosed" timestamp(3) without time zone,
    "affectedPeriodId" text,
    "awaitingInvoiceSign" boolean DEFAULT false NOT NULL
);


ALTER TABLE public."OpenItem" OWNER TO "user";

--
-- Name: OrgMember; Type: TABLE; Schema: public; Owner: user
--

CREATE TABLE public."OrgMember" (
    id text NOT NULL,
    role public."OrgRole" DEFAULT 'OWNER'::public."OrgRole" NOT NULL,
    "userId" text NOT NULL,
    "orgId" text NOT NULL
);


ALTER TABLE public."OrgMember" OWNER TO "user";

--
-- Name: Organization; Type: TABLE; Schema: public; Owner: user
--

CREATE TABLE public."Organization" (
    id text NOT NULL,
    name text NOT NULL,
    inn text,
    "taxRegime" public."TaxRegime" DEFAULT 'TURNOVER_TAX'::public."TaxRegime" NOT NULL,
    "isVatPayer" boolean DEFAULT false NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "activityDescription" text,
    "aiConfidenceThreshold" integer DEFAULT 70 NOT NULL,
    "maxClarificationQuestions" integer DEFAULT 10 NOT NULL,
    settings jsonb,
    "activityCustom" text,
    "activityGroup" text,
    "turnoverTaxRate" double precision DEFAULT 0.04 NOT NULL,
    "charterCapitalAmount" numeric(18,2),
    "charterCapitalDeclaredAt" timestamp(3) without time zone,
    "charterCapitalFundingType" public."CharterCapitalFundingType",
    "autoAccrueProfitTax" boolean DEFAULT true NOT NULL,
    "profitTaxRate" double precision DEFAULT 0.15 NOT NULL
);


ALTER TABLE public."Organization" OWNER TO "user";

--
-- Name: PasswordResetToken; Type: TABLE; Schema: public; Owner: user
--

CREATE TABLE public."PasswordResetToken" (
    id text NOT NULL,
    "userId" text NOT NULL,
    token text NOT NULL,
    "expiresAt" timestamp(3) without time zone NOT NULL,
    "usedAt" timestamp(3) without time zone,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."PasswordResetToken" OWNER TO "user";

--
-- Name: Payment; Type: TABLE; Schema: public; Owner: user
--

CREATE TABLE public."Payment" (
    id text NOT NULL,
    "orgId" text NOT NULL,
    provider text NOT NULL,
    "externalId" text NOT NULL,
    amount numeric(20,2) NOT NULL,
    currency text DEFAULT 'UZS'::text NOT NULL,
    status text DEFAULT 'PENDING'::text NOT NULL,
    "daysGranted" integer DEFAULT 365 NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "completedAt" timestamp(3) without time zone,
    "cancelReason" text,
    "cancelTime" timestamp(3) without time zone,
    "orderCode" text
);


ALTER TABLE public."Payment" OWNER TO "user";

--
-- Name: Period; Type: TABLE; Schema: public; Owner: user
--

CREATE TABLE public."Period" (
    id text NOT NULL,
    "orgId" text NOT NULL,
    year integer NOT NULL,
    month integer NOT NULL,
    mode public."PeriodMode" DEFAULT 'ACTIVE'::public."PeriodMode" NOT NULL,
    status public."PeriodStatus" DEFAULT 'OPEN'::public."PeriodStatus" NOT NULL,
    "lockDate" timestamp(3) without time zone,
    "closingData" jsonb
);


ALTER TABLE public."Period" OWNER TO "user";

--
-- Name: Rule; Type: TABLE; Schema: public; Owner: user
--

CREATE TABLE public."Rule" (
    id text NOT NULL,
    "orgId" text NOT NULL,
    "matchType" public."RuleMatchType" NOT NULL,
    "matchValue" text NOT NULL,
    "categoryId" text NOT NULL,
    "createdFrom" public."RuleSource" DEFAULT 'USER_ANSWER'::public."RuleSource" NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "order" integer DEFAULT 0 NOT NULL,
    direction text
);


ALTER TABLE public."Rule" OWNER TO "user";

--
-- Name: StagedTransaction; Type: TABLE; Schema: public; Owner: user
--

CREATE TABLE public."StagedTransaction" (
    id text NOT NULL,
    "orgId" text NOT NULL,
    "bankAccountId" text NOT NULL,
    "periodId" text NOT NULL,
    date timestamp(3) without time zone NOT NULL,
    amount numeric(20,2) NOT NULL,
    direction public."TransactionDirection" NOT NULL,
    description text NOT NULL,
    "counterpartyHint" text,
    "counterpartyInn" text,
    hash text NOT NULL,
    status public."StagedTransactionStatus" DEFAULT 'IMPORTED'::public."StagedTransactionStatus" NOT NULL,
    "aiSuggestion" jsonb,
    "documentId" text,
    "importBatchId" text,
    "createdAt" timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public."StagedTransaction" OWNER TO "user";

--
-- Name: Subscription; Type: TABLE; Schema: public; Owner: user
--

CREATE TABLE public."Subscription" (
    id text NOT NULL,
    "orgId" text NOT NULL,
    plan public."PlanType" DEFAULT 'FREE'::public."PlanType" NOT NULL,
    "validUntil" timestamp(3) without time zone,
    "customApiKey" text,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."Subscription" OWNER TO "user";

--
-- Name: TaxCalendarEvent; Type: TABLE; Schema: public; Owner: user
--

CREATE TABLE public."TaxCalendarEvent" (
    id text NOT NULL,
    "orgId" text NOT NULL,
    "periodId" text,
    type public."TaxEventType" NOT NULL,
    "dueDate" timestamp(3) without time zone NOT NULL,
    status public."TaxEventStatus" DEFAULT 'PENDING'::public."TaxEventStatus" NOT NULL,
    "estimatedAmount" numeric(20,2),
    note text
);


ALTER TABLE public."TaxCalendarEvent" OWNER TO "user";

--
-- Name: TaxDeadlineTemplate; Type: TABLE; Schema: public; Owner: user
--

CREATE TABLE public."TaxDeadlineTemplate" (
    id text NOT NULL,
    "orgId" text NOT NULL,
    type public."TaxEventType" NOT NULL,
    "dayOfMonth" integer NOT NULL,
    frequency public."Frequency" NOT NULL,
    "taxRegime" public."TaxRegime",
    "isActive" boolean DEFAULT true NOT NULL
);


ALTER TABLE public."TaxDeadlineTemplate" OWNER TO "user";

--
-- Name: User; Type: TABLE; Schema: public; Owner: user
--

CREATE TABLE public."User" (
    id text NOT NULL,
    email text NOT NULL,
    "passwordHash" text NOT NULL,
    name text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "activeOrgId" text
);


ALTER TABLE public."User" OWNER TO "user";

--
-- Name: Voucher; Type: TABLE; Schema: public; Owner: user
--

CREATE TABLE public."Voucher" (
    id text NOT NULL,
    code text NOT NULL,
    "daysGranted" integer NOT NULL,
    "usedByOrgId" text,
    "usedAt" timestamp(3) without time zone,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."Voucher" OWNER TO "user";

--
-- Data for Name: Account; Type: TABLE DATA; Schema: public; Owner: user
--

COPY public."Account" (id, code, name, type, "parentId", "isSystem", "group", "isDeprecated", layer) FROM stdin;
2eddc60e-2ebb-488e-9129-f2216301aff6	0170	Рабочий и продуктивный скот	ASSET	\N	t	Основные средства	f	INDUSTRY
a01dc215-847e-4ae7-9665-6e598d6d0cf6	6820	Краткосрочные займы	LIABILITY	\N	t	Краткосрочные обязательства	f	EXTENSION
b495f94a-d10a-4d28-ae9b-bb0fd701b350	0180	Многолетние насаждения	ASSET	\N	t	Основные средства	f	INDUSTRY
7e2bf813-d7ce-4aca-9008-13ca0fbdbd91	9010	Доходы от реализации готовой продукции	TRANSIT	\N	t	Доходы от осн. деятельности	f	INDUSTRY
10acb533-72b4-46dc-8b19-38c57f6f2fe3	4310	Авансы поставщикам под ТМЦ	ASSET	\N	t	Дебиторская задолженность	f	CORE
371c416e-d27d-45b7-ab24-51bdb59956fe	9020	Доходы от реализации товаров	TRANSIT	\N	t	Доходы от осн. деятельности	f	EXTENSION
c8a54d6a-0839-4054-8593-dc91f818372e	4710	Задолженность персонала по товарам в кредит	ASSET	\N	t	Дебиторская задолженность	f	EXTENSION
45722605-7c6a-4a49-8397-3924028e0583	9110	Себестоимость реализованной готовой продукции	TRANSIT	\N	t	Себестоимость	f	INDUSTRY
7e4a1524-5dff-45a8-85f4-469c9ca5c037	0190	Прочие основные средства	ASSET	\N	t	Основные средства	f	EXTENSION
3e48e334-f497-4f44-9922-73655cbc3209	5110	Расчётный счёт	ASSET	\N	t	Денежные средства	f	CORE
8472ccb2-224c-4f14-ba9c-5dc3feeee509	5210	Валютные счета внутри страны	ASSET	\N	t	Денежные средства	f	EXTENSION
50200182-e49a-4e8a-b0b5-bb780b5bc650	0199	Законсервированные основные средства	ASSET	\N	t	Основные средства	f	EXTENSION
356a8e76-279b-47d3-8004-ba7a73cf90d4	0200	Износ основных средств	CONTRA_ASSET	\N	t	Износ ОС	f	CORE
69358c02-20df-4da7-ba57-3564120994f6	5710	Денежные средства (переводы) в пути	ASSET	\N	t	Денежные средства	f	CORE
87abeaf9-1b92-4153-9d3c-7de887f629a0	9120	Себестоимость реализованных товаров	TRANSIT	\N	t	Себестоимость	f	EXTENSION
9ef38108-e7d4-4119-9f24-9c65d501967d	9420	Административные расходы	TRANSIT	\N	t	Расходы периода	f	CORE
fd21d842-d122-4e90-bb30-e5b2e0fdc600	9430	Прочие операционные расходы	TRANSIT	\N	t	Расходы периода	f	CORE
0969eb54-d0bf-4878-93bd-902309441cb3	0110	Земля	ASSET	\N	t	Основные средства	f	EXTENSION
52e0dd06-8e0b-48ac-a710-e049082f7504	0112	Благоустройство ОС по финансовой аренде	ASSET	\N	t	Основные средства	f	EXTENSION
8a7b7484-d542-4891-b653-a9a664b86e65	6010	Счета к оплате поставщикам и подрядчикам	ACTIVE_PASSIVE	\N	t	Краткосрочные обязательства	f	CORE
428dd7b6-00a6-4638-bee3-2c2c78e29b71	0130	Машины и оборудование	ASSET	\N	t	Основные средства	f	EXTENSION
01e56ad3-84f4-4e74-8f93-4d495a92111a	0140	Мебель и офисное оборудование	ASSET	\N	t	Основные средства	f	CORE
1b147c81-fd32-4a55-870f-b8074ae86548	0150	Компьютерное оборудование и вычислительная техника	ASSET	\N	t	Основные средства	f	CORE
b8bf88e0-1952-418b-9287-1bfc6328c58b	0211	Износ благоустройства земли	CONTRA_ASSET	\N	t	Износ ОС	f	EXTENSION
755703df-3cff-4393-9377-20f62eea498f	0410	Патенты, лицензии и ноу-хау	ASSET	\N	t	Нематериальные активы	f	EXTENSION
1ccafda8-fe88-478c-8f18-14338ff19684	0530	Амортизация программного обеспечения	CONTRA_ASSET	\N	t	Амортизация НМА	f	CORE
1f64b4e5-72ea-4403-bfe9-91fc7083ad80	6410	Задолженность по платежам в бюджетную систему	LIABILITY	\N	t	Краткосрочные обязательства	f	CORE
d0a48222-f2f9-4926-8e0b-98f69f302152	1610	Отклонения в стоимости материалов	ASSET	\N	t	Производственные запасы	f	INDUSTRY
e2b61343-45fb-43da-9974-d800b5fcbb93	6710	Расчёты с персоналом по оплате труда	LIABILITY	\N	t	Краткосрочные обязательства	f	CORE
7dee97f8-ef28-489b-8b18-e9ff0a1b9ba3	9910	Конечный финансовый результат (прибыль или убыток)	TRANSIT	\N	t	Финансовый результат	f	CORE
146b3c49-d48b-47b6-9e96-2a72523430b0	1020	Покупные полуфабрикаты и комплектующие изделия	ASSET	\N	t	Производственные запасы	f	INDUSTRY
8178fb9c-0a1d-4877-beea-905959796528	0540	Амортизация прав пользования землей	CONTRA_ASSET	\N	t	Амортизация НМА	f	EXTENSION
29ff0298-d82c-4083-8711-a3bf1a055703	1030	Топливо	ASSET	\N	t	Производственные запасы	f	INDUSTRY
064761ef-1673-499f-84c4-451abb9ee352	1040	Запасные части	ASSET	\N	t	Производственные запасы	f	INDUSTRY
2eb599e1-d0a6-4945-927f-c5c74f41f531	0550	Амортизация организационных расходов	CONTRA_ASSET	\N	t	Амортизация НМА	t	EXTENSION
63bbd50f-04a2-4d7d-b2e7-c0794686a871	0560	Амортизация франчайзинга	CONTRA_ASSET	\N	t	Амортизация НМА	f	INDUSTRY
144e32e4-6747-4448-8fe1-f45e5d3d8d3e	0570	Амортизация авторских прав	CONTRA_ASSET	\N	t	Амортизация НМА	f	INDUSTRY
e1dbb891-3ae3-4603-b6e4-069de23bc49c	0830	Приобретение нематериальных активов	ASSET	\N	t	Капитальные вложения	f	EXTENSION
a5faaca5-c354-487a-a4ef-e0bf90c696c4	0840	Формирование основного стада	ASSET	\N	t	Капитальные вложения	f	INDUSTRY
38cc415d-1ab8-48c3-b801-38323d41d6de	0860	Капитальные вложения в ОС по финансовой аренде	ASSET	\N	t	Капитальные вложения	f	EXTENSION
69041e5a-d8af-4e55-b70f-2746754e13f1	0890	Прочие капитальные вложения	ASSET	\N	t	Капитальные вложения	f	EXTENSION
e4059e92-254b-4522-853c-1ac7a8c3aab6	0910	Векселя полученные (долгосрочные)	ASSET	\N	t	Долгосрочная дебиторка	f	EXTENSION
520aeec4-d12d-4729-b445-5fcab53a1919	0930	Долгосрочная задолженность персонала	ASSET	\N	t	Долгосрочная дебиторка	f	EXTENSION
43987664-e011-45c9-aedc-730d580daab4	0940	Прочая долгосрочная дебиторская задолженность	ASSET	\N	t	Долгосрочная дебиторка	f	EXTENSION
84160902-bbe7-4106-94ed-69f5d64e3e23	0950	Отсроченный налог на прибыль (долгосрочный)	ASSET	\N	t	Долгосрочная дебиторка	f	EXTENSION
50af7d6b-e202-4737-9bef-d2db1f0f1417	0990	Прочие долгосрочные отсроченные расходы	ASSET	\N	t	Долгосрочная дебиторка	f	EXTENSION
67d27951-bb4c-43bc-9d6b-1fb3563fe5d9	1010	Сырьё и материалы	ASSET	\N	t	Производственные запасы	f	INDUSTRY
c8d22690-5049-4c4b-bb73-0f0bc88bcd58	0100	Основные средства (сводный счёт)	ASSET	\N	t	Основные средства	f	CORE
89627790-c1cb-4caf-abfe-52b30f359ad5	0440	Права пользования землей и природными ресурсами	ASSET	\N	t	Нематериальные активы	f	EXTENSION
1245b827-2416-4de9-bac7-bc840f9ae926	0460	Франчайзинг	ASSET	\N	t	Нематериальные активы	f	INDUSTRY
0a4dd4d9-7306-490a-b335-b29bd735845a	0480	Гудвилл	ASSET	\N	t	Нематериальные активы	f	EXTENSION
0db60a0d-c066-435c-acab-2948634bc331	0490	Прочие нематериальные активы	ASSET	\N	t	Нематериальные активы	f	EXTENSION
c02b9cec-af7b-4229-9dd8-91161c34368a	0510	Амортизация патентов, лицензий и ноу-хау	CONTRA_ASSET	\N	t	Амортизация НМА	f	EXTENSION
07ab6a9e-5efd-47cc-aa37-fea21581f4c7	0520	Амортизация торговых марок и пром. образцов	CONTRA_ASSET	\N	t	Амортизация НМА	f	EXTENSION
1ea1fdbb-ed96-4c3b-b019-512682855343	4020	Векселя полученные (текущие)	ASSET	\N	t	Дебиторская задолженность	f	EXTENSION
ab232e94-529e-422b-8590-adeddd18bbac	2910	Товары на складах	ASSET	\N	t	Производство и ТМЗ	f	EXTENSION
dd618ddd-946d-4746-b1df-69727131d909	2610	Брак в производстве	ASSET	\N	t	Производство и ТМЗ	f	INDUSTRY
8fb8b74e-1f7d-49c9-b259-e7944e3e1575	2820	Готовая продукция на выставке	ASSET	\N	t	Производство и ТМЗ	f	INDUSTRY
ed3bccb4-eedc-44f1-a124-8f3db828a84c	2010	Основное производство	ASSET	\N	t	Производство и ТМЗ	f	INDUSTRY
a8d039c2-e57d-40f0-9eff-a0572546e891	2940	Предметы проката	ASSET	\N	t	Производство и ТМЗ	f	INDUSTRY
acf16063-e564-4005-9e7c-c50175122b1f	2830	Готовая продукция, переданная на комиссию	ASSET	\N	t	Производство и ТМЗ	f	INDUSTRY
b25ef153-f5ce-4b54-a7ed-ef63aa20545c	2710	Обслуживающие хозяйства	ASSET	\N	t	Производство и ТМЗ	f	INDUSTRY
7ac875dd-1a7a-4d49-b57a-3426726defdc	4230	Авансы, выданные на общехозяйственные расходы	ASSET	\N	t	Дебиторская задолженность	f	CORE
d64a149d-2392-44c5-9aae-f10dca32f55e	2950	Тара под товаром и порожняя	ASSET	\N	t	Производство и ТМЗ	f	INDUSTRY
247891d7-174a-4526-a453-9dafab9f853e	2110	Полуфабрикаты собственного производства	ASSET	\N	t	Производство и ТМЗ	f	INDUSTRY
1eb6116a-1936-474a-853c-47549c883357	1090	Прочие материалы	ASSET	\N	t	Производственные запасы	f	EXTENSION
35ec3a42-1734-4a77-bd0f-e7c94b01e289	3120	Предоплаченные услуги	ASSET	\N	t	Предоплаты и РБП	f	CORE
7ee7c2c3-00eb-4376-9f46-94fee5d1f778	4210	Авансы, выданные по оплате труда	ASSET	\N	t	Дебиторская задолженность	f	CORE
fc798568-08fd-43e5-8433-80a47cee005f	1060	Тара и тарные материалы	ASSET	\N	t	Производственные запасы	f	INDUSTRY
8e3d4465-3d99-49a0-9d84-8c676751f11e	2980	Торговая наценка	CONTRA_ASSET	\N	t	Производство и ТМЗ	f	INDUSTRY
5b8887b3-fb5b-4805-bcfe-df0be94b62a9	2310	Вспомогательное производство	ASSET	\N	t	Производство и ТМЗ	f	INDUSTRY
0a174744-9374-45b0-95d3-f06a51c9f40f	4320	Авансы поставщикам под долгосрочные активы	ASSET	\N	t	Дебиторская задолженность	f	EXTENSION
5a194379-dddc-4725-b094-2f068afea99e	4290	Прочие авансы, выданные персоналу	ASSET	\N	t	Дебиторская задолженность	f	EXTENSION
431dedee-b940-4ff5-8fcd-62244a81710d	2510	Общепроизводственные расходы	ASSET	\N	t	Производство и ТМЗ	f	INDUSTRY
e249e53a-effd-4d9b-999b-838ea67d83a6	2990	Прочие товары	ASSET	\N	t	Производство и ТМЗ	f	EXTENSION
f1a71331-5f8b-4956-bbfc-3c5b0794ac05	3110	Предоплаченная оперативная аренда	ASSET	\N	t	Предоплаты и РБП	f	CORE
aa8833a2-53bb-4453-8afa-b003955353f0	1080	Инвентарь и хозяйственные принадлежности	ASSET	\N	t	Производственные запасы	f	EXTENSION
f70c188c-0223-46e4-9333-52aa71136665	4120	Счета к получению от дочерних и зависимых обществ	ASSET	\N	t	Дебиторская задолженность	f	EXTENSION
56f15747-c824-458f-8784-cc95490978fd	1110	Животные на выращивании	ASSET	\N	t	Производственные запасы	f	INDUSTRY
b845ea45-4fe1-45d5-ae1b-6f0d988507ff	3190	Прочие расходы будущих периодов	ASSET	\N	t	Предоплаты и РБП	f	CORE
3e610560-9d1b-4578-b68e-871272bab345	0310	ОС, полученные по договору финансовой аренды	ASSET	\N	t	ОС по аренде	f	EXTENSION
cc2af637-7479-4cc1-b611-65c63e42d5d5	3220	Отсроченные расходы по дисконтам	ASSET	\N	t	Предоплаты и РБП	f	EXTENSION
9c095e06-a9c2-49b7-a7e1-2c949fcf8728	4220	Авансы, выданные на служебные командировки	ASSET	\N	t	Дебиторская задолженность	f	CORE
d312a73e-90ef-4897-9980-4556f39340a0	3290	Прочие отсроченные расходы	ASSET	\N	t	Предоплаты и РБП	f	EXTENSION
5d5c938d-6285-4357-9850-395aa5d9906d	4010	Счета к получению от покупателей и заказчиков	ASSET	\N	t	Дебиторская задолженность	f	CORE
a85da37d-c867-409d-afd0-4d19471dfdfa	1510	Заготовление и приобретение материалов	ASSET	\N	t	Производственные запасы	f	INDUSTRY
850524ab-6eeb-4328-b132-b4f96b5b46b8	2810	Готовая продукция на складе	ASSET	\N	t	Производство и ТМЗ	f	INDUSTRY
b28e5e60-9d11-436c-b874-d5b2da09adfe	2920	Товары в розничной торговле	ASSET	\N	t	Производство и ТМЗ	f	INDUSTRY
73473499-767e-4a12-ae92-5e4f009a2c8f	2930	Товары на выставке	ASSET	\N	t	Производство и ТМЗ	f	INDUSTRY
ad226aaa-503a-439a-a545-dff14e06ac7d	2960	Товары, переданные на комиссию	ASSET	\N	t	Производство и ТМЗ	f	INDUSTRY
94481816-e974-439d-b341-cbb3455aaeb3	6240	Отсроченные обязательства по налогам и сборам	LIABILITY	\N	t	Краткосрочные обязательства	f	EXTENSION
f3142d4f-df08-4b06-81a8-f940ba44b59d	6210	Отсроченные доходы в виде дисконта (скидки)	LIABILITY	\N	t	Краткосрочные обязательства	f	EXTENSION
b5e04f0a-451b-4c6b-9592-2d56611c2fa8	0260	Износ транспортных средств	CONTRA_ASSET	\N	t	Износ ОС	f	EXTENSION
fabed48f-3530-4704-9983-5f09a2bbb891	4730	Задолженность персонала по возмещению ущерба	ASSET	\N	t	Дебиторская задолженность	f	EXTENSION
b39b10a2-4fae-4709-a17e-73e95834ed36	0270	Износ рабочего скота	CONTRA_ASSET	\N	t	Износ ОС	f	INDUSTRY
fa6ea877-5e4a-4444-b5bb-c46eea3294d2	4720	Задолженность персонала по предоставленным займам	ASSET	\N	t	Дебиторская задолженность	f	EXTENSION
97e7ffa3-76bb-4076-be33-11441bf8f06b	4790	Прочая задолженность персонала	ASSET	\N	t	Дебиторская задолженность	f	EXTENSION
8755cae1-0ff5-4a33-be6c-4e246ac19e2b	4810	Платежи к получению по финансовой аренде (тек.)	ASSET	\N	t	Дебиторская задолженность	f	EXTENSION
c82545fe-8bec-488c-904d-b068a4fd5644	4820	Платежи к получению по оперативной аренде	ASSET	\N	t	Дебиторская задолженность	f	EXTENSION
addb9a33-bcec-4cbb-9d50-214b8d6d48e0	6290	Прочие отсроченные обязательства	LIABILITY	\N	t	Краткосрочные обязательства	f	EXTENSION
eb197584-ae22-48da-b174-b20e66aa595f	6310	Авансы, полученные от покупателей и заказчиков	LIABILITY	\N	t	Краткосрочные обязательства	f	CORE
8b8817eb-da38-4689-be7f-ecb810a43e19	5020	Касса (иностранная валюта)	ASSET	\N	t	Денежные средства	f	EXTENSION
dd93ef43-3a06-4abf-beb0-b522c45f4ae4	0212	Износ благоустройства ОС по финансовой аренде	CONTRA_ASSET	\N	t	Износ ОС	f	EXTENSION
5951439e-f3d7-426b-ab4b-739ed86e501b	6250	Обязательства по отсроченному налогу на прибыль	LIABILITY	\N	t	Краткосрочные обязательства	f	EXTENSION
c06960b0-a7a8-4255-b626-16282ddd5c15	5510	Аккредитивы	ASSET	\N	t	Денежные средства	f	EXTENSION
649a0c44-1565-42b7-819b-0f7d1afbc6c8	4830	Проценты к получению	ASSET	\N	t	Дебиторская задолженность	f	EXTENSION
681093ee-199a-49a7-8aff-49f679e60c83	5610	Денежные эквиваленты (по видам)	ASSET	\N	t	Денежные средства	f	EXTENSION
bc086343-2f7c-400c-8b6f-99b93203af55	5520	Чековые книжки	ASSET	\N	t	Денежные средства	f	EXTENSION
b65824a3-d9f5-488f-80d9-db5a10b88b8c	6020	Векселя выданные (краткосрочные)	LIABILITY	\N	t	Краткосрочные обязательства	f	EXTENSION
e58f992e-b3e2-4e14-be8d-68032578c276	0250	Износ компьютерного оборудования	CONTRA_ASSET	\N	t	Износ ОС	f	CORE
af4ea739-4850-4246-b70e-5979310e7be9	5830	Краткосрочные займы выданные	ASSET	\N	t	Денежные средства	f	EXTENSION
809587b7-9b62-47a4-9450-27fae60acdcd	0220	Износ зданий, сооружений и передаточных устройств	CONTRA_ASSET	\N	t	Износ ОС	f	EXTENSION
f344de94-ed5f-4beb-a696-a354a77e7420	5220	Валютные счета за рубежом	ASSET	\N	t	Денежные средства	f	EXTENSION
3d12ef64-d6c9-4648-bdad-5f02a01b773a	5810	Ценные бумаги (краткосрочные)	ASSET	\N	t	Денежные средства	f	EXTENSION
d4c91fda-45de-4c62-928c-8025f856ed94	6530	Задолженность по ИНПС (накопительная пенсия)	LIABILITY	\N	t	Краткосрочные обязательства	f	CORE
c29d41c6-c160-46e1-ada8-95890df5f085	4840	Дивиденды к получению	ASSET	\N	t	Дебиторская задолженность	f	EXTENSION
45f97951-ba83-4a17-a86b-4bf193395420	5890	Прочие текущие инвестиции	ASSET	\N	t	Денежные средства	f	EXTENSION
8521ecd5-3f2c-4dd8-baed-9c9889288878	0230	Износ машин и оборудования	CONTRA_ASSET	\N	t	Износ ОС	f	EXTENSION
138d30cb-6311-4b3a-b65f-dcc6ee5afad7	0240	Износ мебели и офисного оборудования	CONTRA_ASSET	\N	t	Износ ОС	f	CORE
dc1cb76d-da63-4682-bc36-ea7a023c0929	4850	Роялти к получению	ASSET	\N	t	Дебиторская задолженность	f	EXTENSION
ec156254-bc25-4b4c-83b0-7437caf4721e	5920	Прочие текущие активы	ASSET	\N	t	Денежные средства	f	EXTENSION
b1d9b95a-e139-44e2-bb59-28abbff9b1e1	4860	Счета к получению по претензиям	ASSET	\N	t	Дебиторская задолженность	f	EXTENSION
7295850d-efdd-46ab-bba0-50379da90c85	4890	Задолженность прочих дебиторов	ASSET	\N	t	Дебиторская задолженность	f	EXTENSION
c0e5ab3a-b6e2-4ad7-9856-5ec82cb95f71	6120	Счета к оплате дочерним и зависимым обществам	LIABILITY	\N	t	Краткосрочные обязательства	f	EXTENSION
beff5b02-f865-4c28-bf88-5e14edaa209d	4910	Резерв по сомнительным долгам	CONTRA_ASSET	\N	t	Дебиторская задолженность	f	EXTENSION
c3148941-1b87-44df-abbc-c4401399541f	5910	Недостачи и потери от порчи ценностей	ASSET	\N	t	Денежные средства	f	EXTENSION
899a4870-da07-483e-a520-cebac2eb8608	5530	Прочие специальные счета	ASSET	\N	t	Денежные средства	f	EXTENSION
6c402bb5-72cc-4f7e-a177-79b960ffbf49	6230	Прочие отсроченные доходы	LIABILITY	\N	t	Краткосрочные обязательства	f	EXTENSION
e9c83c45-8199-48fa-924a-acf9d8a97276	6610	Дивиденды к оплате	LIABILITY	\N	t	Краткосрочные обязательства	f	EXTENSION
662b1315-8141-428f-a193-1c3929789125	6830	Облигации к оплате (краткосрочные)	LIABILITY	\N	t	Краткосрочные обязательства	f	EXTENSION
763efa54-1753-4839-ba97-d646ab462e7f	6720	Депонированная заработная плата	LIABILITY	\N	t	Краткосрочные обязательства	f	EXTENSION
38ce0eb0-be13-4d5c-9706-2780143921d2	8310	Простые акции	LIABILITY	\N	t	Капитал	f	EXTENSION
4556faeb-719f-4a5c-8efe-e3bf31789c8c	6810	Краткосрочные банковские кредиты	LIABILITY	\N	t	Краткосрочные обязательства	f	EXTENSION
8303502a-c033-4c50-8e26-1db3bf53cea4	6930	Задолженность по роялти	LIABILITY	\N	t	Краткосрочные обязательства	f	EXTENSION
03e4e93e-80ad-49d9-9d3f-36f41671ff87	7910	Финансовая аренда к оплате	LIABILITY	\N	t	Долгосрочные обязательства	f	EXTENSION
837d883d-e229-406d-942f-233b04065635	0610	Ценные бумаги (долгосрочные)	ASSET	\N	t	Долгосрочные инвестиции	f	EXTENSION
5ac623f0-27ab-422d-8f9d-17a302c26f9b	6940	Задолженность по гарантиям	LIABILITY	\N	t	Краткосрочные обязательства	f	EXTENSION
83a0f349-6f73-429c-827c-7f756911f2bf	6950	Долгосрочные обязательства — текущая часть	LIABILITY	\N	t	Краткосрочные обязательства	f	EXTENSION
35b50c2c-4fe9-4638-b718-8a95d35bc6e3	6960	Счета к оплате по претензиям	LIABILITY	\N	t	Краткосрочные обязательства	f	EXTENSION
52661df5-af23-4b41-9f35-1141aa36a66b	6970	Задолженность подотчётным лицам	LIABILITY	\N	t	Краткосрочные обязательства	f	CORE
d07854de-85d6-4afd-bd9a-d10085203eed	8330	Паи и вклады	LIABILITY	\N	t	Капитал	f	CORE
5d16787f-9b88-4a9b-9562-25785e478d93	7810	Долгосрочные банковские кредиты	LIABILITY	\N	t	Долгосрочные обязательства	f	EXTENSION
649527a7-347e-4508-9baa-c02ddc33a548	6990	Прочие обязательства	LIABILITY	\N	t	Краткосрочные обязательства	f	CORE
f15f4681-d876-4c7a-9c8a-3374e4e6095b	7020	Долгосрочные векселя выданные	LIABILITY	\N	t	Долгосрочные обязательства	f	EXTENSION
8c747b9e-c232-4d51-b8fc-fa6ae2f0e9a9	7230	Прочие долгосрочные отсроченные доходы	LIABILITY	\N	t	Долгосрочные обязательства	f	EXTENSION
cb996dc8-943f-446a-8a20-331b1115ac2a	0630	Инвестиции в зависимые общества	ASSET	\N	t	Долгосрочные инвестиции	f	EXTENSION
63deffe2-c06f-42b8-8032-fd29d1f3fda6	0640	Инвестиции в предприятия с иностранным капиталом	ASSET	\N	t	Долгосрочные инвестиции	f	EXTENSION
00d75ef9-b03f-4d8a-8067-5ed3feb30067	7120	Долгосрочная задолженность дочерним обществам	LIABILITY	\N	t	Долгосрочные обязательства	f	EXTENSION
df8ee067-10bd-40c6-b4e8-f7454f1249fe	7250	Долгосрочные обязательства по отсроченному налогу	LIABILITY	\N	t	Долгосрочные обязательства	f	EXTENSION
3a98cca9-bcd2-4004-ac49-16632c4eb31f	7210	Долгосрочные отсроченные доходы (дисконт)	LIABILITY	\N	t	Долгосрочные обязательства	f	EXTENSION
9dd02d1f-6b07-4b80-bad0-a7299fcefa33	7240	Долгосрочные отсроченные обязательства по налогам	LIABILITY	\N	t	Долгосрочные обязательства	f	EXTENSION
8b4ca5ea-e545-4529-8182-469ec9cd7cbc	7310	Авансы от покупателей — долгосрочная часть	LIABILITY	\N	t	Долгосрочные обязательства	f	EXTENSION
a7c3264c-5a24-4c23-8b2b-340dfea0418e	0690	Прочие долгосрочные инвестиции	ASSET	\N	t	Долгосрочные инвестиции	f	EXTENSION
3a5405ed-46b2-4bb3-b67a-b41f56a3a115	6220	Отсроченные доходы в виде премии (надбавки)	LIABILITY	\N	t	Краткосрочные обязательства	f	EXTENSION
05edbb3a-f0d7-4788-af0b-512490fb9cfe	6110	Счета к оплате обособленным подразделениям	LIABILITY	\N	t	Краткосрочные обязательства	f	EXTENSION
aeaaad4b-dd56-464d-9758-06fc97f6d453	6520	Платежи в государственные целевые фонды	LIABILITY	\N	t	Краткосрочные обязательства	f	CORE
7ec63614-36c4-4bf5-b5e1-a5613c96261a	8410	Эмиссионный доход	LIABILITY	\N	t	Капитал	f	EXTENSION
7ee2cd21-4fac-432a-b373-54f459660545	7840	Долгосрочные векселя к оплате	LIABILITY	\N	t	Долгосрочные обязательства	f	EXTENSION
9a909727-1d8b-4c6b-bb05-cdd806231319	7920	Прочие долгосрочные задолженности кредиторам	LIABILITY	\N	t	Долгосрочные обязательства	f	EXTENSION
23764e12-2897-4c73-98b6-14857d2d37ae	8320	Привилегированные акции	LIABILITY	\N	t	Капитал	f	EXTENSION
5fcf8323-35bc-45df-8c6f-d60cfdf77bc2	0620	Инвестиции в дочерние общества	ASSET	\N	t	Долгосрочные инвестиции	f	EXTENSION
b94d33b4-46dc-4003-a4b2-a888e8c7bfad	6630	Вклады учредителей по увеличению уставного капитала	LIABILITY	\N	t	Краткосрочные обязательства	f	EXTENSION
1a8b03be-9a6f-4c92-a684-837e2762ac5b	9390	Прочие операционные доходы	TRANSIT	\N	t	Прочие операц. доходы	f	CORE
2a55f983-26f0-4990-9fb9-c3bb9144eab1	9590	Прочие доходы от финансовой деятельности	TRANSIT	\N	t	Финансовые доходы	f	EXTENSION
1aafb488-fae0-4444-954e-a8527da23768	7220	Долгосрочные отсроченные доходы (премия)	LIABILITY	\N	t	Долгосрочные обязательства	f	EXTENSION
71161a98-0691-4682-9e82-7f9ad773e6fe	9620	Убытки от валютных курсовых разниц	TRANSIT	\N	t	Финансовые расходы	f	EXTENSION
886e1598-a216-4ca0-9c2b-823e4ba704f1	7820	Долгосрочные займы	LIABILITY	\N	t	Долгосрочные обязательства	f	EXTENSION
a7994c01-0a39-4c7e-94c5-07fe4516bb90	8520	Резервный капитал (фонд)	LIABILITY	\N	t	Капитал	f	EXTENSION
9376fb87-ae27-41f7-af3d-678686dcdeb8	1120	Животные на откорме	ASSET	\N	t	Производственные запасы	f	INDUSTRY
846fe6aa-0418-4c2a-9da1-a55662b34482	9220	Выбытие прочих активов	TRANSIT	\N	t	Выбытие активов	f	EXTENSION
8de77f38-7f70-45db-8713-f7656533dc13	9630	Расходы по выпуску и распространению ценных бумаг	TRANSIT	\N	t	Финансовые расходы	f	EXTENSION
19ab6591-b3bc-4b1c-bca4-ddaf1c212ae2	8610	Выкупленные собственные акции — простые	CONTRA_LIABILITY	\N	t	Капитал	f	EXTENSION
408e8dcf-69aa-4c03-bee3-5965d38d3fb8	8720	Накопленная прибыль (непокрытый убыток)	LIABILITY	\N	t	Капитал	f	CORE
74294248-ecbc-4298-80e3-494e5cebeb65	9410	Расходы по реализации	TRANSIT	\N	t	Расходы периода	f	EXTENSION
02fe70a3-a14c-4b6a-a91a-e735c4996374	9540	Доходы от валютных курсовых разниц	TRANSIT	\N	t	Финансовые доходы	f	EXTENSION
2575501b-12ff-47d2-9fbc-e27982f3214f	9350	Доходы от оперативной аренды	TRANSIT	\N	t	Прочие операц. доходы	f	EXTENSION
c20d5f94-b72e-4e45-b5a2-d8595f6348e0	9690	Прочие расходы по финансовой деятельности	TRANSIT	\N	t	Финансовые расходы	f	EXTENSION
802a91f4-e991-40a3-b18c-7c6fb9ed7224	8810	Гранты	LIABILITY	\N	t	Капитал	f	EXTENSION
82204145-ddb1-4ed9-a923-ba77818c0910	8820	Субсидии	LIABILITY	\N	t	Капитал	f	EXTENSION
9871d684-3455-4247-ace0-3084cbe43e7f	9520	Доходы в виде дивидендов	TRANSIT	\N	t	Финансовые доходы	f	EXTENSION
1a96254b-ae8d-4db1-a612-6a32d08d8a0b	9360	Доходы от списания кредиторской задолженности	TRANSIT	\N	t	Прочие операц. доходы	f	EXTENSION
319e306f-f554-4f09-8893-1d041d29cec9	9330	Взысканные пени, штрафы, неустойки	TRANSIT	\N	t	Прочие операц. доходы	f	EXTENSION
fe73cb62-d7dd-473b-8ba1-0095828579c7	8830	Членские взносы	LIABILITY	\N	t	Капитал	f	EXTENSION
3cc60a29-5835-4c63-84c7-0cbfa3c45f9f	9150	Корректировки по ТМЗ при периодическом учёте	TRANSIT	\N	t	Себестоимость	f	INDUSTRY
c3ed2cbd-59c3-456a-a876-c8090634b6a5	9370	Доходы обслуживающих хозяйств	TRANSIT	\N	t	Прочие операц. доходы	f	INDUSTRY
0f73dff8-17a0-44a6-8ea9-4c31ec320570	9510	Доходы в виде роялти	TRANSIT	\N	t	Финансовые доходы	f	EXTENSION
5640a6fa-58cd-4db3-8c6f-89db0a1bbba2	0160	Транспортные средства	ASSET	\N	t	Основные средства	f	EXTENSION
ded8fa64-3790-42ee-ba26-b1dc0ba1b3cc	9530	Доходы в виде процентов	TRANSIT	\N	t	Финансовые доходы	f	EXTENSION
07a8f8e6-9248-406c-b261-6569adadd714	0720	Оборудование к установке — импортное	ASSET	\N	t	Капитальные вложения	f	INDUSTRY
7f42d884-c5b5-4a60-a46e-0bae383ea1ac	8840	Налоговые льготы с целевым использованием	LIABILITY	\N	t	Капитал	f	EXTENSION
c646cece-c7c5-485d-a0b7-33cbe9b8db5c	9310	Прибыль от выбытия основных средств	TRANSIT	\N	t	Прочие операц. доходы	f	EXTENSION
26deba9a-95f3-43ab-87fd-ef8ac1337d0d	9560	Доходы от переоценки ценных бумаг	TRANSIT	\N	t	Финансовые доходы	f	EXTENSION
bb2bfec9-754f-4267-b016-4c0efcfc354e	9710	Чрезвычайные прибыли	TRANSIT	\N	t	Чрезвычайные	f	EXTENSION
91e48c62-91be-47f8-9091-1544c7fb9d4e	6910	Оперативная аренда к оплате	LIABILITY	\N	t	Краткосрочные обязательства	f	CORE
74a4966f-9646-4648-93ce-5f2dfb0e933d	9380	Безвозмездная финансовая помощь	TRANSIT	\N	t	Прочие операц. доходы	f	EXTENSION
48477c78-d235-4543-9386-422a2e32bdd4	0810	Незавершённое строительство	ASSET	\N	t	Капитальные вложения	f	EXTENSION
44feaa92-cf1d-4fbb-9023-f1f9e73def55	9030	Доходы от выполнения работ и оказания услуг	TRANSIT	\N	t	Доходы от осн. деятельности	f	CORE
aa653061-0293-4dab-9e5c-c371dc30a3e6	9040	Возврат проданных товаров (продукции)	TRANSIT	\N	t	Доходы от осн. деятельности	f	EXTENSION
4f79ed72-8dc9-4bc5-be22-e8132fb65664	9050	Скидки, предоставленные покупателям	TRANSIT	\N	t	Доходы от осн. деятельности	f	EXTENSION
113952ca-61ee-4e82-8eaa-e63cb5430441	9140	Приобретение/покупка ТМЗ при периодическом учёте	TRANSIT	\N	t	Себестоимость	f	INDUSTRY
50f6a4c6-4df8-4f58-a830-7b73fc00f043	9340	Прибыли прошлых лет	TRANSIT	\N	t	Прочие операц. доходы	f	EXTENSION
0029de7b-7030-4593-b0b0-4e894777bb18	0430	Программное обеспечение	ASSET	\N	t	Нематериальные активы	f	CORE
b5b4ec56-cf55-4368-a1c4-07d4566f6140	0590	Амортизация прочих НМА	CONTRA_ASSET	\N	t	Амортизация НМА	f	EXTENSION
dc3dcb02-b3de-423b-87af-d07aa90a9872	0290	Износ прочих основных средств	CONTRA_ASSET	\N	t	Износ ОС	f	EXTENSION
457661dd-bf58-48d5-81c0-2bf1acaf4c1a	0710	Оборудование к установке — отечественное	ASSET	\N	t	Капитальные вложения	f	INDUSTRY
3086bc86-bd80-4950-accf-39f5fd489fd7	0420	Торговые марки, товарные знаки и промышленные образцы	ASSET	\N	t	Нематериальные активы	f	EXTENSION
67ff0a15-570e-41d0-a62e-c8b52f685975	010	Основные средства, сданные по договору финансовой аренды	OFF_BALANCE	\N	t	Забалансовые	f	EXTENSION
26bf99f3-2733-475d-98c8-08e70300024d	006	Бланки строгой отчётности	OFF_BALANCE	\N	t	Забалансовые	f	EXTENSION
e097bbc3-376b-44fb-97a5-03eb3d34513b	002	ТМЦ, принятые на ответственное хранение	OFF_BALANCE	\N	t	Забалансовые	f	EXTENSION
35f6bedf-027e-41be-928d-86971eef439c	0820	Приобретение основных средств	ASSET	\N	t	Капитальные вложения	f	EXTENSION
5bd4b9b9-92ea-4ece-a33c-50af72832017	005	Оборудование, принятое для монтажа	OFF_BALANCE	\N	t	Забалансовые	f	INDUSTRY
66e93a59-6299-40b5-aa92-cb7571940147	001	Основные средства, полученные по оперативной аренде	OFF_BALANCE	\N	t	Забалансовые	f	EXTENSION
20870009-b541-46e3-beaf-19da206c796a	004	Товары, принятые на комиссию	OFF_BALANCE	\N	t	Забалансовые	f	INDUSTRY
d5b58309-f856-43f2-a3c0-53f1796554e9	0850	Капитальные вложения в благоустройство земли	ASSET	\N	t	Капитальные вложения	f	EXTENSION
a96ae022-a814-44a2-8605-b7bde45b696b	1050	Строительные материалы	ASSET	\N	t	Производственные запасы	f	INDUSTRY
a51e8566-a915-4488-aff6-d5e5a1dd3958	9820	Расходы по прочим налогам от прибыли	TRANSIT	\N	t	Налоги с прибыли	f	EXTENSION
35c23fc4-2874-4391-8579-0390f6b5a985	7290	Прочие долгосрочные отсроченные обязательства	LIABILITY	\N	t	Долгосрочные обязательства	f	EXTENSION
c8e047ca-b49a-491e-a119-b466072533b1	4330	Прочие авансы выданные	ASSET	\N	t	Дебиторская задолженность	f	EXTENSION
1cb13d06-43d0-40bb-823c-d3c5bae664d9	015	Имущество, полученное по договору простого товарищества	OFF_BALANCE	\N	t	Забалансовые	f	EXTENSION
582ca51d-8915-4a76-a5fc-2bda184e1764	0299	Износ ОС по финансовой аренде	CONTRA_ASSET	\N	t	Износ ОС	f	EXTENSION
1cd33873-8186-42fa-8b85-15caf7be2153	9810	Расходы по налогу на прибыль	TRANSIT	\N	t	Налоги с прибыли	f	CORE
dc6a5c06-b026-41f5-858d-9cdca0b1082e	0111	Благоустройство земли	ASSET	\N	t	Основные средства	f	EXTENSION
01f55375-4087-41a5-8925-742e6a7c79fc	1070	Материалы, переданные в переработку на сторону	ASSET	\N	t	Производственные запасы	f	INDUSTRY
d13264d6-f32a-473e-9077-d7bd42a4f897	007	Списанная в убыток задолженность неплатёжеспособных дебиторов	OFF_BALANCE	\N	t	Забалансовые	f	EXTENSION
4cf2cb4c-f02e-4b40-9421-266e1de94c19	4520	Авансовые платежи в государственные целевые фонды	ASSET	\N	t	Дебиторская задолженность	f	EXTENSION
e5914c39-4249-4c75-ae6b-558429b5cd1f	003	Материалы, принятые в переработку	OFF_BALANCE	\N	t	Забалансовые	f	INDUSTRY
cec04f29-1295-439c-b414-ce3ce730789b	0000	Вспомогательный (ввод начальных остатков)	ACTIVE_PASSIVE	\N	t	Системные	f	CORE
f1080dae-0686-49e6-ba05-9bb5729fbc45	4110	Счета к получению от обособленных подразделений	ASSET	\N	t	Дебиторская задолженность	f	EXTENSION
ab80894d-7a79-41be-92ba-540fc52787d8	4410	Авансовые платежи по налогам и сборам в бюджет	ASSET	\N	t	Дебиторская задолженность	f	CORE
5391cbc8-e2bb-448d-97f0-b950576dd5b3	013	Временные налоговые и таможенные льготы (по видам)	OFF_BALANCE	\N	t	Забалансовые	f	EXTENSION
c209fc77-f99a-445a-abcf-bd801d23a59e	6390	Прочие полученные авансы	LIABILITY	\N	t	Краткосрочные обязательства	f	EXTENSION
fc366069-031e-4a3c-a682-fafbd2f095cf	016	Нематериальные активы, полученные по праву пользования	OFF_BALANCE	\N	t	Забалансовые	f	EXTENSION
d654c479-ba28-4f39-a39d-a0326ddff559	6510	Платежи по страхованию	LIABILITY	\N	t	Краткосрочные обязательства	f	CORE
05649d19-dc49-4e00-b4cd-83beb21416a2	009	Обеспечения обязательств и платежей — выданные	OFF_BALANCE	\N	t	Забалансовые	f	EXTENSION
39adec63-3121-4134-8be2-5af7695adcab	011	Имущество, полученное по договору ссуды	OFF_BALANCE	\N	t	Забалансовые	f	EXTENSION
dadf99fe-87d0-4513-9706-24938056cb43	7110	Долгосрочная задолженность обособленным подразделениям	LIABILITY	\N	t	Долгосрочные обязательства	f	EXTENSION
2f59fe8a-fe43-448a-867c-4d4998e7c699	9720	Чрезвычайные убытки	TRANSIT	\N	t	Чрезвычайные	f	EXTENSION
68510867-58e0-404a-bde8-2bcae840b585	014	Инвентарь и хозяйственные принадлежности в эксплуатации	OFF_BALANCE	\N	t	Забалансовые	f	EXTENSION
f4f559d7-956d-4b57-8b5f-8d7e9a67b265	4510	Авансовые платежи по страхованию	ASSET	\N	t	Дебиторская задолженность	f	EXTENSION
dba75caf-e222-442d-81bd-c758df02d957	6920	Начисленные проценты	LIABILITY	\N	t	Краткосрочные обязательства	f	EXTENSION
ec1b13d0-5843-4b85-93f3-711a85cabe7d	8420	Курсовая разница при формировании уставного капитала	LIABILITY	\N	t	Капитал	f	EXTENSION
55a8b336-7cc1-4cfc-b2cf-81138d832379	8710	Нераспределённая прибыль (убыток) отчётного периода	LIABILITY	\N	t	Капитал	f	CORE
a68b25b4-345c-4b92-9e01-deec9e03fe65	8890	Прочие целевые поступления	LIABILITY	\N	t	Капитал	f	EXTENSION
7e5af491-9e31-4e48-b7f6-2aab90baa6d8	8910	Резервы предстоящих расходов и платежей	LIABILITY	\N	t	Капитал	f	EXTENSION
821602e0-760f-4cdf-8d98-03e5c4a6ce96	9610	Расходы в виде процентов	TRANSIT	\N	t	Финансовые расходы	f	EXTENSION
9aa26a58-9bf0-4523-995f-36c854589891	008	Обеспечения обязательств и платежей — полученные	OFF_BALANCE	\N	t	Забалансовые	f	EXTENSION
9c543edc-ebf9-46b8-898c-b68cbb5c368f	012	Расходы, исключаемые из налогооблагаемой базы следующих периодов	OFF_BALANCE	\N	t	Забалансовые	f	EXTENSION
9d3e5188-316e-46fa-bd32-50203c8893c7	5010	Касса (национальная валюта)	ASSET	\N	t	Денежные средства	f	CORE
61d06fe8-d9cd-459c-8db8-e52be27f0aa8	6320	Авансы, полученные от подписчиков на акции	LIABILITY	\N	t	Краткосрочные обязательства	f	EXTENSION
7a68a2c3-2344-4a0f-841c-d3204aff1d25	6620	Задолженность выбывающим учредителям по их доле	LIABILITY	\N	t	Краткосрочные обязательства	f	EXTENSION
3f277551-beae-4baf-8a41-6ca2c19c6f3f	6840	Векселя к оплате (краткосрочные)	LIABILITY	\N	t	Краткосрочные обязательства	f	EXTENSION
cbeef5a5-e1d3-4dfc-925c-6bd3f8bc521e	7010	Долгосрочные счета к оплате поставщикам	LIABILITY	\N	t	Долгосрочные обязательства	f	EXTENSION
d825bb48-1f60-48c1-bc55-e12556bd1b88	7830	Долгосрочные облигации к оплате	LIABILITY	\N	t	Долгосрочные обязательства	f	EXTENSION
fa12beb3-a823-4ade-afa9-d4b213576a9e	8510	Корректировки по переоценке долгосрочных активов	LIABILITY	\N	t	Капитал	f	EXTENSION
769b58f4-26e8-4080-b8cb-56a9a89374c9	0120	Здания, сооружения и передаточные устройства	ASSET	\N	t	Основные средства	f	EXTENSION
4728a9bc-d634-4be1-9aab-0c22decb0582	8530	Безвозмездно полученное имущество	LIABILITY	\N	t	Капитал	f	EXTENSION
9a7d15be-e68f-4772-b7f2-a7bc91d3352d	8620	Выкупленные собственные акции — привилегированные	CONTRA_LIABILITY	\N	t	Капитал	f	EXTENSION
5fa459f5-215b-41ac-b3bc-4a4ef8cbc0da	9130	Себестоимость выполненных работ и услуг	TRANSIT	\N	t	Себестоимость	f	CORE
6beaa8e4-f0c9-40ac-9e01-90e6f772982e	9210	Выбытие основных средств	TRANSIT	\N	t	Выбытие активов	f	EXTENSION
5be5c677-b405-4082-93a8-37d52681e00b	9320	Убыток от выбытия основных средств	TRANSIT	\N	t	Расходы периода	f	EXTENSION
1b19cfb1-93f1-4a2c-8b69-5b87f7d3cfd5	9550	Доходы от финансовой аренды	TRANSIT	\N	t	Финансовые доходы	f	EXTENSION
9e3cf63f-696d-4f32-bba0-17988f7b7ae5	0280	Износ многолетних насаждений	CONTRA_ASSET	\N	t	Износ ОС	f	INDUSTRY
7db7a596-4b71-479d-90a8-df2ca5ff7421	0470	Авторские права	ASSET	\N	t	Нематериальные активы	f	INDUSTRY
3b222079-81f2-47d0-b794-c1a9015539b8	0870	Капитальные вложения в ОС по оперативной аренде	ASSET	\N	t	Капитальные вложения	f	EXTENSION
5d632ed2-5a14-49bf-85eb-ec088cb38914	0920	Платежи к получению по финансовой аренде	ASSET	\N	t	Долгосрочная дебиторка	f	EXTENSION
c888b983-b48a-49f5-bd2a-877a808812d0	0960	Долгосрочные отсроченные расходы по дисконтам	ASSET	\N	t	Долгосрочная дебиторка	f	EXTENSION
432ebf75-c13d-4d10-b072-09ef82822747	2970	Товары в пути	ASSET	\N	t	Производство и ТМЗ	f	EXTENSION
f8a12afb-7c73-4612-ac9a-1c540a11163f	3210	Отсроченный налог на прибыль (текущий)	ASSET	\N	t	Предоплаты и РБП	f	EXTENSION
07641d9b-5c94-4918-9e04-797611bcec95	4610	Задолженность учредителей по вкладам в уставный капитал	ASSET	\N	t	Дебиторская задолженность	f	EXTENSION
\.


--
-- Data for Name: AuditLog; Type: TABLE DATA; Schema: public; Owner: user
--

COPY public."AuditLog" (id, "orgId", "userId", action, "entityType", "entityId", "oldValue", "newValue", "createdAt") FROM stdin;
733a7e74-c6be-4daa-9b20-3dc3be8f4ce4	1e996ba7-c636-4bdb-8fa9-16548f4d291e	b6fd1a37-31da-4a14-8761-ec6b579e539c	POST_DOCUMENT	Document	faa2f7ee-05f0-46ee-b552-27bb8616bbb6	\N	{"totalAmount": "10000000", "journalEntryCount": 2}	2026-07-05 10:18:18.208
50eac76f-31fa-46a7-ae85-1d977ee98558	9b41b1b5-f6bf-4d28-a299-f645126d578b	b6fd1a37-31da-4a14-8761-ec6b579e539c	POST_DOCUMENT	Document	159f6645-8246-461a-bc4c-0ec53537c116	\N	{"totalAmount": "2000", "journalEntryCount": 2}	2026-07-08 11:14:19.5
b2223851-0359-4b44-9468-02b02ac8cbe5	9b41b1b5-f6bf-4d28-a299-f645126d578b	b6fd1a37-31da-4a14-8761-ec6b579e539c	POST_DOCUMENT	Document	efdbb8f1-05d5-4df3-bbe9-1524268aa2fb	\N	{"totalAmount": "196000", "journalEntryCount": 2}	2026-07-08 11:20:37.913
5648c712-b047-4072-b384-68a3cba5cc31	9b41b1b5-f6bf-4d28-a299-f645126d578b	b6fd1a37-31da-4a14-8761-ec6b579e539c	POST_DOCUMENT	Document	9268de84-f08b-4d84-b163-65ec38d4c648	\N	{"totalAmount": "1049019.42", "journalEntryCount": 2}	2026-07-08 11:21:02.108
46440015-777d-4d3d-84b8-f6bdf22b4728	9b41b1b5-f6bf-4d28-a299-f645126d578b	b6fd1a37-31da-4a14-8761-ec6b579e539c	POST_DOCUMENT	Document	36e951a7-2516-471a-b799-2bfc70e9a924	\N	{"totalAmount": "964000", "journalEntryCount": 2}	2026-07-08 11:21:18.29
1d512ed9-1923-491d-a9f6-39d494febad2	9b41b1b5-f6bf-4d28-a299-f645126d578b	b6fd1a37-31da-4a14-8761-ec6b579e539c	POST_DOCUMENT	Document	f002e9c8-ae69-46fb-8120-5b0f279334c7	\N	{"totalAmount": "148000", "journalEntryCount": 2}	2026-07-08 11:21:59.741
f44c2c00-e0a7-479a-8540-6b53711201f6	9b41b1b5-f6bf-4d28-a299-f645126d578b	b6fd1a37-31da-4a14-8761-ec6b579e539c	POST_DOCUMENT	Document	927502bf-9d13-4cf6-87d8-552637d7215e	\N	{"totalAmount": "5245.1", "journalEntryCount": 2}	2026-07-08 11:22:15.57
de5aebd1-3846-49b9-be29-a5109d9a7af5	9b41b1b5-f6bf-4d28-a299-f645126d578b	system	POST_DOCUMENT	Document	06d94365-67e1-4555-86dc-c4f840233e28	\N	{"totalAmount": "14569896", "journalEntryCount": 3}	2026-07-08 11:23:13.536
87fd0342-003f-47c9-9085-46670ede2b7e	9b41b1b5-f6bf-4d28-a299-f645126d578b	system	POST_DOCUMENT	Document	42d646e5-429b-4461-bb52-0125c13fedf9	\N	{"totalAmount": "200000", "journalEntryCount": 2}	2026-07-08 11:23:13.554
68c02430-8a86-4c41-ab32-8b018805923d	9b41b1b5-f6bf-4d28-a299-f645126d578b	b6fd1a37-31da-4a14-8761-ec6b579e539c	POST_DOCUMENT	Document	1effa11a-ac17-4047-bc05-4c98d7d5ea62	\N	{"totalAmount": "2480000", "journalEntryCount": 8}	2026-07-08 11:23:19.066
d7f7593c-a355-42b2-9a82-9a6c2a22d42d	9b41b1b5-f6bf-4d28-a299-f645126d578b	b6fd1a37-31da-4a14-8761-ec6b579e539c	POST_DOCUMENT	Document	708b6914-40c9-4839-af68-b05fee50e414	\N	{"totalAmount": "4120", "journalEntryCount": 2}	2026-07-08 11:25:16.655
69efb263-7b13-423b-ae11-b38acfe88c17	9b41b1b5-f6bf-4d28-a299-f645126d578b	b6fd1a37-31da-4a14-8761-ec6b579e539c	POST_DOCUMENT	Document	7bbddcd3-e108-4aa5-9e4e-8375f029cbb0	\N	{"totalAmount": "1210", "journalEntryCount": 2}	2026-07-08 11:25:35.951
9f9b2f1f-b78a-48cc-944b-5fe6fde94c26	9b41b1b5-f6bf-4d28-a299-f645126d578b	b6fd1a37-31da-4a14-8761-ec6b579e539c	POST_DOCUMENT	Document	b6344b4d-48a9-4301-9390-ea4310821ec3	\N	{"totalAmount": "72849.48", "journalEntryCount": 2}	2026-07-08 11:25:35.972
147f8ef2-5312-4050-8c0f-7828e9783cb2	9b41b1b5-f6bf-4d28-a299-f645126d578b	b6fd1a37-31da-4a14-8761-ec6b579e539c	POST_DOCUMENT	Document	369d18f6-3b01-424c-9549-0f8f62cd8f9f	\N	{"totalAmount": "14569896", "journalEntryCount": 2}	2026-07-08 11:25:43.165
21d0b78f-696b-4daa-90da-b9b6f31d756a	9b41b1b5-f6bf-4d28-a299-f645126d578b	b6fd1a37-31da-4a14-8761-ec6b579e539c	POST_DOCUMENT	Document	8132dded-5210-4de0-9e2a-7fb0330c6420	\N	{"totalAmount": "824000", "journalEntryCount": 2}	2026-07-08 11:26:00.045
9363bd09-944d-4809-931f-e7b819736c0c	9b41b1b5-f6bf-4d28-a299-f645126d578b	b6fd1a37-31da-4a14-8761-ec6b579e539c	POST_DOCUMENT	Document	d303133e-e42c-49c3-94e5-1d4896961fe7	\N	{"totalAmount": "242000", "journalEntryCount": 2}	2026-07-08 11:26:24.563
cf890416-a3a5-4975-b999-94bbd79e488e	9b41b1b5-f6bf-4d28-a299-f645126d578b	b6fd1a37-31da-4a14-8761-ec6b579e539c	POST_DOCUMENT	Document	3607742a-a5b4-4ab8-ae50-1bd960fda873	\N	{"totalAmount": "18000000", "journalEntryCount": 2}	2026-07-08 11:26:48.845
bd22c33a-2b8b-4d03-a92c-ed52c849deb9	9b41b1b5-f6bf-4d28-a299-f645126d578b	b6fd1a37-31da-4a14-8761-ec6b579e539c	POST_DOCUMENT	Document	ca007879-8cca-494d-b844-915675cfad3f	\N	{"totalAmount": "148000", "journalEntryCount": 2}	2026-07-08 11:27:07.849
65562475-4463-4d2b-ae68-2e77ba8ee5bd	9b41b1b5-f6bf-4d28-a299-f645126d578b	b6fd1a37-31da-4a14-8761-ec6b579e539c	POST_DOCUMENT	Document	0d127988-dbfe-42dd-a5c7-cb1fbb1ea1e0	\N	{"totalAmount": "2000", "journalEntryCount": 2}	2026-07-08 11:27:22.036
ba9bea54-6011-4f1a-967b-03efff0b29ec	9b41b1b5-f6bf-4d28-a299-f645126d578b	b6fd1a37-31da-4a14-8761-ec6b579e539c	POST_DOCUMENT	Document	6c4c0f46-2bd8-4a3a-8607-bb22d0501e2d	\N	{"totalAmount": "2480000", "journalEntryCount": 8}	2026-07-08 11:54:15.427
55e681c7-c9f9-4f2d-bc2b-9f040f172760	228045b1-34d6-4a27-8034-8a9860ab013e	b6fd1a37-31da-4a14-8761-ec6b579e539c	POST_DOCUMENT	Document	7e623458-26af-4ca1-a2d8-32be7142a0a2	\N	{"totalAmount": "10000000", "journalEntryCount": 2}	2026-07-09 12:54:41.589
949bde21-4952-4b74-8972-5371af0a1886	228045b1-34d6-4a27-8034-8a9860ab013e	b6fd1a37-31da-4a14-8761-ec6b579e539c	POST_DOCUMENT	Document	627dc252-7fd6-4287-9cfe-abed79ff56a1	\N	{"totalAmount": "1000000", "journalEntryCount": 2}	2026-07-09 13:00:23.95
1a33e926-f438-436f-b158-d45ea1c666a0	228045b1-34d6-4a27-8034-8a9860ab013e	b6fd1a37-31da-4a14-8761-ec6b579e539c	POST_DOCUMENT	Document	63da4762-7555-4693-b2fc-a2ea7da1b1cd	\N	{"totalAmount": "2200000", "journalEntryCount": 2}	2026-07-09 13:01:41.795
07cb7f0e-2196-4d15-822a-3d51437a6759	228045b1-34d6-4a27-8034-8a9860ab013e	b6fd1a37-31da-4a14-8761-ec6b579e539c	VOID_DOCUMENT	Document	63da4762-7555-4693-b2fc-a2ea7da1b1cd	\N	\N	2026-07-09 13:02:13.691
4d6e12e6-ffc1-4d1e-94e3-189f91d2ea52	228045b1-34d6-4a27-8034-8a9860ab013e	b6fd1a37-31da-4a14-8761-ec6b579e539c	POST_DOCUMENT	Document	aa0dad12-d8c4-4d52-94c2-2fe81086545e	\N	{"totalAmount": "3594.64", "journalEntryCount": 2}	2026-07-09 13:03:14.35
0ccb62e1-c8ad-4c94-9ed2-e9f7f35b6e41	228045b1-34d6-4a27-8034-8a9860ab013e	b6fd1a37-31da-4a14-8761-ec6b579e539c	POST_DOCUMENT	Document	ed998172-0562-425c-9a66-1ac60d0759b2	\N	{"totalAmount": "250", "journalEntryCount": 2}	2026-07-09 13:03:28.54
552c5596-e349-42de-91be-df60c7e9c09b	228045b1-34d6-4a27-8034-8a9860ab013e	b6fd1a37-31da-4a14-8761-ec6b579e539c	POST_DOCUMENT	Document	d97199c4-8389-4192-9d7b-0ae587eb0af4	\N	{"totalAmount": "11000", "journalEntryCount": 2}	2026-07-09 13:03:28.561
a75d2f3e-1870-44f2-9c5f-43db5a5d5482	228045b1-34d6-4a27-8034-8a9860ab013e	b6fd1a37-31da-4a14-8761-ec6b579e539c	POST_DOCUMENT	Document	2e51fd5a-212c-4cba-a3d5-afa2e97c54b9	\N	{"totalAmount": "8758400", "journalEntryCount": 2}	2026-07-09 13:03:40.151
bfb81bf1-a9e1-4a26-b344-fc6b494f39ff	228045b1-34d6-4a27-8034-8a9860ab013e	b6fd1a37-31da-4a14-8761-ec6b579e539c	VOID_DOCUMENT	Document	2e51fd5a-212c-4cba-a3d5-afa2e97c54b9	\N	\N	2026-07-09 13:03:49.774
0d64afd3-2633-469a-939d-dd007f8990ca	228045b1-34d6-4a27-8034-8a9860ab013e	b6fd1a37-31da-4a14-8761-ec6b579e539c	POST_DOCUMENT	Document	2e51fd5a-212c-4cba-a3d5-afa2e97c54b9	\N	{"totalAmount": "8758400", "journalEntryCount": 2}	2026-07-09 13:03:49.791
52d8a0ab-eb65-4af2-96ea-79f4884f2cfc	228045b1-34d6-4a27-8034-8a9860ab013e	b6fd1a37-31da-4a14-8761-ec6b579e539c	POST_DOCUMENT	Document	af31e6c4-e24e-4565-baa5-438168e57987	\N	{"totalAmount": "718928", "journalEntryCount": 2}	2026-07-09 13:04:08.162
2b002f25-49f4-4a7e-8198-706adb2dcf49	228045b1-34d6-4a27-8034-8a9860ab013e	b6fd1a37-31da-4a14-8761-ec6b579e539c	POST_DOCUMENT	Document	3265a466-9bd0-4b8b-b69c-13f1b18f5ca0	\N	{"totalAmount": "50000", "journalEntryCount": 2}	2026-07-09 13:04:22.076
a379f2ba-f282-45ed-9879-8888d600d3f2	228045b1-34d6-4a27-8034-8a9860ab013e	system	POST_DOCUMENT	Document	2172cdba-7065-4335-9919-5f7bf069c4d9	\N	{"totalAmount": "718928", "journalEntryCount": 3}	2026-07-09 13:05:36.603
ce4fe425-2b24-4654-b246-88f487fe5b1f	228045b1-34d6-4a27-8034-8a9860ab013e	b6fd1a37-31da-4a14-8761-ec6b579e539c	POST_DOCUMENT	Document	f31b9a57-a7c1-4d39-8733-91400bd395f9	\N	{"totalAmount": "394010", "journalEntryCount": 8}	2026-07-09 13:05:45.345
bb24ecf4-539c-427d-92f1-6619727afc40	228045b1-34d6-4a27-8034-8a9860ab013e	b6fd1a37-31da-4a14-8761-ec6b579e539c	POST_DOCUMENT	Document	de23966a-d8bc-4c74-abec-cbe0c5699600	\N	{"totalAmount": "67600", "journalEntryCount": 2}	2026-07-09 13:07:06.966
91ed9ca0-10a4-43d5-9eca-9139786278a5	228045b1-34d6-4a27-8034-8a9860ab013e	b6fd1a37-31da-4a14-8761-ec6b579e539c	POST_DOCUMENT	Document	cf54202e-1701-49a3-95d9-e9e4812eeaf7	\N	{"totalAmount": "115000", "journalEntryCount": 2}	2026-07-09 13:07:11.904
f94c76a4-e41b-4a97-beef-cea1d9dc10e6	228045b1-34d6-4a27-8034-8a9860ab013e	b6fd1a37-31da-4a14-8761-ec6b579e539c	POST_DOCUMENT	Document	219c3b57-72b1-40f6-a85d-a5222efc6c40	\N	{"totalAmount": "135", "journalEntryCount": 2}	2026-07-09 13:07:11.925
7d05cc37-0b3d-49ea-8280-7b44d4dbcf1f	228045b1-34d6-4a27-8034-8a9860ab013e	b6fd1a37-31da-4a14-8761-ec6b579e539c	POST_DOCUMENT	Document	6878037d-e213-42b4-8a3f-abfa8418cd3d	\N	{"totalAmount": "10000", "journalEntryCount": 2}	2026-07-09 13:07:11.942
5ec220d5-83a2-4383-8c15-c9d0861a8c46	228045b1-34d6-4a27-8034-8a9860ab013e	b6fd1a37-31da-4a14-8761-ec6b579e539c	POST_DOCUMENT	Document	c4b78d9a-9d79-4fd1-bd2e-4a320f43dcc3	\N	{"totalAmount": "23000000", "journalEntryCount": 2}	2026-07-09 13:07:40.263
bf85ecce-6365-4718-949b-65592d50cb9d	228045b1-34d6-4a27-8034-8a9860ab013e	b6fd1a37-31da-4a14-8761-ec6b579e539c	POST_DOCUMENT	Document	7d4683e1-8fe0-46d7-b92d-ae489a109a58	\N	{"totalAmount": "9800", "journalEntryCount": 2}	2026-07-09 13:08:07.725
978ae206-bac2-4371-b66f-d133bb3a434b	228045b1-34d6-4a27-8034-8a9860ab013e	b6fd1a37-31da-4a14-8761-ec6b579e539c	POST_DOCUMENT	Document	3fe7aafa-78ab-4d78-89a1-9294678c3503	\N	{"totalAmount": "9800", "journalEntryCount": 2}	2026-07-09 13:08:15.285
fc2ac6b2-8976-480c-81f4-df3884d85b16	228045b1-34d6-4a27-8034-8a9860ab013e	b6fd1a37-31da-4a14-8761-ec6b579e539c	POST_DOCUMENT	Document	b65d11bc-5cff-41d2-b472-57219d107a2f	\N	{"totalAmount": "9800", "journalEntryCount": 2}	2026-07-09 13:08:16.664
c9f2b23d-1663-4300-9f82-0382179a31c0	228045b1-34d6-4a27-8034-8a9860ab013e	b6fd1a37-31da-4a14-8761-ec6b579e539c	POST_DOCUMENT	Document	316bf16a-1bf7-44ce-8321-35a237c99395	\N	{"totalAmount": "27000", "journalEntryCount": 2}	2026-07-09 13:08:42.039
6264ef77-29a1-4708-9cee-e0dbb04edadd	228045b1-34d6-4a27-8034-8a9860ab013e	b6fd1a37-31da-4a14-8761-ec6b579e539c	POST_DOCUMENT	Document	78e4fdc3-f8d3-4994-aa1f-190e2cf23341	\N	{"totalAmount": "22000000", "journalEntryCount": 2}	2026-07-09 13:09:10.321
e30afdfa-8006-4af8-9868-3d778eb92243	228045b1-34d6-4a27-8034-8a9860ab013e	b6fd1a37-31da-4a14-8761-ec6b579e539c	POST_DOCUMENT	Document	2b3e652d-fb0e-4281-9400-80e74c9e4e88	\N	{"totalAmount": "317.5", "journalEntryCount": 2}	2026-07-09 13:09:34.083
8f86bf1b-dd89-47d9-92f6-41fffb7f3331	228045b1-34d6-4a27-8034-8a9860ab013e	b6fd1a37-31da-4a14-8761-ec6b579e539c	POST_DOCUMENT	Document	f2de3f2a-a296-4918-b407-7dd1c17de6aa	\N	{"totalAmount": "38130", "journalEntryCount": 2}	2026-07-09 13:09:42.433
af58a96f-8caf-4847-972f-88fae02abef6	228045b1-34d6-4a27-8034-8a9860ab013e	b6fd1a37-31da-4a14-8761-ec6b579e539c	POST_DOCUMENT	Document	e8bc4baa-35fc-438b-8940-3f02fdc94e81	\N	{"totalAmount": "317750", "journalEntryCount": 2}	2026-07-09 13:09:43.36
4a86c9ce-ab97-4537-b457-393c4f0599d5	228045b1-34d6-4a27-8034-8a9860ab013e	system	POST_DOCUMENT	Document	0bd3a180-cd59-4ea4-92ea-f3e09d3df52f	\N	{"totalAmount": "8758400", "journalEntryCount": 3}	2026-07-09 13:10:29.82
4dc596cf-d0a3-4284-8cd1-9977148d4df3	228045b1-34d6-4a27-8034-8a9860ab013e	system	POST_DOCUMENT	Document	c6cba1dd-ce54-4cb2-8c74-2fd6d514da37	\N	{"totalAmount": "10000", "journalEntryCount": 3}	2026-07-09 13:10:29.842
4a08e65f-476d-4670-bea4-2c15b895ad58	228045b1-34d6-4a27-8034-8a9860ab013e	system	POST_DOCUMENT	Document	f45ceb7e-a022-4c72-b8dd-5d71d54492f8	\N	{"totalAmount": "20000", "journalEntryCount": 3}	2026-07-09 13:10:29.865
1bfa476a-5302-463e-94cd-f8a28efe14c2	228045b1-34d6-4a27-8034-8a9860ab013e	b6fd1a37-31da-4a14-8761-ec6b579e539c	POST_DOCUMENT	Document	be229a41-64c1-43e5-8059-e20e000adc71	\N	{"totalAmount": "2000000", "journalEntryCount": 2}	2026-07-09 13:10:02.033
9aebde66-4864-42ca-a45c-b750959c1b9d	228045b1-34d6-4a27-8034-8a9860ab013e	b6fd1a37-31da-4a14-8761-ec6b579e539c	POST_DOCUMENT	Document	4ded0de0-e0bb-4ace-8c9d-77a0b3fe8ce2	\N	{"totalAmount": "313871.4292", "journalEntryCount": 2}	2026-07-09 13:10:39.601
94399dd5-bc61-4614-81a3-f53f512fad39	228045b1-34d6-4a27-8034-8a9860ab013e	b6fd1a37-31da-4a14-8761-ec6b579e539c	POST_DOCUMENT	Document	7d1d1831-85dd-4a60-8dca-0c57933c315d	\N	{"totalAmount": "2200", "journalEntryCount": 2}	2026-07-09 13:11:29.958
b588de8d-d86c-41d1-b1a7-2d24d4af5ff7	228045b1-34d6-4a27-8034-8a9860ab013e	b6fd1a37-31da-4a14-8761-ec6b579e539c	POST_DOCUMENT	Document	91a3ebac-7df7-4486-b822-70297179e97e	\N	{"totalAmount": "150000", "journalEntryCount": 2}	2026-07-09 13:11:46.662
3557c6ff-cc1c-478b-bc99-185e715fbb6f	228045b1-34d6-4a27-8034-8a9860ab013e	b6fd1a37-31da-4a14-8761-ec6b579e539c	POST_DOCUMENT	Document	b1d210e7-b80d-4ea8-90a1-9ffebade3b93	\N	{"totalAmount": "58800", "journalEntryCount": 2}	2026-07-09 13:11:46.682
acbb71ee-9493-4712-931a-f707c5a78fd0	228045b1-34d6-4a27-8034-8a9860ab013e	b6fd1a37-31da-4a14-8761-ec6b579e539c	POST_DOCUMENT	Document	d9ce31f7-dd4e-4c95-966b-773f593b0375	\N	{"totalAmount": "86150.66", "journalEntryCount": 2}	2026-07-09 13:11:46.699
a22ed3b5-b4cb-4dff-81c5-48c512b48960	228045b1-34d6-4a27-8034-8a9860ab013e	b6fd1a37-31da-4a14-8761-ec6b579e539c	POST_DOCUMENT	Document	1a42d156-cfc7-42d4-8857-69eb740375bc	\N	{"totalAmount": "50000", "journalEntryCount": 2}	2026-07-09 13:11:46.716
505e784c-11b1-406f-be27-63cf75ef56ef	228045b1-34d6-4a27-8034-8a9860ab013e	b6fd1a37-31da-4a14-8761-ec6b579e539c	POST_DOCUMENT	Document	e7b9c4f6-4f29-473d-9773-4efb4e829728	\N	{"totalAmount": "150000", "journalEntryCount": 2}	2026-07-09 13:11:46.735
8f3e951f-b407-4583-9a0f-021a18113bb6	228045b1-34d6-4a27-8034-8a9860ab013e	b6fd1a37-31da-4a14-8761-ec6b579e539c	POST_DOCUMENT	Document	a1003312-7511-483f-8163-1deb296f8e5c	\N	{"totalAmount": "1367296", "journalEntryCount": 2}	2026-07-09 13:11:46.753
b378836a-1f72-4c21-bbb1-5781429e254b	228045b1-34d6-4a27-8034-8a9860ab013e	b6fd1a37-31da-4a14-8761-ec6b579e539c	POST_DOCUMENT	Document	89c82fc4-b714-4284-9feb-10e0555d3177	\N	{"totalAmount": "10000", "journalEntryCount": 2}	2026-07-09 13:11:46.769
704aca3b-bf83-49b8-8747-db307e6eaeb6	228045b1-34d6-4a27-8034-8a9860ab013e	b6fd1a37-31da-4a14-8761-ec6b579e539c	POST_DOCUMENT	Document	21be39e8-aa00-4b16-906c-fe79c21d3e3b	\N	{"totalAmount": "440000", "journalEntryCount": 2}	2026-07-09 13:12:01.012
9f71af7d-c2bb-40c2-9983-eaaef075e497	228045b1-34d6-4a27-8034-8a9860ab013e	b6fd1a37-31da-4a14-8761-ec6b579e539c	POST_DOCUMENT	Document	d3b7b6ff-39ed-4f60-b72a-cb0f5ef56e51	\N	{"totalAmount": "11760000", "journalEntryCount": 2}	2026-07-09 13:12:24.308
5760a085-b66f-4673-a1e7-da92148f74bb	228045b1-34d6-4a27-8034-8a9860ab013e	b6fd1a37-31da-4a14-8761-ec6b579e539c	POST_DOCUMENT	Document	f1791b1a-0bfc-400c-9174-bf34095b8ee1	\N	{"totalAmount": "12900000", "journalEntryCount": 2}	2026-07-09 13:13:04.983
9b5d812a-9174-4c17-acfa-c70975456592	228045b1-34d6-4a27-8034-8a9860ab013e	b6fd1a37-31da-4a14-8761-ec6b579e539c	POST_DOCUMENT	Document	ac054429-ae2a-4031-8118-ff6aee3e0307	\N	{"totalAmount": "17230131.2", "journalEntryCount": 2}	2026-07-09 13:13:15.82
b6d35db9-35f2-45f5-bd84-20eb84947240	228045b1-34d6-4a27-8034-8a9860ab013e	b6fd1a37-31da-4a14-8761-ec6b579e539c	POST_DOCUMENT	Document	01b8648a-010f-42a3-b6ec-54288965b3d2	\N	{"totalAmount": "3244000", "journalEntryCount": 2}	2026-07-09 13:13:35
ae117cec-fde4-4281-b2c7-9237bc82a3c2	228045b1-34d6-4a27-8034-8a9860ab013e	b6fd1a37-31da-4a14-8761-ec6b579e539c	POST_DOCUMENT	Document	077b80f7-1e33-45f9-9e92-81dc082d6a78	\N	{"totalAmount": "10000000", "journalEntryCount": 2}	2026-07-09 13:14:15.064
9c265d83-02fb-4727-88e7-bcd025fdfdc1	228045b1-34d6-4a27-8034-8a9860ab013e	b6fd1a37-31da-4a14-8761-ec6b579e539c	POST_DOCUMENT	Document	68431629-82a5-4424-8513-0a353d73847a	\N	{"totalAmount": "3000000", "journalEntryCount": 2}	2026-07-09 13:14:25.293
c46a7d1c-8917-4435-abc3-5e758f35d29e	228045b1-34d6-4a27-8034-8a9860ab013e	b6fd1a37-31da-4a14-8761-ec6b579e539c	POST_DOCUMENT	Document	20968e04-8198-489b-9bf2-0c2137596932	\N	{"totalAmount": "3000000", "journalEntryCount": 2}	2026-07-09 13:14:59.259
f6ccd9d6-dda6-4391-9388-341e8089fe6c	228045b1-34d6-4a27-8034-8a9860ab013e	b6fd1a37-31da-4a14-8761-ec6b579e539c	VOID_DOCUMENT	Document	077b80f7-1e33-45f9-9e92-81dc082d6a78	\N	\N	2026-07-09 13:15:15.336
a45d2a07-853d-4932-861f-4bfb4d61cfac	228045b1-34d6-4a27-8034-8a9860ab013e	b6fd1a37-31da-4a14-8761-ec6b579e539c	POST_DOCUMENT	Document	077b80f7-1e33-45f9-9e92-81dc082d6a78	\N	{"totalAmount": "10000000", "journalEntryCount": 2}	2026-07-09 13:15:15.354
54924c06-eb2c-461c-b39f-9a7f7239df5b	228045b1-34d6-4a27-8034-8a9860ab013e	b6fd1a37-31da-4a14-8761-ec6b579e539c	POST_DOCUMENT	Document	bdd58d95-d287-401f-8d36-56a41b35faa0	\N	{"totalAmount": "30000000", "journalEntryCount": 2}	2026-07-09 13:15:30.606
835e1f85-2880-4bc3-9404-366a5b11ccbc	228045b1-34d6-4a27-8034-8a9860ab013e	b6fd1a37-31da-4a14-8761-ec6b579e539c	POST_DOCUMENT	Document	5506b7cd-c391-49ec-8b80-36fb8c102c5e	\N	{"totalAmount": "30000000", "journalEntryCount": 2}	2026-07-09 13:15:33.461
bad49577-3f25-4bd5-a9e1-db98369c5e19	228045b1-34d6-4a27-8034-8a9860ab013e	b6fd1a37-31da-4a14-8761-ec6b579e539c	POST_DOCUMENT	Document	7b65e3d5-7721-4e6b-ad83-8e745596fdf4	\N	{"totalAmount": "69090000", "journalEntryCount": 2}	2026-07-09 13:15:46.017
4befac5f-0e85-405c-9b30-a7e2d676716d	228045b1-34d6-4a27-8034-8a9860ab013e	b6fd1a37-31da-4a14-8761-ec6b579e539c	POST_DOCUMENT	Document	d9882e12-e27a-4f4d-beeb-a5b4102befc6	\N	{"totalAmount": "5376000", "journalEntryCount": 2}	2026-07-09 13:15:56.507
7fdd9d09-dc1a-411a-b006-30b468f1e964	228045b1-34d6-4a27-8034-8a9860ab013e	b6fd1a37-31da-4a14-8761-ec6b579e539c	POST_DOCUMENT	Document	821ff739-ceb3-468b-a469-3188c9c2adfe	\N	{"totalAmount": "273459200", "journalEntryCount": 2}	2026-07-09 13:16:09.208
01d1b470-621a-4025-af3e-c8b05813538a	228045b1-34d6-4a27-8034-8a9860ab013e	b6fd1a37-31da-4a14-8761-ec6b579e539c	POST_DOCUMENT	Document	b0b6bda9-3e50-483f-96e1-68599833266f	\N	{"totalAmount": "864586.29", "journalEntryCount": 2}	2026-07-09 13:16:35.623
6a888e75-09b5-480a-9932-1df750865184	228045b1-34d6-4a27-8034-8a9860ab013e	b6fd1a37-31da-4a14-8761-ec6b579e539c	POST_DOCUMENT	Document	53761d90-2d33-4fe6-ae87-ba0ffd3c1264	\N	{"totalAmount": "37812.25", "journalEntryCount": 2}	2026-07-09 13:16:41.202
b88744a3-c5af-4955-a2f3-9122b66d43a5	228045b1-34d6-4a27-8034-8a9860ab013e	b6fd1a37-31da-4a14-8761-ec6b579e539c	POST_DOCUMENT	Document	cf27399b-5ba6-4d9c-a193-aed14256a4af	\N	{"totalAmount": "38130", "journalEntryCount": 2}	2026-07-09 13:16:41.227
58f92ac9-bb96-4c88-9de9-0a58a25bf0b7	228045b1-34d6-4a27-8034-8a9860ab013e	b6fd1a37-31da-4a14-8761-ec6b579e539c	POST_DOCUMENT	Document	a67fe804-1e2b-4797-8e39-d7131fbef04b	\N	{"totalAmount": "2000000", "journalEntryCount": 2}	2026-07-09 13:16:58.594
6e5aa7dc-bf50-4953-b4fa-4a0a240437ec	228045b1-34d6-4a27-8034-8a9860ab013e	b6fd1a37-31da-4a14-8761-ec6b579e539c	POST_DOCUMENT	Document	550d7573-4c1f-47b7-8e1d-e141883d295d	\N	{"totalAmount": "540", "journalEntryCount": 2}	2026-07-09 13:17:08.412
e5c9e5fd-1559-41e9-9d42-d12e599883c5	228045b1-34d6-4a27-8034-8a9860ab013e	b6fd1a37-31da-4a14-8761-ec6b579e539c	POST_DOCUMENT	Document	41de570d-fbc4-456a-a719-283eb13c744d	\N	{"totalAmount": "317.5", "journalEntryCount": 2}	2026-07-09 13:17:50.542
07f59b6b-d688-4757-b6d0-9abb1ab7b1c4	228045b1-34d6-4a27-8034-8a9860ab013e	b6fd1a37-31da-4a14-8761-ec6b579e539c	POST_DOCUMENT	Document	cb806713-eb7e-4d54-bdda-1275cdfd268a	\N	{"totalAmount": "15000", "journalEntryCount": 2}	2026-07-09 13:18:04.772
45d7428e-0916-4e58-993d-2f42914d0692	228045b1-34d6-4a27-8034-8a9860ab013e	b6fd1a37-31da-4a14-8761-ec6b579e539c	POST_DOCUMENT	Document	e83e6bc6-2603-4e58-a51d-d69857399d3b	\N	{"totalAmount": "292640000", "journalEntryCount": 2}	2026-07-09 13:18:32.417
b949c06a-d76f-4457-b2d7-fd976493140f	228045b1-34d6-4a27-8034-8a9860ab013e	b6fd1a37-31da-4a14-8761-ec6b579e539c	POST_DOCUMENT	Document	aae08362-44ef-44be-90db-010c074c39c7	\N	{"totalAmount": "108000", "journalEntryCount": 2}	2026-07-09 13:18:50.902
2aefa6a0-6479-4d55-ab49-79a97cca4c22	228045b1-34d6-4a27-8034-8a9860ab013e	system	POST_DOCUMENT	Document	34dadae4-87ee-4ee0-9e84-dc7b95a1587b	\N	{"totalAmount": "273459200", "journalEntryCount": 3}	2026-07-09 13:20:44.691
369cc25c-ded3-45b8-9868-9a0d40d619fc	228045b1-34d6-4a27-8034-8a9860ab013e	system	POST_DOCUMENT	Document	48ed7424-5e3c-4432-88e6-04b225b5598c	\N	{"totalAmount": "11760000", "journalEntryCount": 3}	2026-07-09 13:20:44.71
ec8da787-aff7-46de-8f90-8dc1856e8f04	228045b1-34d6-4a27-8034-8a9860ab013e	system	POST_DOCUMENT	Document	7b56f596-91c7-4e2c-818d-98435eab1dc0	\N	{"totalAmount": "33230131.2", "journalEntryCount": 3}	2026-07-09 13:20:44.736
69016f39-3e50-4c6b-9662-02f996b12d0e	228045b1-34d6-4a27-8034-8a9860ab013e	system	POST_DOCUMENT	Document	affdb512-06c1-4966-ae81-2be136f20bde	\N	{"totalAmount": "5376000", "journalEntryCount": 3}	2026-07-09 13:20:44.751
4efaeefc-058e-4c30-97f7-dc7a6bd6290a	228045b1-34d6-4a27-8034-8a9860ab013e	system	POST_DOCUMENT	Document	03e09997-e6b7-4ce0-8dad-6a8f2111b944	\N	{"totalAmount": "3244000", "journalEntryCount": 3}	2026-07-09 13:20:44.77
d267b5dc-88f7-4b33-96c8-28761dc55b3c	228045b1-34d6-4a27-8034-8a9860ab013e	b6fd1a37-31da-4a14-8761-ec6b579e539c	POST_DOCUMENT	Document	3c9de340-150a-4e66-8913-55b583fc3309	\N	{"totalAmount": "4960000", "journalEntryCount": 8}	2026-07-09 13:20:51.814
8b648876-3a5e-49e2-b071-ded7ad5dc146	228045b1-34d6-4a27-8034-8a9860ab013e	b6fd1a37-31da-4a14-8761-ec6b579e539c	POST_DOCUMENT	Document	7373fd1c-0fb0-41ce-bfc1-b11797f2851c	\N	{"totalAmount": "3520000", "journalEntryCount": 2}	2026-07-09 13:20:51.834
7efac875-937c-4625-8c89-66d77ed89f59	228045b1-34d6-4a27-8034-8a9860ab013e	b6fd1a37-31da-4a14-8761-ec6b579e539c	POST_DOCUMENT	Document	70e3aa5d-b43d-4942-8d52-dc92ef10b872	\N	{"totalAmount": "307857.1428", "journalEntryCount": 2}	2026-07-09 13:20:51.87
\.


--
-- Data for Name: BankAccount; Type: TABLE DATA; Schema: public; Owner: user
--

COPY public."BankAccount" (id, "orgId", name, currency, "bankName", "accountNumber", "lastBalance", "lastSyncedAt") FROM stdin;
f89191ed-f456-4648-a8ac-c98c649f7b18	9b41b1b5-f6bf-4d28-a299-f645126d578b	Main	UZS	OFB	20208000405418599001	772980.35	2026-07-08 11:23:30.369
5801bb14-ff63-4873-84b5-649306c350a8	228045b1-34d6-4a27-8034-8a9860ab013e	Main	UZS	OFB	20208000907434526001	19824558.32	2026-07-09 13:11:03.913
388019a0-1f2b-4bb4-9082-4a29977bc584	1e996ba7-c636-4bdb-8fa9-16548f4d291e	Основной	UZS	OFB	20208000807434489001	0.00	\N
\.


--
-- Data for Name: ClassificationJob; Type: TABLE DATA; Schema: public; Owner: user
--

COPY public."ClassificationJob" (id, "orgId", status, matched, "needsClarification", error, "createdAt", "updatedAt", processed, total) FROM stdin;
\.


--
-- Data for Name: ClosingJob; Type: TABLE DATA; Schema: public; Owner: user
--

COPY public."ClosingJob" (id, "periodId", "orgId", status, step, data, error, "startedAt", "completedAt", "createdAt", "updatedAt") FROM stdin;
6510e8dc-8120-4ce8-95d3-e7e98be5ab8a	4f03361b-3c66-4bd6-9343-0876d6d8ac74	9b41b1b5-f6bf-4d28-a299-f645126d578b	COMPLETED	7	{"fxDiff": {"difference": 0, "exchangeRate": 0}, "accruals": {"rentAmount": 0, "salaryAmount": 2000000, "depreciationAmount": 0, "expenseAccountCode": "9420"}, "currentStep": 7, "soliqMatched": {"matched": 0, "unmatched": 0}}	\N	2026-07-08 11:54:15.393	2026-07-08 11:54:15.477	2026-07-08 11:23:22.449	2026-07-08 11:54:15.478
a38a8f98-252b-41a2-92c1-8c39729055ca	f623fd76-5028-4900-b760-b70090905288	9b41b1b5-f6bf-4d28-a299-f645126d578b	COMPLETED	7	{"fxDiff": {"difference": 0, "exchangeRate": 0}, "accruals": {"rentAmount": 0, "salaryAmount": 2000000, "depreciationAmount": 0, "expenseAccountCode": "9420"}, "currentStep": 7, "soliqMatched": {"matched": 1, "unmatched": 1}}	\N	2026-07-08 11:23:19.029	2026-07-08 11:23:19.113	2026-07-08 11:12:40.343	2026-07-08 11:23:19.114
320a546c-99f3-492d-a482-5306c1ed0260	12c40a94-ca5e-4587-a825-336e0034921e	228045b1-34d6-4a27-8034-8a9860ab013e	COMPLETED	7	{"fxDiff": {"difference": 0, "exchangeRate": 0}, "accruals": {"rentAmount": 0, "salaryAmount": 0, "depreciationAmount": 0, "expenseAccountCode": "9420"}, "currentStep": 7, "soliqMatched": {"matched": 3, "unmatched": 0}}	\N	2026-07-09 13:10:39.567	2026-07-09 13:10:39.627	2026-07-09 13:05:48.587	2026-07-09 13:10:39.628
d451651e-9c0f-4129-8137-297d5d3a1f77	7f6821e4-96d7-4c4f-82e9-713c49232527	228045b1-34d6-4a27-8034-8a9860ab013e	COMPLETED	7	{"fxDiff": {"difference": 0, "exchangeRate": 0}, "accruals": {"rentAmount": 0, "salaryAmount": 317750, "depreciationAmount": 0, "expenseAccountCode": "9420"}, "currentStep": 7, "soliqMatched": {"matched": 1, "unmatched": 0}}	\N	2026-07-09 13:05:45.313	2026-07-09 13:05:45.391	2026-07-09 12:58:14.16	2026-07-09 13:05:45.392
a211a812-0645-4b7e-b881-f5d06a3a9a7f	7a927f44-73c4-42d6-a03e-73d32327dbc5	228045b1-34d6-4a27-8034-8a9860ab013e	COMPLETED	7	{"fxDiff": {"difference": 0, "exchangeRate": 0}, "accruals": {"rentAmount": 0, "salaryAmount": 4000000, "depreciationAmount": 0, "expenseAccountCode": "9420"}, "currentStep": 7, "soliqMatched": {"matched": 4, "unmatched": 1}}	\N	2026-07-09 13:20:51.784	2026-07-09 13:20:51.899	2026-07-09 13:10:43.103	2026-07-09 13:20:51.9
33b5412b-5fea-4edf-9fdc-a1ed853f9465	65435e8b-7413-4034-b4a7-f5ca4651570e	228045b1-34d6-4a27-8034-8a9860ab013e	DRAFT	1	{"fxDiff": {"difference": 0, "exchangeRate": 0}, "accruals": {"rentAmount": 0, "salaryAmount": 0, "depreciationAmount": 0, "expenseAccountCode": "9420"}, "currentStep": 1, "soliqMatched": {"matched": 0, "unmatched": 0}}	\N	\N	\N	2026-07-09 17:59:36.016	2026-07-09 17:59:36.016
\.


--
-- Data for Name: Counterparty; Type: TABLE DATA; Schema: public; Owner: user
--

COPY public."Counterparty" (id, "orgId", name, inn) FROM stdin;
2d73b49f-9032-4ff6-b3af-a6715d0c10f5	9b41b1b5-f6bf-4d28-a299-f645126d578b	Mirzo-Ulug'bek Tumani DSI	200540423
d0fab1a1-01c7-4ac8-a6be-83d3fded6723	9b41b1b5-f6bf-4d28-a299-f645126d578b	Транзитный счёт для рассчёта с коммерсантами (Payme)	308718135
da3d3e6f-8dd8-42d1-9397-fe3b4ea32069	9b41b1b5-f6bf-4d28-a299-f645126d578b	ИП ООО "MONT CLOUD"	306180825
10569498-372b-4ff1-b51b-3e3d4db05283	9b41b1b5-f6bf-4d28-a299-f645126d578b	Казначейство Министерства финансов Республика Узбекистан	201122919
80cfd80b-3a55-4c28-8ee5-6441bfd8de7b	9b41b1b5-f6bf-4d28-a299-f645126d578b	DASTURIY MAHSULOTLAR VA AXBOROT TEXNOLOGIYALARI TEXNOLOGIK PARKI DIREKSIYASI	305975326
2b9a27b0-138b-40b6-a311-97fcdd3f0a3d	9b41b1b5-f6bf-4d28-a299-f645126d578b	Бошка ташкилотлар хизматлари учун жис.шахслардан кабул килинган туловлар	207086151
80865cc4-fd02-4f9e-8608-aae41e98021c	228045b1-34d6-4a27-8034-8a9860ab013e	BURANOV AXMADJON MAXMUDOVICH	306230564
8efb7065-213b-4c62-838b-2c5b5393f736	228045b1-34d6-4a27-8034-8a9860ab013e	ООО "AKSEL MWD"	309935428
b1087098-dde0-4318-a196-493a5e716b1e	228045b1-34d6-4a27-8034-8a9860ab013e	Начисленные %% GP TECH UNION	312915680
583304d1-9194-4ecd-af6c-e58fd2b1bc9a	228045b1-34d6-4a27-8034-8a9860ab013e	MCHJ CASHGENICS	308710993
8941bde9-9692-4f3e-97f3-8dc5a9d247a1	228045b1-34d6-4a27-8034-8a9860ab013e	AXOFT MCHJ	305774212
41373d41-012d-4406-aa8a-2c8d0ac3fa00	228045b1-34d6-4a27-8034-8a9860ab013e	ORIENT FINANS BANK	207086151
bd3939c2-7f7e-4ea7-a3a7-a8527ffa4191	228045b1-34d6-4a27-8034-8a9860ab013e	"CLICK" AJ	302134733
208d0354-efbc-4d6e-9836-45a9d7680dde	228045b1-34d6-4a27-8034-8a9860ab013e	ООО "SUVAN NET"	301551793
cb65d521-7e19-4c2d-b42a-3f752a991e72	228045b1-34d6-4a27-8034-8a9860ab013e	ИП ООО "SMART SOLUTIONS INTERNATIONAL"	310332959
d033802e-4b26-4a33-ad50-aced98701cbc	228045b1-34d6-4a27-8034-8a9860ab013e	Mirzo-Ulug`bek Tumani DSI boshlig`i USMANOV D.А.	200540423
4c02bdca-a140-47e0-ac15-47f1326e337f	228045b1-34d6-4a27-8034-8a9860ab013e	Казначейство Министерства финансов Республика Узбекистан	201122919
851efd17-6b28-4782-bbf1-ab1e6baff372	228045b1-34d6-4a27-8034-8a9860ab013e	VIDIMO MCHJ	310783571
ddc0ee30-c4ca-47fb-8135-65ff085395f8	228045b1-34d6-4a27-8034-8a9860ab013e	"SEAL MAG" AJ	201535024
2f1e5d48-ca43-468f-862a-6dec9fb89995	228045b1-34d6-4a27-8034-8a9860ab013e	SOFTPROM MCHJ	311149962
50116ac8-31c0-46f2-9e7f-6af654bb75b9	228045b1-34d6-4a27-8034-8a9860ab013e	"MEGATON" MCHJ	311010005
d17e1182-8fe0-4ad1-886c-97b971790002	228045b1-34d6-4a27-8034-8a9860ab013e	APN PROMISE ARAL MCHJ XK	311509237
68af40f5-a777-4bab-9ed0-ec9e65984883	228045b1-34d6-4a27-8034-8a9860ab013e	ООО "CENTRAL ASIA MEGASTAR" - основной депозитный счет до востребовани	200642271
d7ece227-fc70-4f93-b92c-a7cc6a9a5eee	228045b1-34d6-4a27-8034-8a9860ab013e	AO UZRTSB	200933985
77a71845-8115-4b48-91a1-9aa942b293d7	228045b1-34d6-4a27-8034-8a9860ab013e	"KAFOLAT SUGURTA KOMPANIYASI AJ"	202288236
079e08b8-a737-4171-b8e0-940c158ae79e	228045b1-34d6-4a27-8034-8a9860ab013e	ООО CALLIE LIMITED	312384465
fa0300ce-3f55-4881-bf90-042e34a1c8b1	228045b1-34d6-4a27-8034-8a9860ab013e	GRAND  PHARM  TRADE MCHJ	303303592
\.


--
-- Data for Name: Document; Type: TABLE DATA; Schema: public; Owner: user
--

COPY public."Document" (id, "orgId", "periodId", "typeId", date, status, payload, "sourceTransactionId", "correctionForPeriodId", "taxCalendarSyncError", "taxCalendarSyncStatus") FROM stdin;
faa2f7ee-05f0-46ee-b552-27bb8616bbb6	1e996ba7-c636-4bdb-8fa9-16548f4d291e	5669264c-fcfe-40ae-bc30-956d12e97c10	257a0183-45a2-43cb-bc23-d93cc06dea6b	2026-07-05 10:18:18.192	POSTED	{"amount": 10000000, "paidAmount": null, "fundingType": "NOT_PAID", "fundedAccountCode": null}	\N	\N	\N	OK
9268de84-f08b-4d84-b163-65ec38d4c648	9b41b1b5-f6bf-4d28-a299-f645126d578b	f623fd76-5028-4900-b760-b70090905288	348b6a91-2055-4cd8-b96a-613eede381c7	2026-05-04 00:00:00	POSTED	{"amount": 1049019.42, "direction": "DEBIT", "confirmedBy": "USER", "description": "00668 M365 Fmily Subscr PK Lic 1YR Online Centrl/Estern Euro Only ESD C, право на использование", "counterpartyInn": "306180825", "counterpartyHint": "ИП ООО \\"MONT CLOUD\\""}	5da9b376-09cf-4d97-99cf-6e0cf066177a	\N	\N	OK
36e951a7-2516-471a-b799-2bfc70e9a924	9b41b1b5-f6bf-4d28-a299-f645126d578b	f623fd76-5028-4900-b760-b70090905288	11153a82-fa3f-4228-9376-e6ba3e88a335	2026-05-04 00:00:00	POSTED	{"amount": 964000, "direction": "DEBIT", "confirmedBy": "USER", "description": "08102~1000218602262693112525093~200540423~Оплата за Налог с оборота за Апрель 2026 г $TAX_ID$26124000082528", "counterpartyInn": "201122919", "counterpartyHint": "Казначейство Министерства финансов Республика Узбекистан"}	0ad5c36c-e1a0-40f3-8e87-b4dba284af99	\N	\N	OK
f002e9c8-ae69-46fb-8120-5b0f279334c7	9b41b1b5-f6bf-4d28-a299-f645126d578b	f623fd76-5028-4900-b760-b70090905288	11153a82-fa3f-4228-9376-e6ba3e88a335	2026-05-04 00:00:00	POSTED	{"amount": 148000, "direction": "DEBIT", "confirmedBy": "USER", "description": "08102~1000218604262693111103093~200540423~Оплата за Налог на доходы физических лиц (НДФЛ) за Апрель 2026 г $TAX_ID$26124000082746", "counterpartyInn": "201122919", "counterpartyHint": "Казначейство Министерства финансов Республика Узбекистан"}	0c645a83-0653-43de-aa9f-0ecb02ff5fc3	\N	\N	OK
927502bf-9d13-4cf6-87d8-552637d7215e	9b41b1b5-f6bf-4d28-a299-f645126d578b	f623fd76-5028-4900-b760-b70090905288	6c00d577-1c7a-4512-971c-91a3156659be	2026-05-04 00:00:00	POSTED	{"amount": 5245.1, "direction": "DEBIT", "confirmedBy": "USER", "description": "00668 BC 04.05.2026 погашение Дебет айланма(банкаро) -5245.10 от суммы 1049019.42  от 04.05.2026", "counterpartyInn": "308718135", "counterpartyHint": "Начисленные %% ООО \\"GORGEOUS PARTNERS\\""}	1d8e6909-c059-4adc-ad40-030978d473ab	\N	\N	OK
e61432b7-c829-4ea4-9839-3d98f20d7a98	9b41b1b5-f6bf-4d28-a299-f645126d578b	f623fd76-5028-4900-b760-b70090905288	9ce804f2-c684-4282-9ffb-62a9a6f2cb8d	2026-05-31 00:00:00	POSTED	{"expenses": 1, "revenues": 1, "taxSummary": {"vat": -1561060.29, "inputVat": 1561060.29, "incomeTax": 0, "outputVat": 0, "turnoverTax": 0}, "totalEsfItems": 2}	\N	\N	\N	\N
06d94365-67e1-4555-86dc-c4f840233e28	9b41b1b5-f6bf-4d28-a299-f645126d578b	f623fd76-5028-4900-b760-b70090905288	f0f3b223-81ec-45c0-9727-3fc2c27dc855	2026-05-12 00:00:00	POSTED	{"amount": 14569896, "vatAmount": 1561060.29, "counterpartyInn": "306180825", "counterpartyHint": "\\"MONT CLOUD \\" MAS'ULIYATI CHEKLANGAN JAMIYAT XORIJIY KORXONA"}	\N	\N	\N	OK
42d646e5-429b-4461-bb52-0125c13fedf9	9b41b1b5-f6bf-4d28-a299-f645126d578b	f623fd76-5028-4900-b760-b70090905288	04ca266f-a8cb-4ffd-ac75-6ae68c6ace72	2026-05-02 00:00:00	POSTED	{"amount": 200000, "vatAmount": 0, "counterpartyInn": "308718135", "counterpartyHint": ""}	\N	\N	\N	OK
159f6645-8246-461a-bc4c-0ec53537c116	9b41b1b5-f6bf-4d28-a299-f645126d578b	f623fd76-5028-4900-b760-b70090905288	28c8c399-9da5-4b55-a645-e8a884e9293f	2026-05-14 00:00:00	POSTED	{"amount": 2000, "direction": "DEBIT", "confirmedBy": "USER", "description": "08102 Оплата Отчисление в ИНПС апрель 2026 $TAX_ID$26134002007583", "counterpartyInn": "200540423", "counterpartyHint": "Mirzo-Ulug'bek Tumani DSI"}	2d89bcb5-e711-4edf-9ac5-dc9a4313dd1a	\N	\N	OK
efdbb8f1-05d5-4df3-bbe9-1524268aa2fb	9b41b1b5-f6bf-4d28-a299-f645126d578b	f623fd76-5028-4900-b760-b70090905288	285a86d8-bd31-4db1-974d-776806e52f09	2026-05-04 00:00:00	POSTED	{"amount": 196000, "direction": "CREDIT", "confirmedBy": "USER", "description": "00634Зачисление денежных средств поставщику MCHJ GORGEOUS PARTNERS (ИНН: 308718135) от PAYME за 02-05-2026 за услуги или товары через HUMO. С автоудержанем (Без оплат) 2% с поставщика CID: 697e51b8fbe4c888a5b95013 EXT: 69f6afdb7637906f27569aed MID: 63b7ac7cd3af34dee9986e01", "counterpartyInn": "308718135", "counterpartyHint": "Транзитный счёт для рассчёта с коммерсантами (Payme)"}	ee5fe381-0ee4-4277-9c0f-da781e8b0631	\N	\N	OK
1effa11a-ac17-4047-bc05-4c98d7d5ea62	9b41b1b5-f6bf-4d28-a299-f645126d578b	f623fd76-5028-4900-b760-b70090905288	e6b9d9c6-c670-49df-a165-3afeb98e56a4	2026-05-28 00:00:00	POSTED	{"salaryAmount": 2000000, "expenseAccountCode": "9420"}	\N	\N	\N	OK
66fde351-72e3-45fa-a526-341d88b01ce8	9b41b1b5-f6bf-4d28-a299-f645126d578b	f623fd76-5028-4900-b760-b70090905288	ba6d6bd5-788d-49b2-a9a5-4663d887a42c	2026-05-28 00:00:00	POSTED	{"type": "period_closing", "year": 2026, "month": 5}	\N	\N	\N	\N
708b6914-40c9-4839-af68-b05fee50e414	9b41b1b5-f6bf-4d28-a299-f645126d578b	4f03361b-3c66-4bd6-9343-0876d6d8ac74	6c00d577-1c7a-4512-971c-91a3156659be	2026-06-10 00:00:00	POSTED	{"amount": 4120, "direction": "DEBIT", "confirmedBy": "USER", "description": "00111 BC 10.06.2026 погашение Дебет айланма(банкаро) -4120.00 от суммы 824000.00  от 10.06.2026", "counterpartyInn": "308718135", "counterpartyHint": "Начисленные %% ООО \\"GORGEOUS PARTNERS\\""}	a56d42fc-6a63-40f7-9d14-2c031042b556	\N	\N	OK
7bbddcd3-e108-4aa5-9e4e-8375f029cbb0	9b41b1b5-f6bf-4d28-a299-f645126d578b	4f03361b-3c66-4bd6-9343-0876d6d8ac74	6c00d577-1c7a-4512-971c-91a3156659be	2026-06-10 00:00:00	POSTED	{"amount": 1210, "direction": "DEBIT", "confirmedBy": "USER", "description": "00111 BC 10.06.2026 погашение Дебет айланма(банкаро) -1210.00 от суммы 242000.00  от 10.06.2026", "counterpartyInn": "308718135", "counterpartyHint": "Начисленные %% ООО \\"GORGEOUS PARTNERS\\""}	71e1ec8b-1ea5-4a9b-9dc5-2d608ef504ad	\N	\N	OK
6c4c0f46-2bd8-4a3a-8607-bb22d0501e2d	9b41b1b5-f6bf-4d28-a299-f645126d578b	4f03361b-3c66-4bd6-9343-0876d6d8ac74	e6b9d9c6-c670-49df-a165-3afeb98e56a4	2026-06-28 00:00:00	POSTED	{"salaryAmount": 2000000, "expenseAccountCode": "9420"}	\N	\N	\N	OK
bde731f2-5d13-45ef-a0aa-da022876d377	9b41b1b5-f6bf-4d28-a299-f645126d578b	4f03361b-3c66-4bd6-9343-0876d6d8ac74	ba6d6bd5-788d-49b2-a9a5-4663d887a42c	2026-06-28 00:00:00	POSTED	{"type": "period_closing", "year": 2026, "month": 6}	\N	\N	\N	\N
b6344b4d-48a9-4301-9390-ea4310821ec3	9b41b1b5-f6bf-4d28-a299-f645126d578b	4f03361b-3c66-4bd6-9343-0876d6d8ac74	6c00d577-1c7a-4512-971c-91a3156659be	2026-06-10 00:00:00	POSTED	{"amount": 72849.48, "direction": "DEBIT", "confirmedBy": "USER", "description": "00111 BC 10.06.2026 погашение Дебет айланма(банкаро) -72849.48 от суммы 14569896.00  от 10.06.2026", "counterpartyInn": "308718135", "counterpartyHint": "Начисленные %% ООО \\"GORGEOUS PARTNERS\\""}	b215ae13-69f1-4e29-b077-a4911d9f6653	\N	\N	OK
369d18f6-3b01-424c-9549-0f8f62cd8f9f	9b41b1b5-f6bf-4d28-a299-f645126d578b	4f03361b-3c66-4bd6-9343-0876d6d8ac74	348b6a91-2055-4cd8-b96a-613eede381c7	2026-06-10 00:00:00	POSTED	{"amount": 14569896, "direction": "DEBIT", "confirmedBy": "USER", "description": "00112 Creative Cloud Pro for teams ALL Multiple Platforms Multi European Languages Subscription New счет № 524 от 12.05.2026 к договору № 82П/24 от 24.10.2024", "counterpartyInn": "306180825", "counterpartyHint": "ИП ООО \\"MONT CLOUD\\""}	3906666e-cf76-4685-b2fb-a523714b1a89	\N	\N	OK
8132dded-5210-4de0-9e2a-7fb0330c6420	9b41b1b5-f6bf-4d28-a299-f645126d578b	4f03361b-3c66-4bd6-9343-0876d6d8ac74	8fdc07dc-89f5-4d8e-81e4-ce54fb6dc7b0	2026-06-10 00:00:00	POSTED	{"amount": 824000, "direction": "DEBIT", "confirmedBy": "USER", "description": "00111 Оплата за услуги Виртуального офиса по договору №220 от 01.04.2026 года за июнь 2026 г.", "counterpartyInn": "305975326", "counterpartyHint": "DASTURIY MAHSULOTLAR VA AXBOROT TEXNOLOGIYALARI TEXNOLOGIK PARKI DIREKSIYASI"}	54032d8a-07b5-4d49-8e9b-ff65aa820df2	\N	\N	OK
d303133e-e42c-49c3-94e5-1d4896961fe7	9b41b1b5-f6bf-4d28-a299-f645126d578b	4f03361b-3c66-4bd6-9343-0876d6d8ac74	9822b4d7-542a-408b-8c0c-d5fc808a9483	2026-06-10 00:00:00	POSTED	{"amount": 242000, "direction": "DEBIT", "confirmedBy": "USER", "description": "00111 Взаиморасчет по отчислениям ИНН: 308718135", "counterpartyInn": "308718135", "counterpartyHint": "DASTURIY MAHSULOTLAR VA AXBOROT TEXNOLOGIYALARI TEXNOLOGIK PARKI DIREKSIYASI"}	9998a5cc-4602-4353-b8c6-ed21f1588cfc	\N	\N	OK
3607742a-a5b4-4ab8-ae50-1bd960fda873	9b41b1b5-f6bf-4d28-a299-f645126d578b	4f03361b-3c66-4bd6-9343-0876d6d8ac74	a945e1d9-4ba7-4f05-a073-4f7b82fe1f30	2026-06-10 00:00:00	POSTED	{"amount": 18000000, "direction": "CREDIT", "confirmedBy": "USER", "description": "00659БУРАНОВ АХМАДЖОН Пополнение уставного фонда RRN (029997368296)  За 10.06.2026", "counterpartyInn": "207086151", "counterpartyHint": "Бошка ташкилотлар хизматлари учун жис.шахслардан кабул килинган туловлар"}	3d5172b9-e7af-43cb-aa79-7b00e273c1ba	\N	\N	OK
ca007879-8cca-494d-b844-915675cfad3f	9b41b1b5-f6bf-4d28-a299-f645126d578b	4f03361b-3c66-4bd6-9343-0876d6d8ac74	11153a82-fa3f-4228-9376-e6ba3e88a335	2026-06-01 00:00:00	POSTED	{"amount": 148000, "direction": "DEBIT", "confirmedBy": "USER", "description": "08102~1000218604262693111103093~200540423~Оплата Налог на доходы физических лиц (НДФЛ) за май 2026 г $TAX_ID$26152000712833", "counterpartyInn": "201122919", "counterpartyHint": "Казначейство Министерства финансов Республика Узбекистан"}	bebb2ad3-7f91-4dbe-9e4b-18d09120b73c	\N	\N	OK
0d127988-dbfe-42dd-a5c7-cb1fbb1ea1e0	9b41b1b5-f6bf-4d28-a299-f645126d578b	4f03361b-3c66-4bd6-9343-0876d6d8ac74	28c8c399-9da5-4b55-a645-e8a884e9293f	2026-06-01 00:00:00	POSTED	{"amount": 2000, "direction": "DEBIT", "confirmedBy": "USER", "description": "00717 Оплата Отчисление в ИНПС за май 2026 г $TAX_ID$26152000712669", "counterpartyInn": "200540423", "counterpartyHint": "Mirzo-Ulug`bek Tumani DSI boshlig`i USMANOV D.А."}	3e8d928e-e435-4663-b35f-ff87c59e2e05	\N	\N	OK
627dc252-7fd6-4287-9cfe-abed79ff56a1	228045b1-34d6-4a27-8034-8a9860ab013e	7f6821e4-96d7-4c4f-82e9-713c49232527	a945e1d9-4ba7-4f05-a073-4f7b82fe1f30	2026-04-09 00:00:00	POSTED	{"amount": 1000000, "direction": "CREDIT", "confirmedBy": "USER", "description": "00668  Buranov Axmadjon Maxmudovich. пополнение уставного фонда 609911411732", "counterpartyInn": "306230564", "counterpartyHint": "BURANOV AXMADJON MAXMUDOVICH"}	bb74e133-e87b-4664-b87d-807b8671b461	\N	\N	OK
3265a466-9bd0-4b8b-b69c-13f1b18f5ca0	228045b1-34d6-4a27-8034-8a9860ab013e	7f6821e4-96d7-4c4f-82e9-713c49232527	7d5bc76f-1bf4-4d51-9f41-bb19759698ee	2026-04-16 00:00:00	POSTED	{"amount": 50000, "direction": "DEBIT", "confirmedBy": "USER", "description": "00668 ИНН 312915680 за услуги электронного документооборота Didox.uz согласно Публичной оферте", "counterpartyInn": "312915680", "counterpartyHint": "ООО Didox Tech"}	85f8e755-0eba-445f-83ff-7501dcc93d99	\N	\N	OK
f8ca25ae-c36d-44a2-a247-3d778aeb5e90	228045b1-34d6-4a27-8034-8a9860ab013e	7f6821e4-96d7-4c4f-82e9-713c49232527	9ce804f2-c684-4282-9ffb-62a9a6f2cb8d	2026-04-30 00:00:00	POSTED	{"expenses": 1, "revenues": 0, "taxSummary": {"vat": -77028, "inputVat": 77028, "incomeTax": 0, "outputVat": 0, "turnoverTax": 0}, "totalEsfItems": 1}	\N	\N	\N	\N
63da4762-7555-4693-b2fc-a2ea7da1b1cd	228045b1-34d6-4a27-8034-8a9860ab013e	7f6821e4-96d7-4c4f-82e9-713c49232527	98d89959-6f0c-4e37-8f4a-73f191630df3	2026-04-09 00:00:00	VOIDED	{"amount": 2200000, "direction": "CREDIT", "confirmedBy": "USER", "description": "00668 Предоплата 100% по договору №07042026-1 от 07.04.2026 за Zoom Workplace Professional подписка на 12 месяцев", "counterpartyInn": "309935428", "counterpartyHint": "ООО \\"AKSEL MWD\\""}	dd5edf46-74b2-49a8-83a9-4c73791d396a	\N	\N	OK
aa0dad12-d8c4-4d52-94c2-2fe81086545e	228045b1-34d6-4a27-8034-8a9860ab013e	7f6821e4-96d7-4c4f-82e9-713c49232527	6c00d577-1c7a-4512-971c-91a3156659be	2026-04-28 00:00:00	POSTED	{"amount": 3594.64, "direction": "DEBIT", "confirmedBy": "USER", "description": "00668 BC 28.04.2026 погашение Дебет айланма(банкаро) -3594.64 от суммы 718928.00  от 28.04.2026", "counterpartyInn": "312915680", "counterpartyHint": "Начисленные %% GP TECH UNION"}	23e2b62a-ad63-40bf-b579-a4265b3278ab	\N	\N	OK
ed998172-0562-425c-9a66-1ac60d0759b2	228045b1-34d6-4a27-8034-8a9860ab013e	7f6821e4-96d7-4c4f-82e9-713c49232527	6c00d577-1c7a-4512-971c-91a3156659be	2026-04-16 00:00:00	POSTED	{"amount": 250, "direction": "DEBIT", "confirmedBy": "USER", "description": "00668 BC 16.04.2026 погашение Дебет айланма(банкаро) -250.00 от суммы 50000.00  от 16.04.2026", "counterpartyInn": "312915680", "counterpartyHint": "Начисленные %% GP TECH UNION"}	2fbbb8f8-50b5-4e85-afe1-be6a0cd8e0f1	\N	\N	OK
d97199c4-8389-4192-9d7b-0ae587eb0af4	228045b1-34d6-4a27-8034-8a9860ab013e	7f6821e4-96d7-4c4f-82e9-713c49232527	6c00d577-1c7a-4512-971c-91a3156659be	2026-04-10 00:00:00	POSTED	{"amount": 11000, "direction": "DEBIT", "confirmedBy": "USER", "description": "00668 BC 10.04.2026 погашение Дебет айланма(ички) -11000.00 от суммы 2200000.00  от 10.04.2026", "counterpartyInn": "312915680", "counterpartyHint": "Начисленные %% GP TECH UNION"}	e90a47bc-31b4-4107-b975-78260203efec	\N	\N	OK
2172cdba-7065-4335-9919-5f7bf069c4d9	228045b1-34d6-4a27-8034-8a9860ab013e	7f6821e4-96d7-4c4f-82e9-713c49232527	56015255-3d79-4d7f-8058-7ab53527ac13	2026-04-28 00:00:00	POSTED	{"amount": 718928, "vatAmount": 77028, "counterpartyInn": "305774212", "counterpartyHint": "\\"AXOFT\\" MCHJ"}	\N	\N	\N	OK
2e51fd5a-212c-4cba-a3d5-afa2e97c54b9	228045b1-34d6-4a27-8034-8a9860ab013e	7f6821e4-96d7-4c4f-82e9-713c49232527	98d89959-6f0c-4e37-8f4a-73f191630df3	2026-04-29 00:00:00	POSTED	{"amount": 8758400, "direction": "CREDIT", "confirmedBy": "USER", "description": "00523Пред 100 % за праграмму windows 10 Pro для АДМ с-но дог 28042026-1 от 28042026 года с учетом НДС", "counterpartyInn": "308710993", "counterpartyHint": "MCHJ CASHGENICS"}	f8e32686-f661-4150-a451-8f295b6ac024	\N	\N	OK
f31b9a57-a7c1-4d39-8733-91400bd395f9	228045b1-34d6-4a27-8034-8a9860ab013e	7f6821e4-96d7-4c4f-82e9-713c49232527	e6b9d9c6-c670-49df-a165-3afeb98e56a4	2026-04-28 00:00:00	POSTED	{"salaryAmount": 317750, "expenseAccountCode": "9420"}	\N	\N	\N	OK
9ac4d545-e899-4955-930a-b59b3444a9e4	228045b1-34d6-4a27-8034-8a9860ab013e	7f6821e4-96d7-4c4f-82e9-713c49232527	ba6d6bd5-788d-49b2-a9a5-4663d887a42c	2026-04-28 00:00:00	POSTED	{"type": "period_closing", "year": 2026, "month": 4}	\N	\N	\N	\N
de23966a-d8bc-4c74-abec-cbe0c5699600	228045b1-34d6-4a27-8034-8a9860ab013e	12c40a94-ca5e-4587-a825-336e0034921e	6c00d577-1c7a-4512-971c-91a3156659be	2026-05-22 00:00:00	POSTED	{"amount": 67600, "direction": "DEBIT", "confirmedBy": "USER", "description": "00668 BC 22.05.2026 погашение Дебет айланма(банкаро) -67600.00 от суммы 13520000.00  от 22.05.2026", "counterpartyInn": "312915680", "counterpartyHint": "Начисленные %% GP TECH UNION"}	01d03459-bd47-4abe-a200-2eb664ba60c7	\N	\N	OK
cf54202e-1701-49a3-95d9-e9e4812eeaf7	228045b1-34d6-4a27-8034-8a9860ab013e	12c40a94-ca5e-4587-a825-336e0034921e	6c00d577-1c7a-4512-971c-91a3156659be	2026-05-18 00:00:00	POSTED	{"amount": 115000, "direction": "DEBIT", "confirmedBy": "USER", "description": "00668 BC 18.05.2026 погашение Дебет айланма(ички) -115000.00 от суммы 23000000.00  от 18.05.2026", "counterpartyInn": "312915680", "counterpartyHint": "Начисленные %% GP TECH UNION"}	a707fa37-6c92-465c-b6d3-3b21de659b1f	\N	\N	OK
c4b78d9a-9d79-4fd1-bd2e-4a320f43dcc3	228045b1-34d6-4a27-8034-8a9860ab013e	12c40a94-ca5e-4587-a825-336e0034921e	a8764508-ec8a-49ab-b12f-f18f38dd6493	2026-05-18 00:00:00	POSTED	{"amount": 23000000, "direction": "DEBIT", "confirmedBy": "USER", "description": "00634 ОПЛАТА ПО ДОГОВОРУ ССУДЫ 18052026-1С от 18.05.2026 НА КАРТУ ДИР 5614682900908783 BURANOV AXMADJON", "counterpartyInn": "207086151", "counterpartyHint": "ORIENT FINANS BANK"}	ee105e52-2a32-4052-ad8b-4e84db02eef1	\N	\N	OK
219c3b57-72b1-40f6-a85d-a5222efc6c40	228045b1-34d6-4a27-8034-8a9860ab013e	12c40a94-ca5e-4587-a825-336e0034921e	6c00d577-1c7a-4512-971c-91a3156659be	2026-05-12 00:00:00	POSTED	{"amount": 135, "direction": "DEBIT", "confirmedBy": "USER", "description": "00668 BC 12.05.2026 погашение Дебет айланма(банкаро) -135.00 от суммы 27000.00  от 12.05.2026", "counterpartyInn": "312915680", "counterpartyHint": "Начисленные %% GP TECH UNION"}	eedbdcb1-d191-4314-a6eb-72c72ccd0f77	\N	\N	OK
6878037d-e213-42b4-8a3f-abfa8418cd3d	228045b1-34d6-4a27-8034-8a9860ab013e	12c40a94-ca5e-4587-a825-336e0034921e	6c00d577-1c7a-4512-971c-91a3156659be	2026-05-04 00:00:00	POSTED	{"amount": 10000, "direction": "DEBIT", "confirmedBy": "USER", "description": "00668 BC 04.05.2026 погашение Дебет айланма(банкаро) -10000.00 от суммы 2000000.00  от 04.05.2026", "counterpartyInn": "312915680", "counterpartyHint": "Начисленные %% GP TECH UNION"}	f69df85a-7b28-4876-bdec-df241e0570dd	\N	\N	OK
e8bc4baa-35fc-438b-8940-3f02fdc94e81	228045b1-34d6-4a27-8034-8a9860ab013e	12c40a94-ca5e-4587-a825-336e0034921e	1394e1a8-b539-48bb-95c9-2069b3f95ee8	2026-05-04 00:00:00	POSTED	{"amount": 317750, "direction": "DEBIT", "confirmedBy": "USER", "description": "08102~1000218604262693111103093~200540423~Оплата Налог на доходы физических лиц (НДФЛ) за апрель 2026 г $TAX_ID$26124000090564", "counterpartyInn": "201122919", "counterpartyHint": "Казначейство Министерства финансов Республика Узбекистан"}	55c8b472-22c1-4648-bf9a-056ca0dfa1b9	\N	\N	OK
4be8d918-c3b3-4572-93ed-765b39198d36	228045b1-34d6-4a27-8034-8a9860ab013e	12c40a94-ca5e-4587-a825-336e0034921e	9ce804f2-c684-4282-9ffb-62a9a6f2cb8d	2026-05-31 00:00:00	POSTED	{"expenses": 0, "revenues": 3, "taxSummary": {"vat": 941614.27, "inputVat": 0, "incomeTax": 0, "outputVat": 941614.27, "turnoverTax": 0}, "totalEsfItems": 3}	\N	\N	\N	\N
0bd3a180-cd59-4ea4-92ea-f3e09d3df52f	228045b1-34d6-4a27-8034-8a9860ab013e	12c40a94-ca5e-4587-a825-336e0034921e	04ca266f-a8cb-4ffd-ac75-6ae68c6ace72	2026-05-04 00:00:00	POSTED	{"amount": 8758400, "vatAmount": 938400, "counterpartyInn": "308710993", "counterpartyHint": "\\"CASHGENICS\\" MCHJ"}	\N	\N	\N	OK
c6cba1dd-ce54-4cb2-8c74-2fd6d514da37	228045b1-34d6-4a27-8034-8a9860ab013e	12c40a94-ca5e-4587-a825-336e0034921e	04ca266f-a8cb-4ffd-ac75-6ae68c6ace72	2026-05-01 00:00:00	POSTED	{"amount": 10000, "vatAmount": 1071.42, "counterpartyInn": "312915680", "counterpartyHint": ""}	\N	\N	\N	OK
f45ceb7e-a022-4c72-b8dd-5d71d54492f8	228045b1-34d6-4a27-8034-8a9860ab013e	12c40a94-ca5e-4587-a825-336e0034921e	04ca266f-a8cb-4ffd-ac75-6ae68c6ace72	2026-05-16 00:00:00	POSTED	{"amount": 20000, "vatAmount": 2142.849999999999, "counterpartyInn": "312915680", "counterpartyHint": ""}	\N	\N	\N	OK
7d4683e1-8fe0-46d7-b92d-ae489a109a58	228045b1-34d6-4a27-8034-8a9860ab013e	12c40a94-ca5e-4587-a825-336e0034921e	285a86d8-bd31-4db1-974d-776806e52f09	2026-05-18 00:00:00	POSTED	{"amount": 9800, "direction": "CREDIT", "confirmedBy": "USER", "description": "00634Зачисление денежных средств поставщику \\"GP TECH UNION\\" MCHJ (ИНН: 312915680) от PAYME за 16-05-2026 за услуги или товары через UZCARD. С автоудержанем (Без оплат) 2% с поставщика CID: 6a057eec7e93e0c8ccbd6b71 EXT: 6a092aab96f1798a3ad5a0af MID: 69f9bb9fdb2327ee51ec9b20", "counterpartyInn": "312915680", "counterpartyHint": "Транзитный счёт для рассчёта с коммерсантами (Payme)"}	4d24f983-a951-4d9e-a6ab-54d6f8d823d9	\N	\N	OK
3fe7aafa-78ab-4d78-89a1-9294678c3503	228045b1-34d6-4a27-8034-8a9860ab013e	12c40a94-ca5e-4587-a825-336e0034921e	285a86d8-bd31-4db1-974d-776806e52f09	2026-05-18 00:00:00	POSTED	{"amount": 9800, "direction": "CREDIT", "confirmedBy": "USER", "description": "00668П/О, ОПЛАТА ЗА ТОВАРЫ, УСЛУГИ ЗА 16.05.2026 ПО СЕРВИСУ №101318 ОПЛАТА ЗА УСЛУГИ NAMO WALLET CОГ-НО ДОГ.№BI/D 30017\\\\TASH ОТ 2026-04-06 ЧЕРЕЗ CLICK. СУММА ПРОДАЖ 10000.00 СУМ. УДЕРЖАНО ОТ СУММЫ ПЛАТЕЖА: -КОМИССИЯ С ПЛАТЕЖА 200.00 СУМ;  . (№2361525, ОБЩ. СУММА 9800 UZS, ОТ 18.05.2026Г.)", "counterpartyInn": "302134733", "counterpartyHint": "\\"CLICK\\" AJ"}	b2a676ff-405a-433a-bd64-7f7fd32fc377	\N	\N	OK
b65d11bc-5cff-41d2-b472-57219d107a2f	228045b1-34d6-4a27-8034-8a9860ab013e	12c40a94-ca5e-4587-a825-336e0034921e	285a86d8-bd31-4db1-974d-776806e52f09	2026-05-04 00:00:00	POSTED	{"amount": 9800, "direction": "CREDIT", "confirmedBy": "USER", "description": "00668П/О, ОПЛАТА ЗА ТОВАРЫ, УСЛУГИ ЗА 02.05.2026 ПО СЕРВИСУ №101318 ОПЛАТА ЗА УСЛУГИ NAMO WALLET CОГ-НО ДОГ.№BI/D 30017\\\\TASH ОТ 2026-04-06 ЧЕРЕЗ CLICK. СУММА ПРОДАЖ 10000.00 СУМ. УДЕРЖАНО ОТ СУММЫ ПЛАТЕЖА: -КОМИССИЯ С ПЛАТЕЖА 200.00 СУМ;  . (№2151952, ОБЩ. СУММА 9800 UZS, ОТ 04.05.2026Г.)", "counterpartyInn": "302134733", "counterpartyHint": "\\"CLICK\\" AJ"}	000728fd-59c3-4672-bcb7-8877c1c5860e	\N	\N	OK
316bf16a-1bf7-44ce-8321-35a237c99395	228045b1-34d6-4a27-8034-8a9860ab013e	12c40a94-ca5e-4587-a825-336e0034921e	7d5bc76f-1bf4-4d51-9f41-bb19759698ee	2026-05-12 00:00:00	POSTED	{"amount": 27000, "direction": "DEBIT", "confirmedBy": "USER", "description": "00668 СЧЕТ НА ОПЛАТУ № 573749 от 11.05.2026 к Договору № ДХ-2848-05/26 от 11.05.2026", "counterpartyInn": "301551793", "counterpartyHint": "ООО \\"SUVAN NET\\""}	8e91b516-4f82-4c00-899e-1978c0e232ab	\N	\N	OK
78e4fdc3-f8d3-4994-aa1f-190e2cf23341	228045b1-34d6-4a27-8034-8a9860ab013e	12c40a94-ca5e-4587-a825-336e0034921e	98d89959-6f0c-4e37-8f4a-73f191630df3	2026-05-07 00:00:00	POSTED	{"amount": 22000000, "direction": "CREDIT", "confirmedBy": "USER", "description": "0066800668 Оплата 100% согл дог № 05052026-3 от 05.05.2026 за услуги по предоставлению лицензий на программное обеспечение Creative Cloud Pro for teams ALL Multiple Platforms", "counterpartyInn": "310332959", "counterpartyHint": "ИП ООО \\"SMART SOLUTIONS INTERNATIONAL\\""}	c7f5362e-e9dd-4c54-bbe6-9f8a4c0864ad	\N	\N	OK
2b3e652d-fb0e-4281-9400-80e74c9e4e88	228045b1-34d6-4a27-8034-8a9860ab013e	12c40a94-ca5e-4587-a825-336e0034921e	7d5bc76f-1bf4-4d51-9f41-bb19759698ee	2026-05-04 00:00:00	POSTED	{"amount": 317.5, "direction": "DEBIT", "confirmedBy": "USER", "description": "00717 Оплата Отчисление в ИНПС за апрель 2026 г $TAX_ID$26124000090370", "counterpartyInn": "200540423", "counterpartyHint": "Mirzo-Ulug`bek Tumani DSI boshlig`i USMANOV D.А."}	b3ef3e42-7c16-4009-8e0e-0443730245a5	\N	\N	OK
f2de3f2a-a296-4918-b407-7dd1c17de6aa	228045b1-34d6-4a27-8034-8a9860ab013e	12c40a94-ca5e-4587-a825-336e0034921e	1394e1a8-b539-48bb-95c9-2069b3f95ee8	2026-05-04 00:00:00	POSTED	{"amount": 38130, "direction": "DEBIT", "confirmedBy": "USER", "description": "08102~2001108606262693212160093~200540423~Оплата Социальный налог за апрель 2026 г $TAX_ID$26124000090434", "counterpartyInn": "201122919", "counterpartyHint": "Казначейство Министерства финансов Республика Узбекистан"}	b990a33f-588d-4043-a035-41b17fff4cfb	\N	\N	OK
be229a41-64c1-43e5-8059-e20e000adc71	228045b1-34d6-4a27-8034-8a9860ab013e	12c40a94-ca5e-4587-a825-336e0034921e	8fdc07dc-89f5-4d8e-81e4-ce54fb6dc7b0	2026-05-04 00:00:00	POSTED	{"amount": 2000000, "direction": "DEBIT", "confirmedBy": "USER", "description": "00647 Оплата аренды по договору № 3 01.04.2026й", "counterpartyInn": "310783571", "counterpartyHint": "VIDIMO MCHJ"}	f507ab1e-0774-425d-bf33-d5560b013039	\N	\N	OK
b2ce2456-49c1-422a-9191-17e76ed3c86d	228045b1-34d6-4a27-8034-8a9860ab013e	12c40a94-ca5e-4587-a825-336e0034921e	ba6d6bd5-788d-49b2-a9a5-4663d887a42c	2026-05-28 00:00:00	POSTED	{"type": "period_closing", "year": 2026, "month": 5}	\N	\N	\N	\N
7d1d1831-85dd-4a60-8dca-0c57933c315d	228045b1-34d6-4a27-8034-8a9860ab013e	7a927f44-73c4-42d6-a03e-73d32327dbc5	6c00d577-1c7a-4512-971c-91a3156659be	2026-06-24 00:00:00	POSTED	{"amount": 2200, "direction": "DEBIT", "confirmedBy": "USER", "description": "00111 BC 24.06.2026 погашение Дебет айланма(банкаро) -2200.00 от суммы 440000.00  от 24.06.2026", "counterpartyInn": "312915680", "counterpartyHint": "Начисленные %% GP TECH UNION"}	a2f84a5c-ff2f-4324-92f5-ae10c0e4843f	\N	\N	OK
91a3ebac-7df7-4486-b822-70297179e97e	228045b1-34d6-4a27-8034-8a9860ab013e	7a927f44-73c4-42d6-a03e-73d32327dbc5	6c00d577-1c7a-4512-971c-91a3156659be	2026-06-05 00:00:00	POSTED	{"amount": 150000, "direction": "DEBIT", "confirmedBy": "USER", "description": "00111 BC 05.06.2026 погашение Дебет айланма(ички) -150000.00 от суммы 30000000.00  от 05.06.2026", "counterpartyInn": "312915680", "counterpartyHint": "Начисленные %% GP TECH UNION"}	cd5d09ed-60f8-4180-b954-362bd3b1526c	\N	\N	OK
7b56f596-91c7-4e2c-818d-98435eab1dc0	228045b1-34d6-4a27-8034-8a9860ab013e	7a927f44-73c4-42d6-a03e-73d32327dbc5	f0f3b223-81ec-45c0-9727-3fc2c27dc855	2026-06-11 00:00:00	POSTED	{"amount": 33230131.2, "vatAmount": 3560371.2, "counterpartyInn": "311509237", "counterpartyHint": "\\"APN PROMISE ARAL\\" MCHJ XK"}	\N	\N	\N	OK
b1d210e7-b80d-4ea8-90a1-9ffebade3b93	228045b1-34d6-4a27-8034-8a9860ab013e	7a927f44-73c4-42d6-a03e-73d32327dbc5	6c00d577-1c7a-4512-971c-91a3156659be	2026-06-09 00:00:00	POSTED	{"amount": 58800, "direction": "DEBIT", "confirmedBy": "USER", "description": "00111 BC 09.06.2026 погашение Дебет айланма(банкаро) -58800.00 от суммы 11760000.00  от 09.06.2026", "counterpartyInn": "312915680", "counterpartyHint": "Начисленные %% GP TECH UNION"}	ef789af1-f043-4c0f-8520-9663a9592114	\N	\N	OK
d9ce31f7-dd4e-4c95-966b-773f593b0375	228045b1-34d6-4a27-8034-8a9860ab013e	7a927f44-73c4-42d6-a03e-73d32327dbc5	6c00d577-1c7a-4512-971c-91a3156659be	2026-06-11 00:00:00	POSTED	{"amount": 86150.66, "direction": "DEBIT", "confirmedBy": "USER", "description": "00111 BC 11.06.2026 погашение Дебет айланма(банкаро) -86150.66 от суммы 17230131.20  от 11.06.2026", "counterpartyInn": "312915680", "counterpartyHint": "Начисленные %% GP TECH UNION"}	b52b68a4-c939-410c-90da-3e32af40a1d9	\N	\N	OK
1a42d156-cfc7-42d4-8857-69eb740375bc	228045b1-34d6-4a27-8034-8a9860ab013e	7a927f44-73c4-42d6-a03e-73d32327dbc5	6c00d577-1c7a-4512-971c-91a3156659be	2026-06-19 00:00:00	POSTED	{"amount": 50000, "direction": "DEBIT", "confirmedBy": "USER", "description": "00111 BC 19.06.2026 погашение Дебет айланма(банкаро) -50000.00 от суммы 10000000.00  от 19.06.2026", "counterpartyInn": "312915680", "counterpartyHint": "Начисленные %% GP TECH UNION"}	91cfeae4-951c-414b-9f1f-3e17753b252b	\N	\N	OK
e7b9c4f6-4f29-473d-9773-4efb4e829728	228045b1-34d6-4a27-8034-8a9860ab013e	7a927f44-73c4-42d6-a03e-73d32327dbc5	6c00d577-1c7a-4512-971c-91a3156659be	2026-06-04 00:00:00	POSTED	{"amount": 150000, "direction": "DEBIT", "confirmedBy": "USER", "description": "00111 BC 04.06.2026 погашение Дебет айланма(ички) -150000.00 от суммы 30000000.00  от 04.06.2026", "counterpartyInn": "312915680", "counterpartyHint": "Начисленные %% GP TECH UNION"}	1c30e254-b8d6-48ca-bc5f-345e514f97ae	\N	\N	OK
a1003312-7511-483f-8163-1deb296f8e5c	228045b1-34d6-4a27-8034-8a9860ab013e	7a927f44-73c4-42d6-a03e-73d32327dbc5	6c00d577-1c7a-4512-971c-91a3156659be	2026-06-04 00:00:00	POSTED	{"amount": 1367296, "direction": "DEBIT", "confirmedBy": "USER", "description": "00111 BC 04.06.2026 погашение Дебет айланма(банкаро) -1367296.00 от суммы 273459200.00  от 04.06.2026", "counterpartyInn": "312915680", "counterpartyHint": "Начисленные %% GP TECH UNION"}	185bc366-dc2c-4711-9911-fc10c251381a	\N	\N	OK
89c82fc4-b714-4284-9feb-10e0555d3177	228045b1-34d6-4a27-8034-8a9860ab013e	7a927f44-73c4-42d6-a03e-73d32327dbc5	6c00d577-1c7a-4512-971c-91a3156659be	2026-06-04 00:00:00	POSTED	{"amount": 10000, "direction": "DEBIT", "confirmedBy": "USER", "description": "00111 BC 04.06.2026 погашение Дебет айланма(банкаро) -10000.00 от суммы 2000000.00  от 04.06.2026", "counterpartyInn": "312915680", "counterpartyHint": "Начисленные %% GP TECH UNION"}	41165517-fad6-4b4a-a231-9ea9fee47ce1	\N	\N	OK
21be39e8-aa00-4b16-906c-fe79c21d3e3b	228045b1-34d6-4a27-8034-8a9860ab013e	7a927f44-73c4-42d6-a03e-73d32327dbc5	7d5bc76f-1bf4-4d51-9f41-bb19759698ee	2026-06-24 00:00:00	POSTED	{"amount": 440000, "direction": "DEBIT", "confirmedBy": "USER", "description": "00098 Оплата за Карточка ф.100х140мм, бумага: 300гр/м2, печать: 4+4 + вырубка по контуру~~~", "counterpartyInn": "201535024", "counterpartyHint": "\\"SEAL MAG\\" AJ"}	0da87071-3bbc-4493-9182-23f68e323f4d	\N	\N	OK
f1791b1a-0bfc-400c-9174-bf34095b8ee1	228045b1-34d6-4a27-8034-8a9860ab013e	7a927f44-73c4-42d6-a03e-73d32327dbc5	98d89959-6f0c-4e37-8f4a-73f191630df3	2026-06-01 00:00:00	POSTED	{"amount": 12900000, "direction": "CREDIT", "confirmedBy": "USER", "description": "00111П/О, 01.06.2026ЙИЛДАГИ ШАРТНОМА№ №1062026-1ГА АСОСАН  GOOGLE ISH  MAYDONI BIZNES BOSHLANG`ICH - 10 FOYDALANUVCHI UCHUN 12 OY УЧУН ТУЛОВ.. (№1213, ОБЩ. СУММА 12900000 UZS, ОТ 01.06.2026Г.)", "counterpartyInn": "311010005", "counterpartyHint": "\\"MEGATON\\" MCHJ"}	70b2e66e-6209-4f63-9ccc-99543c3a09a6	\N	\N	OK
01b8648a-010f-42a3-b6ec-54288965b3d2	228045b1-34d6-4a27-8034-8a9860ab013e	7a927f44-73c4-42d6-a03e-73d32327dbc5	98d89959-6f0c-4e37-8f4a-73f191630df3	2026-06-16 00:00:00	POSTED	{"amount": 3244000, "direction": "CREDIT", "confirmedBy": "USER", "description": "00098 Предоплата 100% за программное обеспечение Kaspersky Small согл. дог. №15062026-1 от 15.06.26г. В т.ч. НДС.", "counterpartyInn": "200642271", "counterpartyHint": "ООО \\"CENTRAL ASIA MEGASTAR\\" - основной депозитный счет до востребовани"}	a2c05b22-289a-4139-acbb-4c4a19d50009	\N	\N	OK
68431629-82a5-4424-8513-0a353d73847a	228045b1-34d6-4a27-8034-8a9860ab013e	7a927f44-73c4-42d6-a03e-73d32327dbc5	9fedca31-2b1e-4a52-81cf-0038aff3697b	2026-06-02 00:00:00	POSTED	{"amount": 3000000, "direction": "DEBIT", "confirmedBy": "USER", "description": "00111 Залог по ИНН 312915680 GP TECH UNION", "counterpartyInn": "312915680", "counterpartyHint": "АО Узбекская Республиканская товарно-сырьевая биржа"}	f51e607d-6e71-4489-9a24-e212106915f8	\N	\N	OK
affdb512-06c1-4966-ae81-2be136f20bde	228045b1-34d6-4a27-8034-8a9860ab013e	7a927f44-73c4-42d6-a03e-73d32327dbc5	04ca266f-a8cb-4ffd-ac75-6ae68c6ace72	2026-06-04 00:00:00	POSTED	{"amount": 5376000, "vatAmount": 576000, "counterpartyInn": "312384465", "counterpartyHint": "\\"CALLIE LIMITED\\" MCHJ"}	\N	\N	\N	OK
03e09997-e6b7-4ce0-8dad-6a8f2111b944	228045b1-34d6-4a27-8034-8a9860ab013e	7a927f44-73c4-42d6-a03e-73d32327dbc5	04ca266f-a8cb-4ffd-ac75-6ae68c6ace72	2026-06-19 00:00:00	POSTED	{"amount": 3244000, "vatAmount": 347571.4300000002, "counterpartyInn": "200642271", "counterpartyHint": "\\"CENTRAL ASIA MEGASTAR\\" MCHJ"}	\N	\N	\N	OK
20968e04-8198-489b-9bf2-0c2137596932	228045b1-34d6-4a27-8034-8a9860ab013e	7a927f44-73c4-42d6-a03e-73d32327dbc5	bc137b43-5986-4ac0-afa5-51eb8f0cbf67	2026-06-12 00:00:00	POSTED	{"amount": 3000000, "direction": "CREDIT", "confirmedBy": "USER", "description": "00658 Возврат д/с с лиц/счета №20-10-01-0613342-860-001, согл поручения клиента от с перс кабинета 312915680 ?GP TECH UNION MCHJ?", "counterpartyInn": "200933985", "counterpartyHint": "AO UZRTSB"}	96bd0766-7f55-45ae-8b90-6497235f57e0	\N	\N	OK
077b80f7-1e33-45f9-9e92-81dc082d6a78	228045b1-34d6-4a27-8034-8a9860ab013e	7a927f44-73c4-42d6-a03e-73d32327dbc5	b3d509bf-6bbe-46fb-84c7-e5169969ba0b	2026-06-19 00:00:00	POSTED	{"amount": 10000000, "direction": "DEBIT", "confirmedBy": "USER", "description": "00111 Оплата залога ИНН: 312915680", "counterpartyInn": "312915680", "counterpartyHint": "АО Узбекская Республиканская товарно-сырьевая биржа"}	365bd283-77e9-4cd7-a8b7-a986d24bb36f	\N	\N	OK
bdd58d95-d287-401f-8d36-56a41b35faa0	228045b1-34d6-4a27-8034-8a9860ab013e	7a927f44-73c4-42d6-a03e-73d32327dbc5	a8764508-ec8a-49ab-b12f-f18f38dd6493	2026-06-05 00:00:00	POSTED	{"amount": 30000000, "direction": "DEBIT", "confirmedBy": "USER", "description": "00634 ОПЛАТА ПО ДОГОВОРУ ССУДЫ 18052026-1С от 18.05.2026 НА КАРТУ ДИР 5614682900908783 BURANOV AXMADJON", "counterpartyInn": "207086151", "counterpartyHint": "ORIENT FINANS BANK"}	4d9540a9-c177-41f0-9983-ab9a5d96c474	\N	\N	OK
5506b7cd-c391-49ec-8b80-36fb8c102c5e	228045b1-34d6-4a27-8034-8a9860ab013e	7a927f44-73c4-42d6-a03e-73d32327dbc5	a8764508-ec8a-49ab-b12f-f18f38dd6493	2026-06-04 00:00:00	POSTED	{"amount": 30000000, "direction": "DEBIT", "confirmedBy": "USER", "description": "00634 ОПЛАТА ПО ДОГОВОРУ ССУДЫ 18052026-1С от 18.05.2026 НА КАРТУ ДИР 5614682900908783 BURANOV AXMADJON", "counterpartyInn": "207086151", "counterpartyHint": "ORIENT FINANS BANK"}	2a8c969d-9efe-4a87-b837-7208144f149c	\N	\N	OK
7b65e3d5-7721-4e6b-ad83-8e745596fdf4	228045b1-34d6-4a27-8034-8a9860ab013e	7a927f44-73c4-42d6-a03e-73d32327dbc5	98d89959-6f0c-4e37-8f4a-73f191630df3	2026-06-05 00:00:00	POSTED	{"amount": 69090000, "direction": "CREDIT", "confirmedBy": "USER", "description": "42110Оплата по договору №05062026-1 от 04.06.2026г  Microsoft 365 Business Standart. Рапорт №12-04/922 от 04.06.2026", "counterpartyInn": "202288236", "counterpartyHint": "\\"KAFOLAT SUGURTA KOMPANIYASI AJ\\""}	8906a42c-2fd5-4be9-89bc-156b5d3737c8	\N	\N	OK
d9882e12-e27a-4f4d-beeb-a5b4102befc6	228045b1-34d6-4a27-8034-8a9860ab013e	7a927f44-73c4-42d6-a03e-73d32327dbc5	98d89959-6f0c-4e37-8f4a-73f191630df3	2026-06-04 00:00:00	POSTED	{"amount": 5376000, "direction": "CREDIT", "confirmedBy": "USER", "description": "0011100111 За услуги приобретения лицензий на программное обеспечение Microsoft Windows 11 Professional Retail  сог. дог. № 04062026-1 от 04.06.2027г. Предоплата 100%.", "counterpartyInn": "312384465", "counterpartyHint": "ООО CALLIE LIMITED"}	c6c32e37-eefa-4e99-a69a-96703f458c35	\N	\N	OK
b0b6bda9-3e50-483f-96e1-68599833266f	228045b1-34d6-4a27-8034-8a9860ab013e	7a927f44-73c4-42d6-a03e-73d32327dbc5	11153a82-fa3f-4228-9376-e6ba3e88a335	2026-06-01 00:00:00	POSTED	{"amount": 864586.29, "direction": "DEBIT", "confirmedBy": "USER", "description": "08102~1000228609262693141102093~200540423~Оплата Налог на добавленную стоимость за май 2026 г $TAX_ID$26152000706734", "counterpartyInn": "201122919", "counterpartyHint": "Казначейство Министерства финансов Республика Узбекистан"}	4402e5e0-04e4-4fd5-a065-40c1a4752038	\N	\N	OK
53761d90-2d33-4fe6-ae87-ba0ffd3c1264	228045b1-34d6-4a27-8034-8a9860ab013e	7a927f44-73c4-42d6-a03e-73d32327dbc5	11153a82-fa3f-4228-9376-e6ba3e88a335	2026-06-01 00:00:00	POSTED	{"amount": 37812.25, "direction": "DEBIT", "confirmedBy": "USER", "description": "08102~1000218604262693111103093~200540423~Оплата Налог на доходы физических лиц (НДФЛ) за май 2026 г $TAX_ID$26152000707678", "counterpartyInn": "201122919", "counterpartyHint": "Казначейство Министерства финансов Республика Узбекистан"}	e1c5e1f8-2469-4c46-9e15-48c59065428d	\N	\N	OK
cf27399b-5ba6-4d9c-a193-aed14256a4af	228045b1-34d6-4a27-8034-8a9860ab013e	7a927f44-73c4-42d6-a03e-73d32327dbc5	11153a82-fa3f-4228-9376-e6ba3e88a335	2026-06-01 00:00:00	POSTED	{"amount": 38130, "direction": "DEBIT", "confirmedBy": "USER", "description": "08102~2001108606262693212160093~200540423~Оплата Социальный налог за май 2026 г. $TAX_ID$26152000707144", "counterpartyInn": "201122919", "counterpartyHint": "Казначейство Министерства финансов Республика Узбекистан"}	595a4c57-19cc-4b29-a3db-2cfb7b421f52	\N	\N	OK
a67fe804-1e2b-4797-8e39-d7131fbef04b	228045b1-34d6-4a27-8034-8a9860ab013e	7a927f44-73c4-42d6-a03e-73d32327dbc5	8fdc07dc-89f5-4d8e-81e4-ce54fb6dc7b0	2026-06-04 00:00:00	POSTED	{"amount": 2000000, "direction": "DEBIT", "confirmedBy": "USER", "description": "00647 Оплата аренды по договору № 3 01.04.2026й", "counterpartyInn": "310783571", "counterpartyHint": "VIDIMO MCHJ"}	4eee711b-7df4-4381-9f96-881b2ae311e1	\N	\N	OK
550d7573-4c1f-47b7-8e1d-e141883d295d	228045b1-34d6-4a27-8034-8a9860ab013e	7a927f44-73c4-42d6-a03e-73d32327dbc5	6c00d577-1c7a-4512-971c-91a3156659be	2026-06-03 00:00:00	POSTED	{"amount": 540, "direction": "DEBIT", "confirmedBy": "USER", "description": "00111 BC 03.06.2026 погашение Дебет айланма(банкаро) -540.00 от суммы 108000.00  от 03.06.2026", "counterpartyInn": "312915680", "counterpartyHint": "Начисленные %% GP TECH UNION"}	0c2dcb1a-f801-4835-9e1b-0bdde11dd2d9	\N	\N	OK
41de570d-fbc4-456a-a719-283eb13c744d	228045b1-34d6-4a27-8034-8a9860ab013e	7a927f44-73c4-42d6-a03e-73d32327dbc5	7d5bc76f-1bf4-4d51-9f41-bb19759698ee	2026-06-01 00:00:00	POSTED	{"amount": 317.5, "direction": "DEBIT", "confirmedBy": "USER", "description": "00717 Оплата Отчисление в ИНПС за май 2026 г $TAX_ID$26152000707018", "counterpartyInn": "200540423", "counterpartyHint": "Mirzo-Ulug`bek Tumani DSI boshlig`i USMANOV D.А."}	91f41346-ab8a-43f6-9ccd-e296f2e94946	\N	\N	OK
cb806713-eb7e-4d54-bdda-1275cdfd268a	228045b1-34d6-4a27-8034-8a9860ab013e	7a927f44-73c4-42d6-a03e-73d32327dbc5	6c00d577-1c7a-4512-971c-91a3156659be	2026-06-02 00:00:00	POSTED	{"amount": 15000, "direction": "DEBIT", "confirmedBy": "USER", "description": "00111 BC 02.06.2026 погашение Дебет айланма(банкаро) -15000.00 от суммы 3000000.00  от 02.06.2026", "counterpartyInn": "312915680", "counterpartyHint": "Начисленные %% GP TECH UNION"}	50716515-cb7d-4a00-8fce-877fe053ea29	\N	\N	OK
e83e6bc6-2603-4e58-a51d-d69857399d3b	228045b1-34d6-4a27-8034-8a9860ab013e	7a927f44-73c4-42d6-a03e-73d32327dbc5	98d89959-6f0c-4e37-8f4a-73f191630df3	2026-06-03 00:00:00	POSTED	{"amount": 292640000, "direction": "CREDIT", "confirmedBy": "USER", "description": "00111Каспер по дог.№21052026-1 от 21.05.2026г.", "counterpartyInn": "303303592", "counterpartyHint": "GRAND  PHARM  TRADE MCHJ"}	08d55234-48e5-4025-b0de-dc41c7127520	\N	\N	OK
aae08362-44ef-44be-90db-010c074c39c7	228045b1-34d6-4a27-8034-8a9860ab013e	7a927f44-73c4-42d6-a03e-73d32327dbc5	7d5bc76f-1bf4-4d51-9f41-bb19759698ee	2026-06-03 00:00:00	POSTED	{"amount": 108000, "direction": "DEBIT", "confirmedBy": "USER", "description": "00103 СЧЕТ НА ОПЛАТУ № 581649 от 03.06.2026 к Договору № ДХ-2848-05/26 от 11.05.2026", "counterpartyInn": "301551793", "counterpartyHint": "ООО \\"SUVAN NET\\""}	baf548b1-d4cd-471b-8e22-e421e0b4a600	\N	\N	OK
22279663-8304-4d9a-bec2-57c05916f20f	228045b1-34d6-4a27-8034-8a9860ab013e	7a927f44-73c4-42d6-a03e-73d32327dbc5	9ce804f2-c684-4282-9ffb-62a9a6f2cb8d	2026-06-30 00:00:00	POSTED	{"expenses": 3, "revenues": 2, "taxSummary": {"vat": -33195999.77, "inputVat": 34119571.2, "incomeTax": 0, "outputVat": 923571.4300000002, "turnoverTax": 0}, "totalEsfItems": 5}	\N	\N	\N	\N
34dadae4-87ee-4ee0-9e84-dc7b95a1587b	228045b1-34d6-4a27-8034-8a9860ab013e	7a927f44-73c4-42d6-a03e-73d32327dbc5	56015255-3d79-4d7f-8058-7ab53527ac13	2026-06-04 00:00:00	POSTED	{"amount": 273459200, "vatAmount": 29299200, "counterpartyInn": "305774212", "counterpartyHint": "\\"AXOFT\\" MCHJ"}	\N	\N	\N	OK
3c9de340-150a-4e66-8913-55b583fc3309	228045b1-34d6-4a27-8034-8a9860ab013e	7a927f44-73c4-42d6-a03e-73d32327dbc5	e6b9d9c6-c670-49df-a165-3afeb98e56a4	2026-06-28 00:00:00	POSTED	{"salaryAmount": 4000000, "expenseAccountCode": "9420"}	\N	\N	\N	OK
7373fd1c-0fb0-41ce-bfc1-b11797f2851c	228045b1-34d6-4a27-8034-8a9860ab013e	7a927f44-73c4-42d6-a03e-73d32327dbc5	df64c86e-6372-4549-a24d-8f2bc3c28254	2026-06-28 00:00:00	POSTED	{"amount": 3520000, "description": "Зачёт нетто-зарплаты в счёт займов"}	\N	\N	\N	OK
15207693-c1bc-412a-a894-117e37e82294	228045b1-34d6-4a27-8034-8a9860ab013e	7a927f44-73c4-42d6-a03e-73d32327dbc5	ba6d6bd5-788d-49b2-a9a5-4663d887a42c	2026-06-28 00:00:00	POSTED	{"type": "period_closing", "year": 2026, "month": 6}	\N	\N	\N	\N
48ed7424-5e3c-4432-88e6-04b225b5598c	228045b1-34d6-4a27-8034-8a9860ab013e	7a927f44-73c4-42d6-a03e-73d32327dbc5	56015255-3d79-4d7f-8058-7ab53527ac13	2026-06-10 00:00:00	POSTED	{"amount": 11760000, "vatAmount": 1260000, "counterpartyInn": "311149962", "counterpartyHint": "\\"SOFTPROM\\" MCHJ"}	\N	\N	\N	OK
af31e6c4-e24e-4565-baa5-438168e57987	228045b1-34d6-4a27-8034-8a9860ab013e	7f6821e4-96d7-4c4f-82e9-713c49232527	0e155225-1f9f-48ce-b303-a1c8852453d8	2026-04-28 00:00:00	POSTED	{"amount": 718928, "direction": "DEBIT", "confirmedBy": "USER", "description": "00668 Оплата по счету №Af000010849 от 28.04.2026", "counterpartyInn": "305774212", "counterpartyHint": "AXOFT MCHJ"}	e30751aa-4e37-440b-ae93-fe6eab405f56	\N	\N	OK
d3b7b6ff-39ed-4f60-b72a-cb0f5ef56e51	228045b1-34d6-4a27-8034-8a9860ab013e	7a927f44-73c4-42d6-a03e-73d32327dbc5	0e155225-1f9f-48ce-b303-a1c8852453d8	2026-06-09 00:00:00	POSTED	{"amount": 11760000, "direction": "DEBIT", "confirmedBy": "USER", "description": "00112 Оплата за Google Workspace Business Starter -1 Y (12 месяцев) по Договору №2026-37", "counterpartyInn": "311149962", "counterpartyHint": "SOFTPROM MCHJ"}	de11b2de-3c6b-4209-8f24-a38e9e860de6	\N	\N	OK
ac054429-ae2a-4031-8118-ff6aee3e0307	228045b1-34d6-4a27-8034-8a9860ab013e	7a927f44-73c4-42d6-a03e-73d32327dbc5	0e155225-1f9f-48ce-b303-a1c8852453d8	2026-06-11 00:00:00	POSTED	{"amount": 17230131.2, "direction": "DEBIT", "confirmedBy": "USER", "description": "00112 Оплата CFQ7TTC0LDPB:0001:YY Microsoft 365 Business Standard № 81 от 11.06.2026 к договору № 41 от 08.06.2026", "counterpartyInn": "311509237", "counterpartyHint": "APN PROMISE ARAL MCHJ XK"}	1afab132-9ec0-48c0-b402-a6a8bc135233	\N	\N	OK
821ff739-ceb3-468b-a469-3188c9c2adfe	228045b1-34d6-4a27-8034-8a9860ab013e	7a927f44-73c4-42d6-a03e-73d32327dbc5	0e155225-1f9f-48ce-b303-a1c8852453d8	2026-06-04 00:00:00	POSTED	{"amount": 273459200, "direction": "DEBIT", "confirmedBy": "USER", "description": "00103 Оплата по счету №Af000011293 от 04.06.2026", "counterpartyInn": "305774212", "counterpartyHint": "AXOFT MCHJ"}	9ca5b2c3-d34d-46d7-98b8-4dad81583ce5	\N	\N	OK
\.


--
-- Data for Name: DocumentType; Type: TABLE DATA; Schema: public; Owner: user
--

COPY public."DocumentType" (id, code, name, "postingTemplate", mode) FROM stdin;
6e95fc1c-fb1a-4026-82e3-b74cff0814ad	REVENUE_VAT	Продажа с документами (с НДС)	{"lines": [{"side": "debit", "expression": "amount", "accountCode": "5110"}, {"side": "credit", "expression": "amount / 1.12", "accountCode": "9030"}, {"side": "credit", "expression": "amount - (amount / 1.12)", "accountCode": "6410"}], "opensItem": false, "requiresCounterparty": true}	MANUAL_ONLY
98d89959-6f0c-4e37-8f4a-73f191630df3	ADVANCE_RECEIVED	Предоплата от клиента (Доход)	{"lines": [{"side": "debit", "expression": "amount", "accountCode": "5110"}, {"side": "credit", "expression": "amount", "accountCode": "6310"}], "opensItem": true, "itemAccountCode": "6310", "requiresCounterparty": true}	BANK_AUTO
45c41496-e779-4de2-941b-a4aba02421b8	SUPPLIER_PAYMENT	Оплата поставщику (погашение долга, устаревший тип)	{"lines": [{"side": "debit", "expression": "amount", "accountCode": "6010"}, {"side": "credit", "expression": "amount", "accountCode": "5110"}], "opensItem": false, "requiresCounterparty": true, "closesOpenItemByAccount": "6010"}	MANUAL_ONLY
2567ac1f-a1ff-4eaf-ba77-5fc14c4fae6d	ADVANCE_PAID	Предоплата поставщику (Расход)	{"lines": [{"side": "debit", "expression": "amount", "accountCode": "4310"}, {"side": "credit", "expression": "amount", "accountCode": "5110"}], "opensItem": true, "itemAccountCode": "4310", "requiresCounterparty": true}	BANK_AUTO
bfc58c65-2aa0-4c4b-bfd4-da248f324770	ACCOUNTABLE	Деньги под отчёт — командировка (Расход)	{"lines": [{"side": "debit", "expression": "amount", "accountCode": "4220"}, {"side": "credit", "expression": "amount", "accountCode": "5110"}], "opensItem": true, "itemAccountCode": "4220", "requiresCounterparty": false}	BANK_AUTO
a945e1d9-4ba7-4f05-a073-4f7b82fe1f30	FOUNDER_LOAN	Займ от учредителя (Доход)	{"lines": [{"side": "debit", "expression": "amount", "accountCode": "5110"}, {"side": "credit", "expression": "amount", "accountCode": "6820"}], "opensItem": true, "itemAccountCode": "6820", "requiresCounterparty": true}	BANK_AUTO
b27b7867-2620-4521-8c5f-8acb6f678656	DEPRECIATION_ACCRUAL	Начисление амортизации ОС	{"lines": [{"side": "debit", "expression": "depreciationAmount", "accountCode": "9420"}, {"side": "credit", "expression": "depreciationAmount", "accountCode": "0200"}], "opensItem": false, "requiresCounterparty": false}	MANUAL_ONLY
7b8245ba-43c5-4bd0-913b-3f05dec2f7fb	PROFIT_TAX_REVERSAL	Сторно налога на прибыль (уменьшение нарастающим итогом)	{"lines": [{"side": "debit", "expression": "taxAmount", "accountCode": "6410"}, {"side": "credit", "expression": "taxAmount", "accountCode": "9810"}], "opensItem": false, "requiresCounterparty": false}	MANUAL_ONLY
8fdc07dc-89f5-4d8e-81e4-ce54fb6dc7b0	RENT	Аренда — прямая оплата (Расход)	{"lines": [{"side": "debit", "expression": "amount", "accountCode": "9420"}, {"side": "credit", "expression": "amount", "accountCode": "5110"}], "opensItem": false, "requiresCounterparty": true}	BANK_AUTO
5cf28009-7426-4b97-9037-e859ee0133f6	GRATUITOUS_RECEIPT_IA	Безвозмездное получение нематериальных активов	{"lines": [{"side": "debit", "expression": "amount", "accountCode": "$assetAccountCode"}, {"side": "credit", "expression": "amount", "accountCode": "8530"}], "opensItem": false, "requiresCounterparty": false}	MANUAL_ONLY
6cb0918e-8051-4dbe-a8da-62d803a9bd8f	REFUND	Возврат денег клиенту (Расход)	{"lines": [{"side": "debit", "expression": "amount", "accountCode": "9040"}, {"side": "credit", "expression": "amount", "accountCode": "5110"}], "opensItem": false, "requiresCounterparty": true}	BANK_AUTO
b3d509bf-6bbe-46fb-84c7-e5169969ba0b	DEPOSIT	Гарантийный депозит выдан (Расход)	{"lines": [{"side": "debit", "expression": "amount", "accountCode": "4890"}, {"side": "credit", "expression": "amount", "accountCode": "5110"}], "opensItem": true, "itemAccountCode": "4890", "requiresCounterparty": true}	BANK_AUTO
95c6c9eb-ae43-4832-8a42-8bf5c51fb358	GRATUITOUS_RECEIPT_MATERIALS	Безвозмездное получение материалов	{"lines": [{"side": "debit", "expression": "amount", "accountCode": "1010"}, {"side": "credit", "expression": "amount", "accountCode": "8530"}], "opensItem": false, "requiresCounterparty": false}	MANUAL_ONLY
72f3e73c-280d-4b24-80de-967e80e10af1	GRATUITOUS_RECEIPT_FA	Безвозмездное получение основных средств	{"lines": [{"side": "debit", "expression": "amount", "accountCode": "$assetAccountCode"}, {"side": "credit", "expression": "amount", "accountCode": "8530"}], "opensItem": false, "requiresCounterparty": false}	MANUAL_ONLY
38adc9a4-4456-4205-ac8c-28532bee4481	ADVERTISING	Реклама и маркетинг (Расход)	{"lines": [{"side": "debit", "expression": "amount", "accountCode": "9410"}, {"side": "credit", "expression": "amount", "accountCode": "5110"}], "opensItem": false, "requiresCounterparty": true}	BANK_AUTO
afcaecde-a23f-4392-8733-909304ea93eb	INVENTORY_SURPLUS	Излишки при инвентаризации	{"lines": [{"side": "debit", "expression": "amount", "accountCode": "$assetAccountCode"}, {"side": "credit", "expression": "amount", "accountCode": "9390"}], "opensItem": false, "requiresCounterparty": false}	MANUAL_ONLY
5ad2832d-1f93-4a49-b670-91628fae645c	INVENTORY_SHORTAGE	Недостача при инвентаризации	{"lines": [{"side": "debit", "expression": "amount", "accountCode": "5910"}, {"side": "credit", "expression": "amount", "accountCode": "$assetAccountCode"}], "opensItem": false, "requiresCounterparty": false}	MANUAL_ONLY
cb938696-fdb4-4a45-9fab-d294cc36e6cd	RENT_ACCRUAL	Начисление аренды (без оплаты)	{"lines": [{"side": "debit", "expression": "rentAmount", "accountCode": "9420"}, {"side": "credit", "expression": "rentAmount", "accountCode": "6010"}], "opensItem": false, "requiresCounterparty": false}	MANUAL_ONLY
e8da3c18-8819-43ed-bbe5-6425339b7ef4	FX_DIFFERENCE	Курсовая разница валютных счетов	{"lines": [{"side": "debit", "condition": "fxDifference > 0", "expression": "fxDifference", "accountCode": "$fxAccountCode"}, {"side": "credit", "condition": "fxDifference > 0", "expression": "fxDifference", "accountCode": "9540"}, {"side": "debit", "condition": "fxDifference < 0", "expression": "-fxDifference", "accountCode": "9620"}, {"side": "credit", "condition": "fxDifference < 0", "expression": "-fxDifference", "accountCode": "$fxAccountCode"}], "opensItem": false, "requiresCounterparty": false}	MANUAL_ONLY
1394e1a8-b539-48bb-95c9-2069b3f95ee8	SOCIAL_TAX_PAYMENT	Социальный налог с ФОТ (Расход)	{"lines": [{"side": "debit", "expression": "amount", "accountCode": "6520"}, {"side": "credit", "expression": "amount", "accountCode": "5110"}], "opensItem": false, "requiresCounterparty": false}	BANK_AUTO
2867a25b-060a-4aab-9c0e-3508c653d392	PROFIT_TAX_ACCRUAL	Начисление налога на прибыль	{"lines": [{"side": "debit", "expression": "taxAmount", "accountCode": "9810"}, {"side": "credit", "expression": "taxAmount", "accountCode": "6410"}], "opensItem": false, "requiresCounterparty": false}	MANUAL_ONLY
ba6d6bd5-788d-49b2-a9a5-4663d887a42c	PERIOD_CLOSING	Закрытие счетов доходов и расходов (реформация баланса)	{"lines": [], "opensItem": false, "requiresCounterparty": false}	MANUAL_ONLY
85113bb1-703c-41a8-a2b3-a59aac5b2aa8	GRATUITOUS_RECEIPT_GOODS	Безвозмездное получение товаров	{"lines": [{"side": "debit", "expression": "amount", "accountCode": "2910"}, {"side": "credit", "expression": "amount", "accountCode": "8530"}], "opensItem": false, "requiresCounterparty": false}	MANUAL_ONLY
9ce804f2-c684-4282-9ffb-62a9a6f2cb8d	SOLIQ_IMPORT	Импорт отчёта Soliq	{}	BANK_AUTO
75855d34-4ec8-41e9-8d12-66733ca71b3f	REVENUE_COLLECTION	Оплата от клиента — постоплата (Доход)	{"lines": [{"side": "debit", "expression": "amount", "accountCode": "5110"}, {"side": "credit", "expression": "amount", "accountCode": "4010"}], "opensItem": false, "requiresCounterparty": true, "closesOpenItemByAccount": "4010"}	BANK_AUTO
6938b725-6c85-4e0b-bc72-dae2793bc4fb	GRATUITOUS_RECEIPT_SECURITIES	Безвозмездное получение ценных бумаг	{"lines": [{"side": "debit", "expression": "amount", "accountCode": "0610"}, {"side": "credit", "expression": "amount", "accountCode": "8530"}], "opensItem": false, "requiresCounterparty": false}	MANUAL_ONLY
0e155225-1f9f-48ce-b303-a1c8852453d8	SUPPLIER_PAYMENT_GOODS	Оплата поставщику за товары (Расход)	{"lines": [{"side": "debit", "expression": "amount", "accountCode": "6010"}, {"side": "credit", "expression": "amount", "accountCode": "5110"}], "opensItem": false, "requiresCounterparty": true, "closesOpenItemByAccount": "6010"}	BANK_AUTO
cd2a96fb-c439-4311-8afb-b9d1927c5dc0	SUPPLIER_PAYMENT_VAT	Оплата поставщику — НДС (Расход)	{"lines": [{"side": "debit", "expression": "amount", "accountCode": "6010"}, {"side": "credit", "expression": "amount", "accountCode": "5110"}], "opensItem": false, "requiresCounterparty": true, "closesOpenItemByAccount": "6010"}	BANK_AUTO
56015255-3d79-4d7f-8058-7ab53527ac13	GOODS_RECEIVED_PREPAID	Поступление товаров — в счёт аванса	{"lines": [{"side": "debit", "expression": "amount - vatAmount", "accountCode": "2910"}, {"side": "debit", "condition": "vatAmount > 0", "expression": "vatAmount", "accountCode": "4410"}, {"side": "credit", "expression": "amount", "accountCode": "4310"}], "opensItem": false, "requiresCounterparty": true, "closesOpenItemByAccount": "4310"}	MANUAL_ONLY
6c00d577-1c7a-4512-971c-91a3156659be	BANK_COMMISSION	Комиссия банка (Расход)	{"lines": [{"side": "debit", "expression": "amount", "accountCode": "9430"}, {"side": "credit", "expression": "amount", "accountCode": "5110"}], "opensItem": false, "requiresCounterparty": false}	BANK_AUTO
43f8923b-0b94-4977-8426-67b392838053	SUPPLIER_REFUND	Возврат денег от поставщика (Доход)	{"lines": [{"side": "debit", "expression": "amount", "accountCode": "5110"}, {"side": "credit", "expression": "amount", "accountCode": "4310"}], "opensItem": false, "requiresCounterparty": true, "closesOpenItemByAccount": "4310"}	BANK_AUTO
89abafb9-ebe1-4a11-84b5-3f5d4d699235	EMPLOYEE_LOAN_REPAYMENT	Сотрудник вернул займ (Доход)	{"lines": [{"side": "debit", "expression": "amount", "accountCode": "5110"}, {"side": "credit", "expression": "amount", "accountCode": "4720"}], "opensItem": false, "requiresCounterparty": false}	BANK_AUTO
e1166d4e-3b9f-4226-9714-0a8d95389d06	SERVICE_RECEIVED_PREPAID	Получение услуги — в счёт аванса	{"lines": [{"side": "debit", "expression": "amount - vatAmount", "accountCode": "9420"}, {"side": "debit", "condition": "vatAmount > 0", "expression": "vatAmount", "accountCode": "4410"}, {"side": "credit", "expression": "amount", "accountCode": "4310"}], "opensItem": false, "requiresCounterparty": true, "closesOpenItemByAccount": "4310"}	MANUAL_ONLY
285a86d8-bd31-4db1-974d-776806e52f09	MARKETPLACE_INCOME	Поступление от маркетплейса (Доход)	{"lines": [{"side": "debit", "expression": "amount", "accountCode": "5110"}, {"side": "credit", "expression": "amount", "accountCode": "4890"}], "opensItem": true, "itemAccountCode": "4890", "requiresCounterparty": true}	BANK_AUTO
d84f4032-b2a8-48aa-ba3d-143929e340f7	INVOICE_CONFIRMED	ЭСФ подтверждён — постоплата	{"lines": [{"side": "debit", "expression": "amount", "accountCode": "4010"}, {"side": "credit", "expression": "amount - vatAmount", "accountCode": "9030"}, {"side": "credit", "condition": "vatAmount > 0", "expression": "vatAmount", "accountCode": "6410"}], "opensItem": true, "itemAccountCode": "4010", "requiresCounterparty": true}	MANUAL_ONLY
dceb6d0a-046c-47cc-a7ec-2c16b9f091a5	INVENTORY_SHORTAGE_RESOLUTION	Списание недостачи	{"lines": [{"side": "debit", "condition": "hasCulprit", "expression": "amount", "accountCode": "4730"}, {"side": "debit", "condition": "!hasCulprit", "expression": "amount", "accountCode": "9430"}, {"side": "credit", "expression": "amount", "accountCode": "5910"}], "opensItem": false, "requiresCounterparty": false}	MANUAL_ONLY
789ecb1a-abfa-4728-9274-0758869b2137	SUPPLIER_PAYMENT_OTHER	Оплата поставщику — прочее (Расход)	{"lines": [{"side": "debit", "expression": "amount", "accountCode": "6010"}, {"side": "credit", "expression": "amount", "accountCode": "5110"}], "opensItem": false, "requiresCounterparty": true, "closesOpenItemByAccount": "6010"}	BANK_AUTO
06642c1a-54a8-4f0d-928f-5ea90fdfc665	FIXED_ASSET_PURCHASE	Покупка оборудования (Расход)	{"lines": [{"side": "debit", "expression": "amount", "accountCode": "0820"}, {"side": "credit", "expression": "amount", "accountCode": "5110"}], "opensItem": false, "requiresCounterparty": true}	BANK_AUTO
dccb7bbe-3f72-4242-816a-b1c732407a76	RESERVE_CAPITAL_FORMATION	Формирование резервного капитала	{"lines": [{"side": "debit", "expression": "amount", "accountCode": "8710"}, {"side": "credit", "expression": "amount", "accountCode": "8520"}], "opensItem": false, "requiresCounterparty": false}	MANUAL_ONLY
cb9fb490-41d5-4083-871c-3d1bc514e7df	UTILITY_PAYMENT	Коммунальные услуги (Расход)	{"lines": [{"side": "debit", "expression": "amount", "accountCode": "9420"}, {"side": "credit", "expression": "amount", "accountCode": "5110"}], "opensItem": false, "requiresCounterparty": true}	BANK_AUTO
b5dcfe43-b75b-4720-806d-ae047637f9aa	SERVICE_RECEIVED	Получение услуги — в долг	{"lines": [{"side": "debit", "expression": "amount - vatAmount", "accountCode": "9420"}, {"side": "debit", "condition": "vatAmount > 0", "expression": "vatAmount", "accountCode": "4410"}, {"side": "credit", "expression": "amount", "accountCode": "6010"}], "opensItem": true, "itemAccountCode": "6010", "requiresCounterparty": true}	MANUAL_ONLY
6376423c-4121-4f9a-92a9-3e3b70745a9c	INTEREST_PAYMENT	Проценты по кредиту/займу (Расход)	{"lines": [{"side": "debit", "expression": "amount", "accountCode": "9610"}, {"side": "credit", "expression": "amount", "accountCode": "5110"}], "opensItem": false, "requiresCounterparty": true}	BANK_AUTO
81f7f271-a691-442b-a5bd-b6f2ce1f77b1	MARKETPLACE_REVENUE	Выручка маркетплейса (с комиссией)	{"lines": [{"side": "debit", "expression": "netAmount", "accountCode": "4890"}, {"side": "debit", "expression": "commissionAmount", "accountCode": "9430"}, {"side": "credit", "expression": "amount - vatAmount", "accountCode": "9030"}, {"side": "credit", "condition": "vatAmount > 0", "expression": "vatAmount", "accountCode": "6410"}], "opensItem": false, "requiresCounterparty": true}	MANUAL_ONLY
a191a6af-fe07-486a-862d-4cbeb47370f3	BANK_LOAN_RECEIVED	Кредит от банка получен (Доход)	{"lines": [{"side": "debit", "expression": "amount", "accountCode": "5110"}, {"side": "credit", "expression": "amount", "accountCode": "6810"}], "opensItem": true, "itemAccountCode": "6810", "requiresCounterparty": true}	BANK_AUTO
f0802c27-4a26-43ee-b048-9b8aa474c67f	DIVIDEND_PAYMENT	Дивиденды учредителям (Расход)	{"lines": [{"side": "debit", "expression": "amount * 0.05", "accountCode": "6610"}, {"side": "credit", "expression": "amount * 0.05", "accountCode": "6410"}, {"side": "debit", "expression": "amount * (1 - 0.05)", "accountCode": "6610"}, {"side": "credit", "expression": "amount * (1 - 0.05)", "accountCode": "5110"}], "opensItem": false, "requiresCounterparty": true, "closesOpenItemByAccount": "6610"}	BANK_AUTO
a8f89943-afe5-4118-a1ba-070923c14f53	FIXED_ASSET_DISPOSAL	Выбытие (списание) ОС	{"lines": [{"side": "debit", "expression": "accumulatedDepreciation", "accountCode": "0200"}, {"side": "debit", "condition": "acquisitionCost > accumulatedDepreciation", "expression": "acquisitionCost - accumulatedDepreciation", "accountCode": "9210"}, {"side": "credit", "expression": "acquisitionCost", "accountCode": "$assetAccountCode"}], "opensItem": false, "requiresCounterparty": false}	MANUAL_ONLY
377e659f-a469-49e2-a0ff-b9132fdce4c8	FINE_PENALTY	Штраф/пеня уплачена (Расход)	{"lines": [{"side": "debit", "expression": "amount", "accountCode": "9430"}, {"side": "credit", "expression": "amount", "accountCode": "5110"}], "opensItem": false, "requiresCounterparty": false}	BANK_AUTO
acdb871d-6cda-4cd4-90bf-1797f651c5aa	PROVISION_FUTURE_EXPENSES	Резерв предстоящих расходов	{"lines": [{"side": "debit", "expression": "amount", "accountCode": "$expenseAccountCode"}, {"side": "credit", "expression": "amount", "accountCode": "8910"}], "opensItem": false, "requiresCounterparty": false}	MANUAL_ONLY
e5d37023-5e42-4cb1-9cdb-84510c3d0a29	PROVISION_UNUSED_TO_INCOME	Восстановление резерва в доход	{"lines": [{"side": "debit", "expression": "amount", "accountCode": "8910"}, {"side": "credit", "expression": "amount", "accountCode": "9390"}], "opensItem": false, "requiresCounterparty": false}	MANUAL_ONLY
7d5bc76f-1bf4-4d51-9f41-bb19759698ee	SUPPLIER_PAYMENT_SERVICES	Оплата поставщику за услуги (Расход)	{"lines": [{"side": "debit", "expression": "amount", "accountCode": "6010"}, {"side": "credit", "expression": "amount", "accountCode": "5110"}], "opensItem": false, "requiresCounterparty": true, "closesOpenItemByAccount": "6010"}	BANK_AUTO
f0f3b223-81ec-45c0-9727-3fc2c27dc855	GOODS_RECEIVED	Поступление товаров — в долг	{"lines": [{"side": "debit", "expression": "amount - vatAmount", "accountCode": "2910"}, {"side": "debit", "condition": "vatAmount > 0", "expression": "vatAmount", "accountCode": "4410"}, {"side": "credit", "expression": "amount", "accountCode": "6010"}], "opensItem": true, "itemAccountCode": "6010", "requiresCounterparty": true}	MANUAL_ONLY
f4d37a78-efd4-4f87-9077-154b6197bf81	INSURANCE_PAYMENT	Страховой взнос (Расход)	{"lines": [{"side": "debit", "expression": "amount", "accountCode": "3120"}, {"side": "credit", "expression": "amount", "accountCode": "5110"}], "opensItem": false, "requiresCounterparty": true}	BANK_AUTO
dcd554e9-af33-4eac-a7d1-5e8e60b25f4c	CASH_DEPOSIT	Внесение наличных на счёт (Доход)	{"lines": [{"side": "debit", "expression": "amount", "accountCode": "5110"}, {"side": "credit", "expression": "amount", "accountCode": "5010"}], "opensItem": false, "requiresCounterparty": false}	BANK_AUTO
9e96aa57-ff60-4960-9daa-a57779600c5f	GOODS_SOLD	Списание себестоимости реализованных товаров	{"lines": [{"side": "debit", "expression": "amount", "accountCode": "9120"}, {"side": "credit", "expression": "amount", "accountCode": "2910"}], "opensItem": false, "requiresCounterparty": false}	MANUAL_ONLY
3aa41fd3-4f40-433f-9a14-8708f3d47156	CAPITAL_CONTRIBUTION	Взнос учредителя в уставный капитал (Доход)	{"lines": [{"side": "debit", "expression": "amount", "accountCode": "5110"}, {"side": "credit", "expression": "amount", "accountCode": "4610"}], "opensItem": false, "requiresCounterparty": true, "closesOpenItemByAccount": "4610"}	BANK_AUTO
19a91aee-0859-4e81-b241-6dcb67b025d6	GRANT_RECEIVABLE	Грант признан (документы получены)	{"lines": [{"side": "debit", "expression": "amount", "accountCode": "4890"}, {"side": "credit", "expression": "amount", "accountCode": "8810"}], "opensItem": true, "itemAccountCode": "4890", "requiresCounterparty": false}	MANUAL_ONLY
12b8b4f3-bf19-4d5b-997a-af8301649a0f	FIXED_ASSET_SALE	Продажа оборудования (Доход)	{"lines": [{"side": "debit", "expression": "amount", "accountCode": "5110"}, {"side": "credit", "condition": "isVatPayer", "expression": "amount / 1.12", "accountCode": "9210"}, {"side": "credit", "condition": "isVatPayer == 0", "expression": "amount", "accountCode": "9210"}, {"side": "credit", "condition": "isVatPayer", "expression": "amount - (amount / 1.12)", "accountCode": "6410"}], "opensItem": false, "requiresCounterparty": true}	BANK_AUTO
5259bc9d-1476-420d-821f-d11a56bff1f5	GRANT_RECEIVED	Грант получен (Доход)	{"lines": [{"side": "debit", "expression": "amount", "accountCode": "5110"}, {"side": "credit", "expression": "amount", "accountCode": "4890"}], "opensItem": false, "requiresCounterparty": false, "closesOpenItemByAccount": "4890"}	BANK_AUTO
b317be27-27f0-45ad-8705-26a4711f3bc7	FOUNDER_LOAN_REPAYMENT	Возврат займа учредителю (Расход)	{"lines": [{"side": "debit", "expression": "amount", "accountCode": "6820"}, {"side": "credit", "expression": "amount", "accountCode": "5110"}], "opensItem": false, "requiresCounterparty": true, "closesOpenItemByAccount": "6820"}	BANK_AUTO
0ce36b53-3efa-41f4-8916-d85f6664528d	FIXED_ASSET_COMMISSIONING	Ввод ОС в эксплуатацию	{"lines": [{"side": "debit", "expression": "acquisitionCost", "accountCode": "$assetAccountCode"}, {"side": "credit", "expression": "acquisitionCost", "accountCode": "0820"}], "opensItem": false, "requiresCounterparty": false}	MANUAL_ONLY
e6f2a302-fae5-485e-a2ab-aa79ce433cf9	NMA_AMORTIZATION	Начисление амортизации НМА	{"lines": [{"side": "debit", "expression": "amount", "accountCode": "$expenseAccountCode"}, {"side": "credit", "expression": "amount", "accountCode": "$amortizationAccountCode"}], "opensItem": false, "requiresCounterparty": false}	MANUAL_ONLY
13b74b2d-3323-4fd5-9c32-969c051a5a1f	RENT_PAYMENT	Аренда — оплата по начислению (Расход)	{"lines": [{"side": "debit", "expression": "amount", "accountCode": "6010"}, {"side": "credit", "expression": "amount", "accountCode": "5110"}], "opensItem": false, "requiresCounterparty": true}	BANK_AUTO
04ca266f-a8cb-4ffd-ac75-6ae68c6ace72	INVOICE_CONFIRMED_PREPAID	ЭСФ подтверждён — зачёт аванса	{"lines": [{"side": "debit", "expression": "amount", "accountCode": "6310"}, {"side": "credit", "expression": "amount - vatAmount", "accountCode": "9030"}, {"side": "credit", "condition": "vatAmount > 0", "expression": "vatAmount", "accountCode": "6410"}], "opensItem": false, "requiresCounterparty": true}	MANUAL_ONLY
4b0e0fda-debf-4a93-98f3-b682384bfdc0	ADVANCE_RETURN_SENT	Возврат предоплаты клиенту (Расход)	{"lines": [{"side": "debit", "expression": "amount", "accountCode": "6310"}, {"side": "credit", "expression": "amount", "accountCode": "5110"}], "opensItem": false, "requiresCounterparty": true, "closesOpenItemByAccount": "6310"}	BANK_AUTO
e8df63d0-2294-41c6-a36c-b17defa48b91	SUBSIDY_RECEIVABLE	Субсидия признана (документы)	{"lines": [{"side": "debit", "expression": "amount", "accountCode": "4890"}, {"side": "credit", "expression": "amount", "accountCode": "8820"}], "opensItem": true, "itemAccountCode": "4890", "requiresCounterparty": false}	MANUAL_ONLY
3d16520f-48bd-4417-a672-c3507ce7aa68	CASH_WITHDRAWAL	Снятие наличных в кассу (Расход)	{"lines": [{"side": "debit", "expression": "amount", "accountCode": "5010"}, {"side": "credit", "expression": "amount", "accountCode": "5110"}], "opensItem": false, "requiresCounterparty": false}	BANK_AUTO
79a48388-7d2b-4fdd-a95a-0b2cb3b9070a	FIXED_ASSET_REVALUATION	Переоценка ОС	{"lines": [{"side": "debit", "condition": "increaseAmount > 0", "expression": "increaseAmount", "accountCode": "$assetAccountCode"}, {"side": "credit", "condition": "increaseAmount > 0", "expression": "increaseAmount", "accountCode": "8510"}, {"side": "debit", "condition": "deprAdjustment > 0", "expression": "deprAdjustment", "accountCode": "8510"}, {"side": "credit", "condition": "deprAdjustment > 0", "expression": "deprAdjustment", "accountCode": "0200"}, {"side": "debit", "condition": "decreaseAmount > 0", "expression": "decreaseAmount", "accountCode": "9430"}, {"side": "credit", "condition": "decreaseAmount > 0", "expression": "decreaseAmount", "accountCode": "$assetAccountCode"}], "opensItem": false, "requiresCounterparty": false}	MANUAL_ONLY
530e95ab-cd04-4183-8641-c5246d65d026	TAX_EXEMPTION_RECOGNITION	Признание целевых налоговых льгот	{"lines": [{"side": "debit", "expression": "amount", "accountCode": "6410"}, {"side": "credit", "expression": "amount", "accountCode": "8840"}], "opensItem": false, "requiresCounterparty": false}	MANUAL_ONLY
467cf2fe-d1a7-49db-b8fd-76a2a6f56060	SUBSIDY_RECEIVED	Субсидия получена (Доход)	{"lines": [{"side": "debit", "expression": "amount", "accountCode": "5110"}, {"side": "credit", "expression": "amount", "accountCode": "4890"}], "opensItem": false, "requiresCounterparty": false, "closesOpenItemByAccount": "4890"}	BANK_AUTO
ec86c143-c9c0-4b88-9df8-85a81b772d23	TARGET_RECEIPTS	Целевые взносы получены (Доход)	{"lines": [{"side": "debit", "expression": "amount", "accountCode": "5110"}, {"side": "credit", "condition": "receiptType == 'membership'", "expression": "amount", "accountCode": "8830"}, {"side": "credit", "condition": "receiptType != 'membership'", "expression": "amount", "accountCode": "8890"}], "opensItem": false, "requiresCounterparty": false}	BANK_AUTO
d7aa4960-a9a0-4ac8-9aad-8b2a02ceac11	GOODS_REVALUATION	Переоценка товаров	{"lines": [{"side": "debit", "condition": "increaseAmount > 0", "expression": "increaseAmount", "accountCode": "2910"}, {"side": "credit", "condition": "increaseAmount > 0", "expression": "increaseAmount", "accountCode": "6230"}, {"side": "debit", "condition": "decreaseAmount > 0", "expression": "decreaseAmount", "accountCode": "3190"}, {"side": "credit", "condition": "decreaseAmount > 0", "expression": "decreaseAmount", "accountCode": "2910"}], "opensItem": false, "requiresCounterparty": false}	MANUAL_ONLY
ab63669a-7ebd-476e-b40e-08674a4e4009	GOODS_IN_TRANSIT_RECEIVED	Товар в пути оприходован на склад	{"lines": [{"side": "debit", "expression": "amount", "accountCode": "2910"}, {"side": "credit", "expression": "amount", "accountCode": "2970"}], "opensItem": false, "requiresCounterparty": false, "closesOpenItemByAccount": "2970"}	MANUAL_ONLY
e55bbb77-f314-4312-8c32-929f8e6e5050	MATERIALS_RECEIVED	Поступление материалов от поставщика	{"lines": [{"side": "debit", "expression": "amount", "accountCode": "1010"}, {"side": "debit", "condition": "vatAmount > 0", "expression": "vatAmount", "accountCode": "4410"}, {"side": "credit", "expression": "amount + vatAmount", "accountCode": "6010"}], "opensItem": true, "itemAccountCode": "6010", "requiresCounterparty": true}	MANUAL_ONLY
b2044aad-17b8-44f6-b2af-63f12342d1b9	DIVIDEND_ACCRUAL	Начисление дивидендов учредителям	{"lines": [{"side": "debit", "expression": "amount", "accountCode": "8710"}, {"side": "credit", "expression": "amount", "accountCode": "6610"}], "opensItem": true, "itemAccountCode": "6610", "requiresCounterparty": true}	MANUAL_ONLY
ff5f062b-2c24-4057-8586-57162affbf2c	SUBSCRIPTION_WRITEOFF	Списание расходов будущих периодов (подписка)	{"lines": [{"side": "debit", "expression": "amount", "accountCode": "9420"}, {"side": "credit", "expression": "amount", "accountCode": "3120"}], "opensItem": false, "requiresCounterparty": false}	MANUAL_ONLY
1f600da3-8f52-4473-a96c-8e8973d74395	ACCOUNTABLE_GENERAL	Деньги под отчёт — офис (Расход)	{"lines": [{"side": "debit", "expression": "amount", "accountCode": "4230"}, {"side": "credit", "expression": "amount", "accountCode": "5110"}], "opensItem": true, "itemAccountCode": "4230", "requiresCounterparty": false}	BANK_AUTO
4ea2ff26-a5cd-4d1d-9451-ba345a593d4f	VAT_OFFSET	Зачёт входящего НДС в счёт исходящего (4410 → 6410)	{"lines": [{"side": "debit", "expression": "vatAmount", "accountCode": "6410"}, {"side": "credit", "expression": "vatAmount", "accountCode": "4410"}], "opensItem": false, "requiresCounterparty": false, "closesOpenItemByAccount": "4410"}	MANUAL_ONLY
292d4512-4560-4752-a3c4-acdb06e743ef	DIVIDEND_INCOME_RECEIVED	Дивиденды от других компаний (Доход)	{"lines": [{"side": "debit", "expression": "amount", "accountCode": "5110"}, {"side": "credit", "expression": "amount", "accountCode": "9520"}], "opensItem": false, "requiresCounterparty": false}	BANK_AUTO
6f718e9e-cdae-49d0-8155-9479f4458daa	MATERIALS_TO_PRODUCTION	Передача материалов в производство	{"lines": [{"side": "debit", "expression": "amount", "accountCode": "2010"}, {"side": "credit", "expression": "amount", "accountCode": "1010"}], "opensItem": false, "requiresCounterparty": false}	MANUAL_ONLY
1dbb043e-f811-4fef-a557-8ebd6a9103df	ACCOUNTABLE_WRITEOFF	Списание подотчётных — командировка	{"lines": [{"side": "debit", "expression": "amount", "accountCode": "9420"}, {"side": "credit", "expression": "amount", "accountCode": "4220"}], "opensItem": false, "requiresCounterparty": true, "closesOpenItemByAccount": "4220"}	MANUAL_ONLY
36229f0e-26f3-4e4e-bc52-400a8ec36c7c	ACCOUNTABLE_RETURN	Сотрудник вернул остаток — командировка (Доход)	{"lines": [{"side": "debit", "expression": "amount", "accountCode": "5110"}, {"side": "credit", "expression": "amount", "accountCode": "4220"}], "opensItem": false, "requiresCounterparty": true, "closesOpenItemByAccount": "4220"}	BANK_AUTO
98543f5a-30c5-40f9-8c2d-0f0501c3ba29	ACCOUNTABLE_GENERAL_WRITEOFF	Списание подотчётных — офис	{"lines": [{"side": "debit", "expression": "amount", "accountCode": "9430"}, {"side": "credit", "expression": "amount", "accountCode": "4230"}], "opensItem": false, "requiresCounterparty": true, "closesOpenItemByAccount": "4230"}	MANUAL_ONLY
8778b6b9-81e7-4caa-ac97-89e015a4de18	ACCOUNTABLE_GENERAL_RETURN	Сотрудник вернул остаток — офис (Доход)	{"lines": [{"side": "debit", "expression": "amount", "accountCode": "5110"}, {"side": "credit", "expression": "amount", "accountCode": "4230"}], "opensItem": false, "requiresCounterparty": true, "closesOpenItemByAccount": "4230"}	BANK_AUTO
bc137b43-5986-4ac0-afa5-51eb8f0cbf67	DEPOSIT_RETURN	Возврат гарантийного депозита (Доход)	{"lines": [{"side": "debit", "expression": "amount", "accountCode": "5110"}, {"side": "credit", "expression": "amount", "accountCode": "4890"}], "opensItem": false, "requiresCounterparty": true, "closesOpenItemByAccount": "4890"}	BANK_AUTO
dee44e8b-37ff-4f96-9ec0-ea36116cc9fb	LONG_TERM_LOAN_REPAYMENT	Погашение долгосрочного займа (Расход)	{"lines": [{"side": "debit", "expression": "amount", "accountCode": "$loanAccountCode"}, {"side": "credit", "expression": "amount", "accountCode": "5110"}], "opensItem": false, "requiresCounterparty": false, "closesOpenItemByAccount": "$loanAccountCode"}	BANK_AUTO
f6ed879a-9fd3-4136-bc24-ffb47304462f	SALARY_ADVANCE	Аванс по зарплате (Расход)	{"lines": [{"side": "debit", "expression": "amount", "accountCode": "4210"}, {"side": "credit", "expression": "amount", "accountCode": "5110"}], "opensItem": false, "requiresCounterparty": false}	BANK_AUTO
db94992f-48c9-48b6-b63c-e9c2939e5900	FINANCE_LEASE_INTEREST	Проценты по лизингу (Расход)	{"lines": [{"side": "debit", "expression": "amount", "accountCode": "9610"}, {"side": "credit", "expression": "amount", "accountCode": "5110"}], "opensItem": false, "requiresCounterparty": false}	BANK_AUTO
699a4b6b-139a-4eb2-9b4a-871c5c7d4c23	FINISHED_GOODS_SOLD	Списание себестоимости реализованной готовой продукции	{"lines": [{"side": "debit", "expression": "amount", "accountCode": "9110"}, {"side": "credit", "expression": "amount", "accountCode": "2810"}], "opensItem": false, "requiresCounterparty": false}	MANUAL_ONLY
805d00f5-a0f8-4d41-90cc-64345e7c2e0b	PROVISION_FOR_DOUBTFUL_DEBTS	Резерв по сомнительным долгам	{"lines": [{"side": "debit", "expression": "amount", "accountCode": "9430"}, {"side": "credit", "expression": "amount", "accountCode": "4910"}], "opensItem": false, "requiresCounterparty": false}	MANUAL_ONLY
f7b8d446-e0f1-40b4-8831-9ffb041bf773	INVENTORY_WRITEOFF	Списание товарно-материальных запасов	{"lines": [{"side": "debit", "expression": "amount", "accountCode": "$expenseAccountCode"}, {"side": "credit", "expression": "amount", "accountCode": "$inventoryAccountCode"}], "opensItem": false, "requiresCounterparty": false}	MANUAL_ONLY
5c5c7a20-3c90-4624-b62c-9dfb94a1281c	LONG_TERM_LOAN_RECEIVED	Долгосрочный займ получен (Доход)	{"lines": [{"side": "debit", "expression": "amount", "accountCode": "5110"}, {"side": "credit", "expression": "amount", "accountCode": "$loanAccountCode"}], "opensItem": true, "itemAccountCode": "$loanAccountCode", "requiresCounterparty": false}	BANK_AUTO
3ac67e3f-ec45-4706-9818-eae9ab790fab	INTANGIBLE_ASSET_PURCHASE	Покупка ПО/лицензии/бренда (Расход)	{"lines": [{"side": "debit", "expression": "amount", "accountCode": "0830"}, {"side": "credit", "expression": "amount", "accountCode": "5110"}], "opensItem": false, "requiresCounterparty": true}	BANK_AUTO
b2ab8c0c-5ff8-4277-ad00-6e188a0aa535	MATERIALS_RETURNED_TO_SUPPLIER	Возврат материалов поставщику	{"lines": [{"side": "debit", "expression": "amount", "accountCode": "6010"}, {"side": "credit", "expression": "amount", "accountCode": "1010"}], "opensItem": false, "requiresCounterparty": true}	MANUAL_ONLY
a83ec6cf-8532-4d04-821b-e54d2466ca7e	FINANCE_LEASE_ASSET_RECEIVED	ОС получено в лизинг	{"lines": [{"side": "debit", "expression": "amount", "accountCode": "0310"}, {"side": "credit", "expression": "amount", "accountCode": "7910"}], "opensItem": true, "itemAccountCode": "7910", "requiresCounterparty": true}	MANUAL_ONLY
78400357-74bd-4c24-be25-fcfd9da15fc6	FINISHED_GOODS_OUTPUT	Выпуск готовой продукции	{"lines": [{"side": "debit", "expression": "amount", "accountCode": "2810"}, {"side": "credit", "expression": "amount", "accountCode": "2010"}], "opensItem": false, "requiresCounterparty": false}	MANUAL_ONLY
9924c436-9a34-4fe4-b5c9-d1139952b62d	FINANCE_LEASE_DEPRECIATION	Амортизация лизингового ОС	{"lines": [{"side": "debit", "expression": "amount", "accountCode": "9420"}, {"side": "credit", "expression": "amount", "accountCode": "0299"}], "opensItem": false, "requiresCounterparty": false}	MANUAL_ONLY
9778f671-26bf-44a4-b068-2867a8a14568	FINANCE_LEASE_PAYMENT	Платёж по лизингу — тело (Расход)	{"lines": [{"side": "debit", "expression": "amount", "accountCode": "7910"}, {"side": "credit", "expression": "amount", "accountCode": "5110"}], "opensItem": false, "requiresCounterparty": false, "closesOpenItemByAccount": "7910"}	BANK_AUTO
9ed54ea5-b5c1-4fe5-b14c-9d3d1b0f6ab8	INTANGIBLE_ASSET_COMMISSIONING	Ввод НМА в эксплуатацию	{"lines": [{"side": "debit", "expression": "acquisitionCost", "accountCode": "$assetAccountCode"}, {"side": "credit", "expression": "acquisitionCost", "accountCode": "0830"}], "opensItem": false, "requiresCounterparty": false}	MANUAL_ONLY
5e5bfac5-391d-47cb-b902-fce2e6388139	INTEREST_INCOME_RECEIVED	Проценты по депозиту получены (Доход)	{"lines": [{"side": "debit", "expression": "amount", "accountCode": "5110"}, {"side": "credit", "expression": "amount", "accountCode": "9530"}], "opensItem": false, "requiresCounterparty": false}	BANK_AUTO
353c3458-3142-4331-885c-0fa84c56ca9d	CORRECTIVE_INVOICE_RECEIVED	Корректировочный счёт-фактура полученный	{"lines": [{"side": "debit", "expression": "correctionAmount + vatCorrection", "accountCode": "6010"}, {"side": "credit", "expression": "correctionAmount", "accountCode": "$expenseOrAssetAccountCode"}, {"side": "credit", "expression": "vatCorrection", "accountCode": "4410"}], "opensItem": false, "requiresCounterparty": true}	MANUAL_ONLY
5312c7f4-c62c-482b-9563-8a4a697e13a8	RENTAL_INCOME_RECEIVED	Доход от сдачи в аренду (Доход)	{"lines": [{"side": "debit", "expression": "amount", "accountCode": "5110"}, {"side": "credit", "expression": "amount", "accountCode": "9350"}], "opensItem": false, "requiresCounterparty": false}	BANK_AUTO
a8764508-ec8a-49ab-b12f-f18f38dd6493	EMPLOYEE_LOAN	Займ сотруднику (Расход)	{"lines": [{"side": "debit", "expression": "amount", "accountCode": "4720"}, {"side": "credit", "expression": "amount", "accountCode": "5110"}], "opensItem": true, "itemAccountCode": "4720", "requiresCounterparty": false}	BANK_AUTO
687bac12-2cc8-4838-955d-84294042be1a	GOODS_RETURNED_FROM_CUSTOMER	Клиент вернул товар	{"lines": [{"side": "debit", "expression": "amount", "accountCode": "9040"}, {"side": "credit", "expression": "amount", "accountCode": "$settlementAccountCode"}, {"side": "debit", "expression": "vatAmount", "accountCode": "6410"}, {"side": "credit", "expression": "vatAmount", "accountCode": "$settlementAccountCode"}, {"side": "debit", "expression": "costAmount", "accountCode": "2910"}, {"side": "credit", "expression": "costAmount", "accountCode": "9120"}], "opensItem": false, "requiresCounterparty": true}	MANUAL_ONLY
fef4d671-90db-416e-a2ae-1b58ae570d04	COUNTERPARTY_SETOFF	Взаимозачёт с контрагентом	{"lines": [{"side": "debit", "expression": "amount", "accountCode": "6010"}, {"side": "credit", "expression": "amount", "accountCode": "4010"}], "opensItem": false, "requiresCounterparty": true}	MANUAL_ONLY
1754e374-b54b-4aef-ae59-00b22e32f489	VAT_REFUND_FROM_BUDGET	Возврат НДС из бюджета (Доход)	{"lines": [{"side": "debit", "expression": "amount", "accountCode": "5110"}, {"side": "credit", "expression": "amount", "accountCode": "4410"}], "opensItem": false, "requiresCounterparty": false}	BANK_AUTO
4bf73f3b-5934-4669-a3d0-262616203c26	ROYALTY_INCOME	Роялти получены (Доход)	{"lines": [{"side": "debit", "expression": "amount", "accountCode": "5110"}, {"side": "credit", "expression": "amount", "accountCode": "9510"}], "opensItem": false, "requiresCounterparty": true}	BANK_AUTO
48c21ef9-70ef-42ca-8ce5-c44f0a25d0d5	OTHER_EXPENSE	Прочий расход (Расход)	{"lines": [{"side": "debit", "expression": "amount", "accountCode": "9430"}, {"side": "credit", "expression": "amount", "accountCode": "5110"}], "opensItem": false, "requiresCounterparty": false}	BANK_AUTO
28c8c399-9da5-4b55-a645-e8a884e9293f	INPS_PAYMENT	Накопительная пенсия — ИНПС (Расход)	{"lines": [{"side": "debit", "expression": "amount", "accountCode": "6530"}, {"side": "credit", "expression": "amount", "accountCode": "5110"}], "opensItem": false, "requiresCounterparty": false}	BANK_AUTO
bc558626-bad9-4db9-9163-b768e931191c	WRITE_OFF_CREDITORS	Списание кредиторской задолженности	{"lines": [{"side": "debit", "expression": "amount", "accountCode": "6010"}, {"side": "credit", "expression": "amount", "accountCode": "9360"}], "opensItem": false, "requiresCounterparty": true}	MANUAL_ONLY
ccca5e91-1dd2-4432-98e7-ee0e8f011438	ROYALTY_PAYMENT	Выплата роялти (Расход)	{"lines": [{"side": "debit", "expression": "amount", "accountCode": "9430"}, {"side": "credit", "expression": "amount", "accountCode": "5110"}], "opensItem": false, "requiresCounterparty": true}	BANK_AUTO
7126052b-b268-43bf-940f-c41bca733e39	LETTER_OF_CREDIT_OPEN	Открытие аккредитива (Перевод)	{"lines": [{"side": "debit", "expression": "amount", "accountCode": "5510"}, {"side": "credit", "expression": "amount", "accountCode": "5110"}], "opensItem": true, "itemAccountCode": "5510", "requiresCounterparty": true}	BANK_AUTO
754216fb-c827-4f2c-8cb9-d8181ef517a1	TURNOVER_TAX_ACCRUAL	Начисление налога с оборота	{"lines": [{"side": "debit", "expression": "taxAmount", "accountCode": "9810"}, {"side": "credit", "expression": "taxAmount", "accountCode": "6410"}], "opensItem": false, "requiresCounterparty": false}	MANUAL_ONLY
1552a555-dc92-4806-87b6-28f41728e90d	LONG_TERM_TO_CURRENT_RECLASS	Перевод долга в краткосрочный	{"lines": [{"side": "debit", "expression": "amount", "accountCode": "7810"}, {"side": "credit", "expression": "amount", "accountCode": "6950"}], "opensItem": false, "requiresCounterparty": false}	MANUAL_ONLY
086de74a-b976-4883-ab58-b26be1b0798a	FIXED_ASSET_DISPOSAL_RESULT	Итог от выбытия ОС	{"lines": [{"side": "debit", "condition": "profit > 0", "expression": "profit", "accountCode": "9210"}, {"side": "credit", "condition": "profit > 0", "expression": "profit", "accountCode": "9310"}, {"side": "debit", "condition": "loss > 0", "expression": "loss", "accountCode": "9320"}, {"side": "credit", "condition": "loss > 0", "expression": "loss", "accountCode": "9210"}], "opensItem": false, "requiresCounterparty": false}	MANUAL_ONLY
a5a52d7d-5358-4742-a3d2-5bdb855f53ef	INSURANCE_WRITEOFF	Списание предоплаченной страховки по периодам	{"lines": [{"side": "debit", "expression": "amount", "accountCode": "9420"}, {"side": "credit", "expression": "amount", "accountCode": "3120"}], "opensItem": false, "requiresCounterparty": false}	MANUAL_ONLY
463d148a-d359-4f3b-9ba2-b357bfcc40c4	LETTER_OF_CREDIT_EXECUTION	Исполнение аккредитива	{"lines": [{"side": "debit", "expression": "amount", "accountCode": "6010"}, {"side": "credit", "expression": "amount", "accountCode": "5510"}], "opensItem": false, "requiresCounterparty": true, "closesOpenItemByAccount": "5510"}	MANUAL_ONLY
f9b5d7be-a1de-4616-87fb-5160d8bff2a0	SALARY_DEPOSIT	Депонирование заработной платы	{"lines": [{"side": "debit", "expression": "amount", "accountCode": "6710"}, {"side": "credit", "expression": "amount", "accountCode": "6720"}], "opensItem": true, "itemAccountCode": "6720", "requiresCounterparty": false}	MANUAL_ONLY
348b6a91-2055-4cd8-b96a-613eede381c7	SUBSCRIPTION	Подписка/лицензия (Расход)	{"lines": [{"side": "debit", "condition": "subscriptionPeriod == 'monthly'", "expression": "amount", "accountCode": "9420"}, {"side": "debit", "condition": "subscriptionPeriod != 'monthly'", "expression": "amount", "accountCode": "3120"}, {"side": "credit", "expression": "amount", "accountCode": "5110"}], "opensItem": false, "requiresCounterparty": true}	BANK_AUTO
b0110fcc-5f81-4073-a3ef-248893e8af09	SALARY_DEPOSIT_PAYMENT	Выплата задержанной зарплаты (Расход)	{"lines": [{"side": "debit", "expression": "amount", "accountCode": "6720"}, {"side": "credit", "expression": "amount", "accountCode": "5110"}], "opensItem": false, "requiresCounterparty": false, "closesOpenItemByAccount": "6720"}	BANK_AUTO
e2830998-31a3-48df-81d2-1e8d895905ab	DEPOSIT_INTEREST_ACCRUAL	Начисление процентов по депозиту	{"lines": [{"side": "debit", "expression": "amount", "accountCode": "4830"}, {"side": "credit", "expression": "amount", "accountCode": "9530"}], "opensItem": false, "requiresCounterparty": false}	MANUAL_ONLY
4c2a61f6-e4c2-4c37-bc61-45b1dc79fd30	CUSTOMS_DUTY	Таможенные платежи (Расход)	{"lines": [{"side": "debit", "condition": "customsType == 'import_goods'", "expression": "amount", "accountCode": "2910"}, {"side": "debit", "condition": "customsType == 'import_asset'", "expression": "amount", "accountCode": "0820"}, {"side": "debit", "condition": "customsType != 'import_goods' && customsType != 'import_asset'", "expression": "amount", "accountCode": "9430"}, {"side": "credit", "expression": "amount", "accountCode": "5110"}], "opensItem": false, "requiresCounterparty": false}	BANK_AUTO
18037132-b313-4e13-9b59-45d13375edc5	GOODS_RETURNED_TO_SUPPLIER	Возврат товаров поставщику	{"lines": [{"side": "debit", "expression": "amount", "accountCode": "6010"}, {"side": "credit", "expression": "amount", "accountCode": "2910"}], "opensItem": false, "requiresCounterparty": true}	MANUAL_ONLY
04e958eb-bafe-4ecb-be7a-920c0fede591	CAPITAL_INCREASE_PENDING	Довзнос учредителя сверх устава (Доход)	{"lines": [{"side": "debit", "expression": "amount", "accountCode": "5110"}, {"side": "credit", "expression": "amount", "accountCode": "6630"}], "opensItem": true, "itemAccountCode": "6630", "requiresCounterparty": true}	BANK_AUTO
fe906970-11d8-4c26-a140-d1a3096e0b4c	CAPITAL_INCREASE_REGISTERED	Реклассификация довзноса в УК	{"lines": [{"side": "debit", "expression": "amount", "accountCode": "6630"}, {"side": "credit", "expression": "amount", "accountCode": "8330"}], "opensItem": false, "requiresCounterparty": true, "closesOpenItemByAccount": "6630"}	MANUAL_ONLY
4b65532a-0522-4461-9e9a-464c4967fccb	EXTRAORDINARY_GAIN_LOSS	Чрезвычайный доход/расход	{"lines": [{"side": "debit", "condition": "gainAmount > 0", "expression": "gainAmount", "accountCode": "$accountCode"}, {"side": "credit", "condition": "gainAmount > 0", "expression": "gainAmount", "accountCode": "9710"}, {"side": "debit", "condition": "lossAmount > 0", "expression": "lossAmount", "accountCode": "9720"}, {"side": "credit", "condition": "lossAmount > 0", "expression": "lossAmount", "accountCode": "$accountCode"}], "opensItem": false, "requiresCounterparty": false}	MANUAL_ONLY
6d312214-7e8f-49a2-bd5a-5cab3408523e	MEMBERSHIP_FEE	Членский взнос в организацию (Расход)	{"lines": [{"side": "debit", "expression": "amount", "accountCode": "9430"}, {"side": "credit", "expression": "amount", "accountCode": "5110"}], "opensItem": false, "requiresCounterparty": true}	BANK_AUTO
d38a642e-8907-4472-9386-6d1198d9fd61	CHARITY_PAYMENT	Благотворительный взнос (Расход)	{"lines": [{"side": "debit", "expression": "amount", "accountCode": "9430"}, {"side": "credit", "expression": "amount", "accountCode": "5110"}], "opensItem": false, "requiresCounterparty": true}	BANK_AUTO
db996e95-cd79-4ffb-8f9f-86847ef5ba92	PARTNER_LOAN_RECEIVED	Займ от другой компании получен (Доход)	{"lines": [{"side": "debit", "expression": "amount", "accountCode": "5110"}, {"side": "credit", "expression": "amount", "accountCode": "6820"}], "opensItem": true, "itemAccountCode": "6820", "requiresCounterparty": true}	BANK_AUTO
918467b2-beae-4139-aecf-5c594474ccba	PARTNER_LOAN_RETURNED	Другая компания вернула займ (Доход)	{"lines": [{"side": "debit", "expression": "amount", "accountCode": "5110"}, {"side": "credit", "expression": "amount", "accountCode": "4890"}], "opensItem": false, "requiresCounterparty": true, "closesOpenItemByAccount": "4890"}	BANK_AUTO
257a0183-45a2-43cb-bc23-d93cc06dea6b	OPENING_CAPITAL_DECLARATION	Декларация уставного капитала	{"lines": [{"side": "debit", "expression": "amount", "accountCode": "4610"}, {"side": "credit", "expression": "amount", "accountCode": "8330"}, {"side": "debit", "condition": "fundingType == 'FULLY_PAID_CASH'", "expression": "amount", "accountCode": "5110"}, {"side": "credit", "condition": "fundingType == 'FULLY_PAID_CASH'", "expression": "amount", "accountCode": "4610"}, {"side": "debit", "condition": "fundingType == 'PARTIALLY_PAID'", "expression": "paidAmount", "accountCode": "5110"}, {"side": "credit", "condition": "fundingType == 'PARTIALLY_PAID'", "expression": "paidAmount", "accountCode": "4610"}, {"side": "debit", "condition": "fundingType == 'PAID_IN_KIND'", "expression": "paidAmount", "accountCode": "$fundedAccountCode"}, {"side": "credit", "condition": "fundingType == 'PAID_IN_KIND'", "expression": "paidAmount", "accountCode": "4610"}], "opensItem": false, "requiresCounterparty": false}	MANUAL_ONLY
bb3c5d41-a683-48a7-b082-4f7473019c7c	PENALTY_INCOME	Неустойка от партнёра получена (Доход)	{"lines": [{"side": "debit", "expression": "amount", "accountCode": "5110"}, {"side": "credit", "expression": "amount", "accountCode": "9330"}], "opensItem": false, "requiresCounterparty": true}	BANK_AUTO
27da6372-59c4-4ea3-8363-48e2e7e103e5	INSURANCE_CLAIM_RECEIVED	Страховое возмещение получено (Доход)	{"lines": [{"side": "debit", "expression": "amount", "accountCode": "5110"}, {"side": "credit", "expression": "amount", "accountCode": "9390"}], "opensItem": false, "requiresCounterparty": true}	BANK_AUTO
1a94b949-c1ac-4ec2-9148-db0d6f34d044	TENANT_UTILITIES_RECEIVED	Коммунальные от арендатора — возмещение (Доход)	{"lines": [{"side": "debit", "expression": "amount", "accountCode": "5110"}, {"side": "credit", "expression": "amount", "accountCode": "6310"}], "opensItem": false, "requiresCounterparty": true}	BANK_AUTO
9822b4d7-542a-408b-8c0c-d5fc808a9483	STATE_DUTY	Оплата госпошлины (Расход)	{"lines": [{"side": "debit", "expression": "amount", "accountCode": "9430"}, {"side": "credit", "expression": "amount", "accountCode": "5110"}], "opensItem": false, "requiresCounterparty": false}	BANK_AUTO
3f02148c-db29-490e-82d7-f17fd826ac9d	EMPLOYEE_TRAINING	Обучение сотрудников (Расход)	{"lines": [{"side": "debit", "expression": "amount", "accountCode": "9420"}, {"side": "credit", "expression": "amount", "accountCode": "5110"}], "opensItem": false, "requiresCounterparty": true}	BANK_AUTO
e098e254-6587-4d5d-8613-c70258fe9c4a	TAX_REFUND_OTHER	Возврат переплаты налога — не НДС (Доход)	{"lines": [{"side": "debit", "expression": "amount", "accountCode": "5110"}, {"side": "credit", "expression": "amount", "accountCode": "6410"}], "opensItem": false, "requiresCounterparty": false}	BANK_AUTO
c9cb7877-764f-402c-805b-efc2cc8b2993	FACTORING_RECEIVED	Деньги по факторингу получены (Доход)	{"lines": [{"side": "debit", "expression": "amount", "accountCode": "5110"}, {"side": "credit", "expression": "amount", "accountCode": "4010"}], "opensItem": false, "requiresCounterparty": true}	BANK_AUTO
cf7ace25-8cb1-4cc5-8793-76c486ea191f	FUEL_PURCHASE	Закупка топлива — ГСМ (Расход)	{"lines": [{"side": "debit", "expression": "amount", "accountCode": "1030"}, {"side": "credit", "expression": "amount", "accountCode": "5110"}], "opensItem": false, "requiresCounterparty": true}	BANK_AUTO
0c3577f2-36c2-4f3f-a150-a679eb568837	TAXI_BUSINESS	Такси/транспорт для бизнеса (Расход)	{"lines": [{"side": "debit", "expression": "amount", "accountCode": "9420"}, {"side": "credit", "expression": "amount", "accountCode": "5110"}], "opensItem": false, "requiresCounterparty": false}	BANK_AUTO
32d1ac75-9a8d-4b76-812b-266b5bc30413	TRANSLATION_SERVICES	Перевод документов (Расход)	{"lines": [{"side": "debit", "expression": "amount", "accountCode": "9420"}, {"side": "credit", "expression": "amount", "accountCode": "5110"}], "opensItem": false, "requiresCounterparty": true}	BANK_AUTO
59ed6121-cb62-47e0-b0b5-22fd50c96ea4	WARRANTY_REPAIR	Гарантийный ремонт клиенту (Расход)	{"lines": [{"side": "debit", "expression": "amount", "accountCode": "9430"}, {"side": "credit", "expression": "amount", "accountCode": "5110"}], "opensItem": false, "requiresCounterparty": true}	BANK_AUTO
60699c0b-ff06-4718-9786-ba4cf6c690f6	ACQUIRING_COMMISSION	Комиссия эквайринга (Расход)	{"lines": [{"side": "debit", "expression": "amount", "accountCode": "9430"}, {"side": "credit", "expression": "amount", "accountCode": "5110"}], "opensItem": false, "requiresCounterparty": true}	BANK_AUTO
17d24db6-517a-4674-a56a-1ced62af8541	DELIVERY_TO_CUSTOMER	Доставка товара покупателю (Расход)	{"lines": [{"side": "debit", "expression": "amount", "accountCode": "9410"}, {"side": "credit", "expression": "amount", "accountCode": "5110"}], "opensItem": false, "requiresCounterparty": true}	BANK_AUTO
fe00395d-90cf-4584-8e1d-f9d4e61dfe6a	PACKAGING_COST	Упаковка и тара (Расход)	{"lines": [{"side": "debit", "expression": "amount", "accountCode": "9410"}, {"side": "credit", "expression": "amount", "accountCode": "5110"}], "opensItem": false, "requiresCounterparty": false}	BANK_AUTO
0896de05-62bc-49ed-9fa6-be1cded4fb2c	SECURITY_SERVICES	Охрана / ЧОП (Расход)	{"lines": [{"side": "debit", "expression": "amount", "accountCode": "9420"}, {"side": "credit", "expression": "amount", "accountCode": "5110"}], "opensItem": false, "requiresCounterparty": true}	BANK_AUTO
b920a648-30fb-4210-b927-b6103173e8fc	CUSTOMS_BROKER	Оплата таможенному брокеру (Расход)	{"lines": [{"side": "debit", "expression": "amount", "accountCode": "2910"}, {"side": "credit", "expression": "amount", "accountCode": "5110"}], "opensItem": false, "requiresCounterparty": true}	BANK_AUTO
9a4e4994-4eb2-4a7d-b266-ef9475f9fd8f	PRODUCT_CERTIFICATION	Сертификация товара/продукции (Расход)	{"lines": [{"side": "debit", "expression": "amount", "accountCode": "9430"}, {"side": "credit", "expression": "amount", "accountCode": "5110"}], "opensItem": false, "requiresCounterparty": true}	BANK_AUTO
48bae625-01d9-46fc-826b-0283f1f1df32	CASH_COLLECTION_SERVICE	Инкассация (Расход)	{"lines": [{"side": "debit", "expression": "amount", "accountCode": "9430"}, {"side": "credit", "expression": "amount", "accountCode": "5110"}], "opensItem": false, "requiresCounterparty": true}	BANK_AUTO
f367049e-ee88-44c7-af1c-f34604c1cbaa	REFERRAL_COMMISSION	Реферальная комиссия партнёру (Расход)	{"lines": [{"side": "debit", "expression": "amount", "accountCode": "9410"}, {"side": "credit", "expression": "amount", "accountCode": "5110"}], "opensItem": false, "requiresCounterparty": true}	BANK_AUTO
ad5e585e-30a9-41e9-90b0-baa08fc39012	MOBILE_COMMUNICATION	Мобильная связь сотрудников (Расход)	{"lines": [{"side": "debit", "expression": "amount", "accountCode": "9420"}, {"side": "credit", "expression": "amount", "accountCode": "5110"}], "opensItem": false, "requiresCounterparty": false}	BANK_AUTO
4274faae-a55b-4cdd-8c97-c0091c6f2825	CONFERENCE_FEE	Участие в конференции/мероприятии (Расход)	{"lines": [{"side": "debit", "expression": "amount", "accountCode": "9420"}, {"side": "credit", "expression": "amount", "accountCode": "5110"}], "opensItem": false, "requiresCounterparty": true}	BANK_AUTO
952418bd-a3f2-4824-ac3f-2ed93b5eb845	RAW_MATERIALS_PURCHASE	Прямая закупка сырья (Расход)	{"lines": [{"side": "debit", "expression": "amount", "accountCode": "1010"}, {"side": "credit", "expression": "amount", "accountCode": "5110"}], "opensItem": false, "requiresCounterparty": true}	BANK_AUTO
150b71ef-9778-4f23-bfd7-bdabb4245063	REVENUE_NO_VAT	Продажа с документами (без НДС)	{"lines": [{"side": "debit", "expression": "amount", "accountCode": "5110"}, {"side": "credit", "expression": "amount", "accountCode": "9030"}], "opensItem": false, "requiresCounterparty": true}	MANUAL_ONLY
11153a82-fa3f-4228-9376-e6ba3e88a335	TAX_PAYMENT	Оплата налога (Расход)	{"lines": [{"side": "debit", "expression": "amount", "accountCode": "6410"}, {"side": "credit", "expression": "amount", "accountCode": "5110"}], "opensItem": false, "requiresCounterparty": false}	BANK_AUTO
5730d5d2-0cc9-40f1-b6b6-59eb68aed9a7	PREPAID_RENT_PAYMENT	Предоплата за аренду (Расход)	{"lines": [{"side": "debit", "expression": "amount", "accountCode": "3110"}, {"side": "credit", "expression": "amount", "accountCode": "5110"}], "opensItem": false, "requiresCounterparty": false}	BANK_AUTO
87de1c5a-9fe8-4a26-8fef-82c577c7bbf0	GOODS_IN_TRANSIT	Товар оплачен, в пути (Перевод)	{"lines": [{"side": "debit", "expression": "amount", "accountCode": "2970"}, {"side": "credit", "expression": "amount", "accountCode": "$creditAccountCode"}], "opensItem": true, "itemAccountCode": "2970", "requiresCounterparty": true}	BANK_AUTO
1f884e78-fc7c-48aa-ae83-bce8f2164fe6	SELF_EMPLOYED_PAYMENT	Оплата самозанятому (Расход)	{"lines": [{"side": "debit", "expression": "amount", "accountCode": "9420"}, {"side": "credit", "expression": "amount", "accountCode": "5110"}], "opensItem": false, "requiresCounterparty": true}	BANK_AUTO
0b559f90-b5d3-42be-82c9-477d02bca671	PERMITS_APPROVALS	Разрешения и согласования (Расход)	{"lines": [{"side": "debit", "expression": "amount", "accountCode": "9430"}, {"side": "credit", "expression": "amount", "accountCode": "5110"}], "opensItem": false, "requiresCounterparty": false}	BANK_AUTO
25d5c6f2-c773-4cfa-b4af-6f8951b74eb7	MUSIC_LICENSE	Лицензия на публичное воспроизведение музыки (Расход)	{"lines": [{"side": "debit", "expression": "amount", "accountCode": "9430"}, {"side": "credit", "expression": "amount", "accountCode": "5110"}], "opensItem": false, "requiresCounterparty": true}	BANK_AUTO
2687bf03-150f-4f94-bd50-54f95662d167	ROAD_TOLLS	Платные дороги и парковки (Расход)	{"lines": [{"side": "debit", "expression": "amount", "accountCode": "9430"}, {"side": "credit", "expression": "amount", "accountCode": "5110"}], "opensItem": false, "requiresCounterparty": false}	BANK_AUTO
45ef32c3-e802-434d-9856-32600b7aa81c	MEDICAL_LICENSE	Медицинская лицензия (Расход)	{"lines": [{"side": "debit", "expression": "amount", "accountCode": "9430"}, {"side": "credit", "expression": "amount", "accountCode": "5110"}], "opensItem": false, "requiresCounterparty": true}	BANK_AUTO
865d6354-abe6-44f2-96b0-18d2986ebb09	CURRENCY_EXCHANGE	Обмен валюты (Перевод)	{"lines": [{"side": "debit", "expression": "amount", "accountCode": "5110"}, {"side": "credit", "expression": "amount", "accountCode": "5210"}], "opensItem": false, "requiresCounterparty": false}	BANK_AUTO
72614928-cc2b-4cc4-9e4f-338a38a03073	FIXED_ASSET_SALVAGE	Оприходование остатков от ОС	{"lines": [{"side": "debit", "expression": "amount", "accountCode": "1090"}, {"side": "credit", "expression": "amount", "accountCode": "9210"}], "opensItem": false, "requiresCounterparty": false}	MANUAL_ONLY
25e8a645-6d41-4eee-ba92-d2b9f263f4bc	SALARY	Выплата зарплаты сотрудникам (Расход)	{"lines": [{"side": "debit", "expression": "amount", "accountCode": "6710"}, {"side": "credit", "expression": "amount", "accountCode": "5110"}], "opensItem": false, "requiresCounterparty": false}	BANK_AUTO
df64c86e-6372-4549-a24d-8f2bc3c28254	SALARY_OFFSET	Зачёт займа сотруднику в счёт зарплаты	{"lines": [{"side": "debit", "expression": "amount", "accountCode": "6710"}, {"side": "credit", "expression": "amount", "accountCode": "4720"}], "opensItem": false, "requiresCounterparty": false}	MANUAL_ONLY
9fedca31-2b1e-4a52-81cf-0038aff3697b	INTERNAL_TRANSFER	Перевод на другой свой счёт (Перевод)	{"lines": [{"side": "debit", "expression": "amount", "accountCode": "5710"}, {"side": "credit", "expression": "amount", "accountCode": "5110"}], "opensItem": true, "itemAccountCode": "5710", "requiresCounterparty": false}	BANK_AUTO
19c016f7-a3f0-45db-9840-fc63ead2d0fe	CORRECTIVE_INVOICE_ISSUED	Корректировочный счёт-фактура выданный	{"lines": [{"side": "debit", "expression": "correctionAmount", "accountCode": "9030"}, {"side": "debit", "expression": "vatCorrection", "accountCode": "6410"}, {"side": "credit", "expression": "correctionAmount + vatCorrection", "accountCode": "$settlementAccountCode"}], "opensItem": false, "requiresCounterparty": true}	MANUAL_ONLY
e6b9d9c6-c670-49df-a165-3afeb98e56a4	SALARY_ACCRUAL	Начисление зарплаты и налогов ФОТ	{"lines": [{"side": "debit", "expression": "salaryAmount", "accountCode": "$expenseAccountCode"}, {"side": "credit", "expression": "salaryAmount", "accountCode": "6710"}, {"side": "debit", "expression": "salaryAmount * 0.001", "accountCode": "6710"}, {"side": "credit", "expression": "salaryAmount * 0.001", "accountCode": "6530"}, {"side": "debit", "expression": "salaryAmount * 0.119", "accountCode": "6710"}, {"side": "credit", "expression": "salaryAmount * 0.119", "accountCode": "6410"}, {"side": "debit", "expression": "salaryAmount * 0.12", "accountCode": "$expenseAccountCode"}, {"side": "credit", "expression": "salaryAmount * 0.12", "accountCode": "6520"}], "opensItem": false, "requiresCounterparty": false}	MANUAL_ONLY
821f2c04-962c-4686-9774-5d1e17adab95	BANK_LOAN_REPAYMENT	Погашение кредита банку (Расход)	{"lines": [{"side": "debit", "expression": "amount", "accountCode": "6810"}, {"side": "credit", "expression": "amount", "accountCode": "5110"}], "opensItem": false, "requiresCounterparty": true, "closesOpenItemByAccount": "6810"}	BANK_AUTO
533c5b41-645c-4918-9bf0-2341e7eba9f1	BAD_DEBT_WRITEOFF	Списание безнадёжной дебиторской задолженности	{"lines": [{"side": "debit", "condition": "useReserve", "expression": "amount", "accountCode": "4910"}, {"side": "debit", "condition": "!useReserve", "expression": "amount", "accountCode": "9430"}, {"side": "credit", "expression": "amount", "accountCode": "4010"}], "opensItem": false, "requiresCounterparty": true}	MANUAL_ONLY
ffb3cab5-8a4b-4ebd-9a2a-4c5e1ff45497	INTERNAL_TRANSFER_RECEIVED	Поступление с другого своего счёта (Перевод)	{"lines": [{"side": "debit", "expression": "amount", "accountCode": "$destinationAccountCode"}, {"side": "credit", "expression": "amount", "accountCode": "5710"}], "opensItem": false, "requiresCounterparty": false, "closesOpenItemByAccount": "5710"}	BANK_AUTO
b3124a22-2705-462f-a2d8-c7e0ac4a97d6	IMPORT_VAT_PAYMENT	НДС на импорт (Расход)	{"lines": [{"side": "debit", "expression": "amount", "accountCode": "4410"}, {"side": "credit", "expression": "amount", "accountCode": "5110"}], "opensItem": false, "requiresCounterparty": false}	BANK_AUTO
107e2a09-269b-4e40-bd8d-54aa6a7bc44f	CIVIL_CONTRACT_PAYMENT	Оплата по договору ГПХ (Расход)	{"lines": [{"side": "debit", "expression": "amount", "accountCode": "6710"}, {"side": "credit", "expression": "amount", "accountCode": "5110"}], "opensItem": false, "requiresCounterparty": true}	BANK_AUTO
46204a22-bee9-49b3-826e-2f24bc7cf733	PREPAID_RENT_RECOGNITION	Списание предоплаты аренды по периодам	{"lines": [{"side": "debit", "expression": "amount", "accountCode": "9420"}, {"side": "credit", "expression": "amount", "accountCode": "3110"}], "opensItem": false, "requiresCounterparty": false}	MANUAL_ONLY
1046e0ee-6a24-476f-af41-c72cd740837b	PROVISION_FUTURE_EXPENSES_USE	Использование резерва расходов	{"lines": [{"side": "debit", "expression": "amount", "accountCode": "8910"}, {"side": "credit", "expression": "amount", "accountCode": "$targetAccountCode"}], "opensItem": false, "requiresCounterparty": false}	MANUAL_ONLY
4553fda7-5b3e-43ce-887e-0bd58a6c9106	PARTNER_LOAN_REPAID	Возврат займа другой компании (Расход)	{"lines": [{"side": "debit", "expression": "amount", "accountCode": "6820"}, {"side": "credit", "expression": "amount", "accountCode": "5110"}], "opensItem": false, "requiresCounterparty": true, "closesOpenItemByAccount": "6820"}	BANK_AUTO
97ff00fc-4637-4c8f-81f4-47743c682614	PROFESSIONAL_SERVICES	Профессиональные услуги — юрист/аудит/консультант (Расход)	{"lines": [{"side": "debit", "expression": "amount", "accountCode": "9420"}, {"side": "credit", "expression": "amount", "accountCode": "5110"}], "opensItem": false, "requiresCounterparty": true}	BANK_AUTO
1d2ebe75-77b6-4338-9ea1-a6172421c7ef	PARTNER_LOAN_ISSUED	Займ выдан другой компании (Расход)	{"lines": [{"side": "debit", "expression": "amount", "accountCode": "4890"}, {"side": "credit", "expression": "amount", "accountCode": "5110"}], "opensItem": true, "itemAccountCode": "4890", "requiresCounterparty": true}	BANK_AUTO
e2770e95-0918-44e4-bb44-2d1cee450a7e	MARKETPLACE_PROMOTION	Продвижение на маркетплейсе (Расход)	{"lines": [{"side": "debit", "expression": "amount", "accountCode": "9410"}, {"side": "credit", "expression": "amount", "accountCode": "5110"}], "opensItem": false, "requiresCounterparty": true}	BANK_AUTO
\.


--
-- Data for Name: JournalEntry; Type: TABLE DATA; Schema: public; Owner: user
--

COPY public."JournalEntry" (id, "documentId", "accountId", debit, credit, date, "counterpartyId", "contractId") FROM stdin;
2f09ffe7-0689-4351-960a-df0b125afb9f	faa2f7ee-05f0-46ee-b552-27bb8616bbb6	07641d9b-5c94-4918-9e04-797611bcec95	10000000.00	0.00	2026-07-05 10:18:18.192	\N	\N
cfc8f204-2809-4962-add5-988be7b164f5	faa2f7ee-05f0-46ee-b552-27bb8616bbb6	d07854de-85d6-4afd-bd9a-d10085203eed	0.00	10000000.00	2026-07-05 10:18:18.192	\N	\N
4ad87ac7-0a61-4e02-827f-b1634c368537	159f6645-8246-461a-bc4c-0ec53537c116	d4c91fda-45de-4c62-928c-8025f856ed94	2000.00	0.00	2026-05-14 00:00:00	\N	\N
2fe97ec2-adce-42e9-826d-945853fca620	159f6645-8246-461a-bc4c-0ec53537c116	3e48e334-f497-4f44-9922-73655cbc3209	0.00	2000.00	2026-05-14 00:00:00	\N	\N
43d4e5b6-6fa8-4aad-87e1-997318015f55	efdbb8f1-05d5-4df3-bbe9-1524268aa2fb	3e48e334-f497-4f44-9922-73655cbc3209	196000.00	0.00	2026-05-04 00:00:00	\N	\N
751f2a21-6919-4f1a-bc26-94df9780866e	efdbb8f1-05d5-4df3-bbe9-1524268aa2fb	7295850d-efdd-46ab-bba0-50379da90c85	0.00	196000.00	2026-05-04 00:00:00	\N	\N
1c78e812-63d4-4f71-9f57-5b8f9e0a4b16	9268de84-f08b-4d84-b163-65ec38d4c648	35ec3a42-1734-4a77-bd0f-e7c94b01e289	1049019.42	0.00	2026-05-04 00:00:00	\N	\N
2c2c9b4e-59b2-4e6a-8d63-9169d051bcc4	9268de84-f08b-4d84-b163-65ec38d4c648	3e48e334-f497-4f44-9922-73655cbc3209	0.00	1049019.42	2026-05-04 00:00:00	\N	\N
07e3365b-9944-4e71-84dc-092ce63136ea	36e951a7-2516-471a-b799-2bfc70e9a924	1f64b4e5-72ea-4403-bfe9-91fc7083ad80	964000.00	0.00	2026-05-04 00:00:00	\N	\N
6bd535c5-bc40-476f-bedb-ffb84cc008c7	36e951a7-2516-471a-b799-2bfc70e9a924	3e48e334-f497-4f44-9922-73655cbc3209	0.00	964000.00	2026-05-04 00:00:00	\N	\N
26c4bf61-ea1b-4e98-9505-921b33231fef	f002e9c8-ae69-46fb-8120-5b0f279334c7	1f64b4e5-72ea-4403-bfe9-91fc7083ad80	148000.00	0.00	2026-05-04 00:00:00	\N	\N
5a254f58-0212-418e-8348-37caf63162af	f002e9c8-ae69-46fb-8120-5b0f279334c7	3e48e334-f497-4f44-9922-73655cbc3209	0.00	148000.00	2026-05-04 00:00:00	\N	\N
97a8f79d-3302-46c8-9d7b-e8ba372d59af	927502bf-9d13-4cf6-87d8-552637d7215e	fd21d842-d122-4e90-bb30-e5b2e0fdc600	5245.10	0.00	2026-05-04 00:00:00	\N	\N
9b999444-7b24-4c2e-acf0-52ca3b6e58ee	927502bf-9d13-4cf6-87d8-552637d7215e	3e48e334-f497-4f44-9922-73655cbc3209	0.00	5245.10	2026-05-04 00:00:00	\N	\N
0247de0a-7c98-4099-afcf-98af090abaec	06d94365-67e1-4555-86dc-c4f840233e28	ab232e94-529e-422b-8590-adeddd18bbac	13008835.71	0.00	2026-05-12 00:00:00	\N	\N
5b11f5cf-e54c-44c5-986f-a4502aa638ab	06d94365-67e1-4555-86dc-c4f840233e28	ab80894d-7a79-41be-92ba-540fc52787d8	1561060.29	0.00	2026-05-12 00:00:00	\N	\N
06ab0985-7d6e-49fb-b276-92e3189d7e30	06d94365-67e1-4555-86dc-c4f840233e28	8a7b7484-d542-4891-b653-a9a664b86e65	0.00	14569896.00	2026-05-12 00:00:00	\N	\N
92a7a6df-5a4d-4280-8869-29169b0748db	42d646e5-429b-4461-bb52-0125c13fedf9	eb197584-ae22-48da-b174-b20e66aa595f	200000.00	0.00	2026-05-02 00:00:00	\N	\N
e6b2bda0-e6ae-4bcf-b2f6-aaea0d7cb566	42d646e5-429b-4461-bb52-0125c13fedf9	44feaa92-cf1d-4fbb-9023-f1f9e73def55	0.00	200000.00	2026-05-02 00:00:00	\N	\N
57737c70-fb8c-4854-847f-0e15a29a8d5b	1effa11a-ac17-4047-bc05-4c98d7d5ea62	9ef38108-e7d4-4119-9f24-9c65d501967d	2000000.00	0.00	2026-05-28 00:00:00	\N	\N
1cde97c2-801a-4749-958a-756e0cf58c67	1effa11a-ac17-4047-bc05-4c98d7d5ea62	e2b61343-45fb-43da-9974-d800b5fcbb93	0.00	2000000.00	2026-05-28 00:00:00	\N	\N
9f7a0e32-a3ec-4f2a-8066-c8cefe17a8c3	1effa11a-ac17-4047-bc05-4c98d7d5ea62	e2b61343-45fb-43da-9974-d800b5fcbb93	2000.00	0.00	2026-05-28 00:00:00	\N	\N
f8c6cf45-ee4b-443c-bb0c-ca7a670bad1a	1effa11a-ac17-4047-bc05-4c98d7d5ea62	d4c91fda-45de-4c62-928c-8025f856ed94	0.00	2000.00	2026-05-28 00:00:00	\N	\N
22c4a55a-a7ba-4c56-afef-934f39c42596	1effa11a-ac17-4047-bc05-4c98d7d5ea62	e2b61343-45fb-43da-9974-d800b5fcbb93	238000.00	0.00	2026-05-28 00:00:00	\N	\N
efbc7d04-63b9-4cfc-8471-9c80fdb9df9e	1effa11a-ac17-4047-bc05-4c98d7d5ea62	1f64b4e5-72ea-4403-bfe9-91fc7083ad80	0.00	238000.00	2026-05-28 00:00:00	\N	\N
7f8b502c-9f31-4673-80a0-b65b9305dd97	1effa11a-ac17-4047-bc05-4c98d7d5ea62	9ef38108-e7d4-4119-9f24-9c65d501967d	240000.00	0.00	2026-05-28 00:00:00	\N	\N
bd26c369-c861-4db8-ad70-969ce9785b22	1effa11a-ac17-4047-bc05-4c98d7d5ea62	aeaaad4b-dd56-464d-9758-06fc97f6d453	0.00	240000.00	2026-05-28 00:00:00	\N	\N
ae2813a4-c3e6-4059-83d5-e3e6112e4733	66fde351-72e3-45fa-a526-341d88b01ce8	7dee97f8-ef28-489b-8b18-e9ff0a1b9ba3	5245.10	0.00	2026-05-28 00:00:00	\N	\N
401dfea9-1bcc-48c9-8add-f6ee8734e53e	66fde351-72e3-45fa-a526-341d88b01ce8	fd21d842-d122-4e90-bb30-e5b2e0fdc600	0.00	5245.10	2026-05-28 00:00:00	\N	\N
632de682-1730-42f9-b2a3-77d82c7cd4dc	66fde351-72e3-45fa-a526-341d88b01ce8	44feaa92-cf1d-4fbb-9023-f1f9e73def55	200000.00	0.00	2026-05-28 00:00:00	\N	\N
3cda799b-ff02-4e30-96a8-3acd29b4ac61	66fde351-72e3-45fa-a526-341d88b01ce8	7dee97f8-ef28-489b-8b18-e9ff0a1b9ba3	0.00	200000.00	2026-05-28 00:00:00	\N	\N
4a0e0096-58a2-48c7-bdef-c667004c8f73	66fde351-72e3-45fa-a526-341d88b01ce8	7dee97f8-ef28-489b-8b18-e9ff0a1b9ba3	2240000.00	0.00	2026-05-28 00:00:00	\N	\N
2d4ff152-8b4b-46db-948c-df0e7753c722	66fde351-72e3-45fa-a526-341d88b01ce8	9ef38108-e7d4-4119-9f24-9c65d501967d	0.00	2240000.00	2026-05-28 00:00:00	\N	\N
354923fb-2a9c-4910-84a8-2b9018b3b894	708b6914-40c9-4839-af68-b05fee50e414	fd21d842-d122-4e90-bb30-e5b2e0fdc600	4120.00	0.00	2026-06-10 00:00:00	\N	\N
3ee87848-6d71-458d-b87f-00c09e10e2b4	708b6914-40c9-4839-af68-b05fee50e414	3e48e334-f497-4f44-9922-73655cbc3209	0.00	4120.00	2026-06-10 00:00:00	\N	\N
0556da6e-0fd1-4db1-8f90-0cbb4999ebb6	7bbddcd3-e108-4aa5-9e4e-8375f029cbb0	fd21d842-d122-4e90-bb30-e5b2e0fdc600	1210.00	0.00	2026-06-10 00:00:00	\N	\N
cd2872ae-70d3-4e3e-80e5-8c3db2ed055e	7bbddcd3-e108-4aa5-9e4e-8375f029cbb0	3e48e334-f497-4f44-9922-73655cbc3209	0.00	1210.00	2026-06-10 00:00:00	\N	\N
b026ac01-1dcc-4853-aa28-de541962a35a	b6344b4d-48a9-4301-9390-ea4310821ec3	fd21d842-d122-4e90-bb30-e5b2e0fdc600	72849.48	0.00	2026-06-10 00:00:00	\N	\N
579ed391-617f-4691-9c11-c76e49c8a2da	b6344b4d-48a9-4301-9390-ea4310821ec3	3e48e334-f497-4f44-9922-73655cbc3209	0.00	72849.48	2026-06-10 00:00:00	\N	\N
278bb960-0ba0-40f2-bf17-105a8eabba91	369d18f6-3b01-424c-9549-0f8f62cd8f9f	35ec3a42-1734-4a77-bd0f-e7c94b01e289	14569896.00	0.00	2026-06-10 00:00:00	\N	\N
a678b948-0b64-4778-8da0-bad260e219ce	369d18f6-3b01-424c-9549-0f8f62cd8f9f	3e48e334-f497-4f44-9922-73655cbc3209	0.00	14569896.00	2026-06-10 00:00:00	\N	\N
08f9f3cc-8195-4681-8211-23f724841dc4	8132dded-5210-4de0-9e2a-7fb0330c6420	9ef38108-e7d4-4119-9f24-9c65d501967d	824000.00	0.00	2026-06-10 00:00:00	\N	\N
ada6ef60-ab61-46f1-8ced-a3fc65f203a4	8132dded-5210-4de0-9e2a-7fb0330c6420	3e48e334-f497-4f44-9922-73655cbc3209	0.00	824000.00	2026-06-10 00:00:00	\N	\N
00d7d944-dd79-4f31-8378-b090b6427587	d303133e-e42c-49c3-94e5-1d4896961fe7	fd21d842-d122-4e90-bb30-e5b2e0fdc600	242000.00	0.00	2026-06-10 00:00:00	\N	\N
4dc3c9d3-1631-4128-a3a4-bd4a155ee52f	d303133e-e42c-49c3-94e5-1d4896961fe7	3e48e334-f497-4f44-9922-73655cbc3209	0.00	242000.00	2026-06-10 00:00:00	\N	\N
356ca640-a863-42a3-a86b-58dbb47b3f21	3607742a-a5b4-4ab8-ae50-1bd960fda873	3e48e334-f497-4f44-9922-73655cbc3209	18000000.00	0.00	2026-06-10 00:00:00	\N	\N
3193d785-5645-44a9-af97-2c7b993009fe	3607742a-a5b4-4ab8-ae50-1bd960fda873	a01dc215-847e-4ae7-9665-6e598d6d0cf6	0.00	18000000.00	2026-06-10 00:00:00	\N	\N
be804187-0c42-4ec4-a692-e52e97e50e62	ca007879-8cca-494d-b844-915675cfad3f	1f64b4e5-72ea-4403-bfe9-91fc7083ad80	148000.00	0.00	2026-06-01 00:00:00	\N	\N
aa51e08e-b007-4966-8064-c8a18a81681c	ca007879-8cca-494d-b844-915675cfad3f	3e48e334-f497-4f44-9922-73655cbc3209	0.00	148000.00	2026-06-01 00:00:00	\N	\N
57a86b4d-e5fe-4de7-9d9b-429fdcc2b68e	0d127988-dbfe-42dd-a5c7-cb1fbb1ea1e0	d4c91fda-45de-4c62-928c-8025f856ed94	2000.00	0.00	2026-06-01 00:00:00	\N	\N
45dbd8a6-0d3b-4aa2-8c3b-5ed8ac9f779e	0d127988-dbfe-42dd-a5c7-cb1fbb1ea1e0	3e48e334-f497-4f44-9922-73655cbc3209	0.00	2000.00	2026-06-01 00:00:00	\N	\N
8947f317-9326-4f9b-8eb9-6334e80c91c5	6c4c0f46-2bd8-4a3a-8607-bb22d0501e2d	9ef38108-e7d4-4119-9f24-9c65d501967d	2000000.00	0.00	2026-06-28 00:00:00	\N	\N
9d1ef19a-0c14-4e20-b849-ef9aab36572c	6c4c0f46-2bd8-4a3a-8607-bb22d0501e2d	e2b61343-45fb-43da-9974-d800b5fcbb93	0.00	2000000.00	2026-06-28 00:00:00	\N	\N
e1fdc935-b29d-49eb-9e44-9239673713a3	6c4c0f46-2bd8-4a3a-8607-bb22d0501e2d	e2b61343-45fb-43da-9974-d800b5fcbb93	2000.00	0.00	2026-06-28 00:00:00	\N	\N
c3d0bed1-e19d-4ea4-87fc-9b002212c760	6c4c0f46-2bd8-4a3a-8607-bb22d0501e2d	d4c91fda-45de-4c62-928c-8025f856ed94	0.00	2000.00	2026-06-28 00:00:00	\N	\N
398686c5-0720-4885-92df-300efc2b6224	6c4c0f46-2bd8-4a3a-8607-bb22d0501e2d	e2b61343-45fb-43da-9974-d800b5fcbb93	238000.00	0.00	2026-06-28 00:00:00	\N	\N
3f9232ae-333e-427b-b037-265ab1327fd9	6c4c0f46-2bd8-4a3a-8607-bb22d0501e2d	1f64b4e5-72ea-4403-bfe9-91fc7083ad80	0.00	238000.00	2026-06-28 00:00:00	\N	\N
aae18e2c-ddb0-4a23-a3ff-7dd484157840	6c4c0f46-2bd8-4a3a-8607-bb22d0501e2d	9ef38108-e7d4-4119-9f24-9c65d501967d	240000.00	0.00	2026-06-28 00:00:00	\N	\N
8b9d24bd-cf6c-46a4-961c-74c3cdac7d46	6c4c0f46-2bd8-4a3a-8607-bb22d0501e2d	aeaaad4b-dd56-464d-9758-06fc97f6d453	0.00	240000.00	2026-06-28 00:00:00	\N	\N
660f4587-d525-4e9f-8f30-a6c222e25145	bde731f2-5d13-45ef-a0aa-da022876d377	7dee97f8-ef28-489b-8b18-e9ff0a1b9ba3	320179.48	0.00	2026-06-28 00:00:00	\N	\N
12c881fb-d7ea-40c1-89b0-44247998ff93	bde731f2-5d13-45ef-a0aa-da022876d377	fd21d842-d122-4e90-bb30-e5b2e0fdc600	0.00	320179.48	2026-06-28 00:00:00	\N	\N
96023324-89e5-44a3-9df7-e1baf56d19ae	bde731f2-5d13-45ef-a0aa-da022876d377	7dee97f8-ef28-489b-8b18-e9ff0a1b9ba3	3064000.00	0.00	2026-06-28 00:00:00	\N	\N
145b8ebd-4016-4248-9988-ceacc6f81b25	bde731f2-5d13-45ef-a0aa-da022876d377	9ef38108-e7d4-4119-9f24-9c65d501967d	0.00	3064000.00	2026-06-28 00:00:00	\N	\N
c581ad9f-f55a-4999-8536-6a4f116e2cee	627dc252-7fd6-4287-9cfe-abed79ff56a1	3e48e334-f497-4f44-9922-73655cbc3209	1000000.00	0.00	2026-04-09 00:00:00	\N	\N
fefca012-ebe7-4291-844d-85b19dcc00d2	627dc252-7fd6-4287-9cfe-abed79ff56a1	a01dc215-847e-4ae7-9665-6e598d6d0cf6	0.00	1000000.00	2026-04-09 00:00:00	\N	\N
bfb229fc-12ed-4bde-b84e-39e613ca6041	aa0dad12-d8c4-4d52-94c2-2fe81086545e	fd21d842-d122-4e90-bb30-e5b2e0fdc600	3594.64	0.00	2026-04-28 00:00:00	\N	\N
3229eafb-061e-4d54-8a76-d58ca4cb3de6	aa0dad12-d8c4-4d52-94c2-2fe81086545e	3e48e334-f497-4f44-9922-73655cbc3209	0.00	3594.64	2026-04-28 00:00:00	\N	\N
9b3be244-476e-45ad-9619-04d912aba6cc	ed998172-0562-425c-9a66-1ac60d0759b2	fd21d842-d122-4e90-bb30-e5b2e0fdc600	250.00	0.00	2026-04-16 00:00:00	\N	\N
fde075bd-efc4-4193-90a0-309679b3fbac	ed998172-0562-425c-9a66-1ac60d0759b2	3e48e334-f497-4f44-9922-73655cbc3209	0.00	250.00	2026-04-16 00:00:00	\N	\N
43bb09d8-156d-447e-9e2c-f74a8783798b	d97199c4-8389-4192-9d7b-0ae587eb0af4	fd21d842-d122-4e90-bb30-e5b2e0fdc600	11000.00	0.00	2026-04-10 00:00:00	\N	\N
25a61506-8448-4b4d-a786-69610d58518b	d97199c4-8389-4192-9d7b-0ae587eb0af4	3e48e334-f497-4f44-9922-73655cbc3209	0.00	11000.00	2026-04-10 00:00:00	\N	\N
e2832a3e-216b-40dd-b6e9-3028d8b9cb27	2e51fd5a-212c-4cba-a3d5-afa2e97c54b9	3e48e334-f497-4f44-9922-73655cbc3209	8758400.00	0.00	2026-04-29 00:00:00	\N	\N
474891f8-d9b9-434e-87f5-323ce742940a	2e51fd5a-212c-4cba-a3d5-afa2e97c54b9	eb197584-ae22-48da-b174-b20e66aa595f	0.00	8758400.00	2026-04-29 00:00:00	\N	\N
c24ca750-cde9-4d88-8eb1-92b783ada9da	af31e6c4-e24e-4565-baa5-438168e57987	3e48e334-f497-4f44-9922-73655cbc3209	0.00	718928.00	2026-04-28 00:00:00	\N	\N
9202d1e5-6990-4cc6-aa4c-cc03acc91b4f	3265a466-9bd0-4b8b-b69c-13f1b18f5ca0	8a7b7484-d542-4891-b653-a9a664b86e65	50000.00	0.00	2026-04-16 00:00:00	\N	\N
0dc9365f-8bf7-4246-94b2-3bb23bc7495b	3265a466-9bd0-4b8b-b69c-13f1b18f5ca0	3e48e334-f497-4f44-9922-73655cbc3209	0.00	50000.00	2026-04-16 00:00:00	\N	\N
dc4eccd6-f6c0-476e-9fec-81e3b096050a	2172cdba-7065-4335-9919-5f7bf069c4d9	ab80894d-7a79-41be-92ba-540fc52787d8	77028.00	0.00	2026-04-28 00:00:00	\N	\N
aadcbc98-91b8-4374-bc7c-2b2492aff3b0	2172cdba-7065-4335-9919-5f7bf069c4d9	10acb533-72b4-46dc-8b19-38c57f6f2fe3	0.00	718928.00	2026-04-28 00:00:00	\N	\N
539c07f7-b138-4bcc-a604-826f0a06e704	f31b9a57-a7c1-4d39-8733-91400bd395f9	9ef38108-e7d4-4119-9f24-9c65d501967d	317750.00	0.00	2026-04-28 00:00:00	\N	\N
fec514a2-0dcc-40b2-ad53-0d18477a3db7	f31b9a57-a7c1-4d39-8733-91400bd395f9	e2b61343-45fb-43da-9974-d800b5fcbb93	0.00	317750.00	2026-04-28 00:00:00	\N	\N
1224f643-75e4-4ad7-845a-ef4b5b3b15f7	f31b9a57-a7c1-4d39-8733-91400bd395f9	e2b61343-45fb-43da-9974-d800b5fcbb93	317.75	0.00	2026-04-28 00:00:00	\N	\N
def888d4-3a34-40e7-aa48-8cdaa9648349	f31b9a57-a7c1-4d39-8733-91400bd395f9	d4c91fda-45de-4c62-928c-8025f856ed94	0.00	317.75	2026-04-28 00:00:00	\N	\N
2f352314-0a61-40db-b67b-499d9ab1f367	f31b9a57-a7c1-4d39-8733-91400bd395f9	e2b61343-45fb-43da-9974-d800b5fcbb93	37812.25	0.00	2026-04-28 00:00:00	\N	\N
65222321-c823-48c5-9228-42fc24160400	f31b9a57-a7c1-4d39-8733-91400bd395f9	1f64b4e5-72ea-4403-bfe9-91fc7083ad80	0.00	37812.25	2026-04-28 00:00:00	\N	\N
71f323c9-51c0-4d37-ae3e-1916d0778269	f31b9a57-a7c1-4d39-8733-91400bd395f9	9ef38108-e7d4-4119-9f24-9c65d501967d	38130.00	0.00	2026-04-28 00:00:00	\N	\N
2c1a5fd3-9316-4043-bf4f-6c9bb8d4a538	f31b9a57-a7c1-4d39-8733-91400bd395f9	aeaaad4b-dd56-464d-9758-06fc97f6d453	0.00	38130.00	2026-04-28 00:00:00	\N	\N
7c4df0c6-8cf8-4f01-b25a-c130c8ac2b44	9ac4d545-e899-4955-930a-b59b3444a9e4	7dee97f8-ef28-489b-8b18-e9ff0a1b9ba3	14844.64	0.00	2026-04-28 00:00:00	\N	\N
e60ca9ff-8712-4dd2-a648-e2ea23148dfa	9ac4d545-e899-4955-930a-b59b3444a9e4	fd21d842-d122-4e90-bb30-e5b2e0fdc600	0.00	14844.64	2026-04-28 00:00:00	\N	\N
7eabf80e-69d3-4662-8fa3-de5c66d37ae9	9ac4d545-e899-4955-930a-b59b3444a9e4	7dee97f8-ef28-489b-8b18-e9ff0a1b9ba3	355880.00	0.00	2026-04-28 00:00:00	\N	\N
07e79b84-ef7d-4725-8fdf-a5f1103ea5cf	9ac4d545-e899-4955-930a-b59b3444a9e4	9ef38108-e7d4-4119-9f24-9c65d501967d	0.00	355880.00	2026-04-28 00:00:00	\N	\N
f67cf38b-40c6-4ab3-a056-fce869c530ac	de23966a-d8bc-4c74-abec-cbe0c5699600	fd21d842-d122-4e90-bb30-e5b2e0fdc600	67600.00	0.00	2026-05-22 00:00:00	\N	\N
5e8b12cf-1e41-4f32-8556-b2e1cc548245	de23966a-d8bc-4c74-abec-cbe0c5699600	3e48e334-f497-4f44-9922-73655cbc3209	0.00	67600.00	2026-05-22 00:00:00	\N	\N
f21dfe11-d28d-4012-887c-b3d19d3bc956	cf54202e-1701-49a3-95d9-e9e4812eeaf7	fd21d842-d122-4e90-bb30-e5b2e0fdc600	115000.00	0.00	2026-05-18 00:00:00	\N	\N
0bc35d9a-6ebd-49ad-ab1b-588cbb2b8ad3	cf54202e-1701-49a3-95d9-e9e4812eeaf7	3e48e334-f497-4f44-9922-73655cbc3209	0.00	115000.00	2026-05-18 00:00:00	\N	\N
d84c6eb4-02ec-4609-9898-4397cafdb5a6	219c3b57-72b1-40f6-a85d-a5222efc6c40	fd21d842-d122-4e90-bb30-e5b2e0fdc600	135.00	0.00	2026-05-12 00:00:00	\N	\N
8bc7d499-7dd6-41d6-b51c-4da008917e94	219c3b57-72b1-40f6-a85d-a5222efc6c40	3e48e334-f497-4f44-9922-73655cbc3209	0.00	135.00	2026-05-12 00:00:00	\N	\N
dc0152c7-594a-44a6-b217-56077ce56979	6878037d-e213-42b4-8a3f-abfa8418cd3d	fd21d842-d122-4e90-bb30-e5b2e0fdc600	10000.00	0.00	2026-05-04 00:00:00	\N	\N
9a4a1b7e-87a8-4f69-afdf-f0eb8a8f1b80	6878037d-e213-42b4-8a3f-abfa8418cd3d	3e48e334-f497-4f44-9922-73655cbc3209	0.00	10000.00	2026-05-04 00:00:00	\N	\N
f535e887-0faf-4f0d-a0fc-4921259da4d1	2172cdba-7065-4335-9919-5f7bf069c4d9	ab232e94-529e-422b-8590-adeddd18bbac	641900.00	0.00	2026-04-28 00:00:00	\N	\N
24ddb751-8fe6-4d27-94ca-fdd769c865d0	c4b78d9a-9d79-4fd1-bd2e-4a320f43dcc3	fa6ea877-5e4a-4444-b5bb-c46eea3294d2	23000000.00	0.00	2026-05-18 00:00:00	\N	\N
4766f481-aae6-4f8b-8634-68abc0a95e82	c4b78d9a-9d79-4fd1-bd2e-4a320f43dcc3	3e48e334-f497-4f44-9922-73655cbc3209	0.00	23000000.00	2026-05-18 00:00:00	\N	\N
8cc46c5c-6da5-4473-9e46-1d10c500a23f	7d4683e1-8fe0-46d7-b92d-ae489a109a58	3e48e334-f497-4f44-9922-73655cbc3209	9800.00	0.00	2026-05-18 00:00:00	\N	\N
426afda7-c029-4e7c-827e-d420d68ab356	7d4683e1-8fe0-46d7-b92d-ae489a109a58	7295850d-efdd-46ab-bba0-50379da90c85	0.00	9800.00	2026-05-18 00:00:00	\N	\N
dd138773-dd41-473a-b034-76e21e6d743f	3fe7aafa-78ab-4d78-89a1-9294678c3503	3e48e334-f497-4f44-9922-73655cbc3209	9800.00	0.00	2026-05-18 00:00:00	\N	\N
11421390-ac83-4ceb-8529-3272b207f324	3fe7aafa-78ab-4d78-89a1-9294678c3503	7295850d-efdd-46ab-bba0-50379da90c85	0.00	9800.00	2026-05-18 00:00:00	\N	\N
facd5bc3-51f0-4687-9e59-987de32ef44e	b65d11bc-5cff-41d2-b472-57219d107a2f	3e48e334-f497-4f44-9922-73655cbc3209	9800.00	0.00	2026-05-04 00:00:00	\N	\N
1af62d34-c0e5-4ce7-b123-6c345e9a2770	b65d11bc-5cff-41d2-b472-57219d107a2f	7295850d-efdd-46ab-bba0-50379da90c85	0.00	9800.00	2026-05-04 00:00:00	\N	\N
07240be2-a3e2-410e-bf00-70e8649fd054	316bf16a-1bf7-44ce-8321-35a237c99395	8a7b7484-d542-4891-b653-a9a664b86e65	27000.00	0.00	2026-05-12 00:00:00	\N	\N
daef65c3-d557-4fd1-a5cd-23aab31f818d	316bf16a-1bf7-44ce-8321-35a237c99395	3e48e334-f497-4f44-9922-73655cbc3209	0.00	27000.00	2026-05-12 00:00:00	\N	\N
d8c9a840-8ec9-40cd-8b02-0f68aabb34a6	78e4fdc3-f8d3-4994-aa1f-190e2cf23341	3e48e334-f497-4f44-9922-73655cbc3209	22000000.00	0.00	2026-05-07 00:00:00	\N	\N
df814273-efa1-4749-a1f2-7eee1079d855	78e4fdc3-f8d3-4994-aa1f-190e2cf23341	eb197584-ae22-48da-b174-b20e66aa595f	0.00	22000000.00	2026-05-07 00:00:00	\N	\N
c8d37c98-e28c-42b6-ba14-7f3bde05a621	2b3e652d-fb0e-4281-9400-80e74c9e4e88	8a7b7484-d542-4891-b653-a9a664b86e65	317.50	0.00	2026-05-04 00:00:00	\N	\N
efd4b4c6-b87d-40f1-8e71-549c15d294b9	2b3e652d-fb0e-4281-9400-80e74c9e4e88	3e48e334-f497-4f44-9922-73655cbc3209	0.00	317.50	2026-05-04 00:00:00	\N	\N
a1d65be1-3ae1-4a38-87fc-bfd8650cb098	f2de3f2a-a296-4918-b407-7dd1c17de6aa	aeaaad4b-dd56-464d-9758-06fc97f6d453	38130.00	0.00	2026-05-04 00:00:00	\N	\N
39e43133-5913-4789-abb9-9f1bc2e2874c	f2de3f2a-a296-4918-b407-7dd1c17de6aa	3e48e334-f497-4f44-9922-73655cbc3209	0.00	38130.00	2026-05-04 00:00:00	\N	\N
eeead53e-f17c-4811-b261-823858bb2274	e8bc4baa-35fc-438b-8940-3f02fdc94e81	aeaaad4b-dd56-464d-9758-06fc97f6d453	317750.00	0.00	2026-05-04 00:00:00	\N	\N
1e0f536e-89df-4384-885c-cadd259ee49a	e8bc4baa-35fc-438b-8940-3f02fdc94e81	3e48e334-f497-4f44-9922-73655cbc3209	0.00	317750.00	2026-05-04 00:00:00	\N	\N
7e529779-d53f-4e20-89db-99b523a6931a	be229a41-64c1-43e5-8059-e20e000adc71	9ef38108-e7d4-4119-9f24-9c65d501967d	2000000.00	0.00	2026-05-04 00:00:00	\N	\N
a308e2e0-07ed-4ae9-9c21-7748f0aa5aaa	be229a41-64c1-43e5-8059-e20e000adc71	3e48e334-f497-4f44-9922-73655cbc3209	0.00	2000000.00	2026-05-04 00:00:00	\N	\N
e975bba6-dddf-42a6-8dfc-49bdf1f2be61	0bd3a180-cd59-4ea4-92ea-f3e09d3df52f	eb197584-ae22-48da-b174-b20e66aa595f	8758400.00	0.00	2026-05-04 00:00:00	\N	\N
860b1f6e-a157-435e-ac11-0403a8492996	0bd3a180-cd59-4ea4-92ea-f3e09d3df52f	44feaa92-cf1d-4fbb-9023-f1f9e73def55	0.00	7820000.00	2026-05-04 00:00:00	\N	\N
408709a2-33dd-4e74-bd50-3360be5b57ec	0bd3a180-cd59-4ea4-92ea-f3e09d3df52f	1f64b4e5-72ea-4403-bfe9-91fc7083ad80	0.00	938400.00	2026-05-04 00:00:00	\N	\N
59a208fe-9dc3-4878-96b4-d7b9ccf11504	c6cba1dd-ce54-4cb2-8c74-2fd6d514da37	eb197584-ae22-48da-b174-b20e66aa595f	10000.00	0.00	2026-05-01 00:00:00	\N	\N
debaec0d-c1ce-435d-a694-e481d3a9bf80	c6cba1dd-ce54-4cb2-8c74-2fd6d514da37	44feaa92-cf1d-4fbb-9023-f1f9e73def55	0.00	8928.58	2026-05-01 00:00:00	\N	\N
0fc98cbb-13a4-40b4-86a3-d46873919b28	c6cba1dd-ce54-4cb2-8c74-2fd6d514da37	1f64b4e5-72ea-4403-bfe9-91fc7083ad80	0.00	1071.42	2026-05-01 00:00:00	\N	\N
9a917a30-e805-4bdc-9110-8a67f87eb1b0	f45ceb7e-a022-4c72-b8dd-5d71d54492f8	eb197584-ae22-48da-b174-b20e66aa595f	20000.00	0.00	2026-05-16 00:00:00	\N	\N
c6709ae2-9cab-49a1-aceb-8bf509c75c9c	f45ceb7e-a022-4c72-b8dd-5d71d54492f8	44feaa92-cf1d-4fbb-9023-f1f9e73def55	0.00	17857.15	2026-05-16 00:00:00	\N	\N
f8c1ad06-b3ec-4b1c-8a3e-aabe9a5fdf58	f45ceb7e-a022-4c72-b8dd-5d71d54492f8	1f64b4e5-72ea-4403-bfe9-91fc7083ad80	0.00	2142.85	2026-05-16 00:00:00	\N	\N
5ef4242a-c065-44c5-88a0-8f9384cb700a	b2ce2456-49c1-422a-9191-17e76ed3c86d	7dee97f8-ef28-489b-8b18-e9ff0a1b9ba3	192735.00	0.00	2026-05-28 00:00:00	\N	\N
b5a77068-f0d2-437f-8e90-61659c50e358	b2ce2456-49c1-422a-9191-17e76ed3c86d	fd21d842-d122-4e90-bb30-e5b2e0fdc600	0.00	192735.00	2026-05-28 00:00:00	\N	\N
07ec14e2-43b2-4cee-85fd-9bee80a99647	b2ce2456-49c1-422a-9191-17e76ed3c86d	7dee97f8-ef28-489b-8b18-e9ff0a1b9ba3	2000000.00	0.00	2026-05-28 00:00:00	\N	\N
a60d867b-eace-40cb-8378-b86a6869dd0f	b2ce2456-49c1-422a-9191-17e76ed3c86d	9ef38108-e7d4-4119-9f24-9c65d501967d	0.00	2000000.00	2026-05-28 00:00:00	\N	\N
f0b1d254-0af6-4ae5-a1c5-eb52099d6655	b2ce2456-49c1-422a-9191-17e76ed3c86d	44feaa92-cf1d-4fbb-9023-f1f9e73def55	7846785.73	0.00	2026-05-28 00:00:00	\N	\N
1508bd25-d4cf-4090-841a-884b9e239d27	b2ce2456-49c1-422a-9191-17e76ed3c86d	7dee97f8-ef28-489b-8b18-e9ff0a1b9ba3	0.00	7846785.73	2026-05-28 00:00:00	\N	\N
f10f1b0e-f9cf-4394-ad9c-5fd75a2984ea	7d1d1831-85dd-4a60-8dca-0c57933c315d	fd21d842-d122-4e90-bb30-e5b2e0fdc600	2200.00	0.00	2026-06-24 00:00:00	\N	\N
6bb82974-9a10-45bc-acd9-9e20b392ab18	7d1d1831-85dd-4a60-8dca-0c57933c315d	3e48e334-f497-4f44-9922-73655cbc3209	0.00	2200.00	2026-06-24 00:00:00	\N	\N
3d6b3200-6357-4134-886a-1db2f04c4049	91a3ebac-7df7-4486-b822-70297179e97e	fd21d842-d122-4e90-bb30-e5b2e0fdc600	150000.00	0.00	2026-06-05 00:00:00	\N	\N
f62a6a13-9cb2-441b-9ece-053386cd3b73	91a3ebac-7df7-4486-b822-70297179e97e	3e48e334-f497-4f44-9922-73655cbc3209	0.00	150000.00	2026-06-05 00:00:00	\N	\N
9955209e-c19b-402f-9884-9298423df6b4	b1d210e7-b80d-4ea8-90a1-9ffebade3b93	fd21d842-d122-4e90-bb30-e5b2e0fdc600	58800.00	0.00	2026-06-09 00:00:00	\N	\N
2a2e5f45-f4a7-4797-a823-fe124926b8df	b1d210e7-b80d-4ea8-90a1-9ffebade3b93	3e48e334-f497-4f44-9922-73655cbc3209	0.00	58800.00	2026-06-09 00:00:00	\N	\N
c6224c1d-907d-4265-bed7-3cd63ff5f481	d9ce31f7-dd4e-4c95-966b-773f593b0375	fd21d842-d122-4e90-bb30-e5b2e0fdc600	86150.66	0.00	2026-06-11 00:00:00	\N	\N
9147bf6d-816b-47fe-8a1d-82bd2f952396	d9ce31f7-dd4e-4c95-966b-773f593b0375	3e48e334-f497-4f44-9922-73655cbc3209	0.00	86150.66	2026-06-11 00:00:00	\N	\N
d0553de4-1dc9-48e6-a7d4-a1d2f81d97ba	1a42d156-cfc7-42d4-8857-69eb740375bc	fd21d842-d122-4e90-bb30-e5b2e0fdc600	50000.00	0.00	2026-06-19 00:00:00	\N	\N
0d6a9602-c649-4ca6-9244-d76661e90424	1a42d156-cfc7-42d4-8857-69eb740375bc	3e48e334-f497-4f44-9922-73655cbc3209	0.00	50000.00	2026-06-19 00:00:00	\N	\N
fc95add8-88c3-4469-ac99-9d2f6c9959ad	e7b9c4f6-4f29-473d-9773-4efb4e829728	fd21d842-d122-4e90-bb30-e5b2e0fdc600	150000.00	0.00	2026-06-04 00:00:00	\N	\N
4f6ed430-8194-448e-a22c-bc900025554f	e7b9c4f6-4f29-473d-9773-4efb4e829728	3e48e334-f497-4f44-9922-73655cbc3209	0.00	150000.00	2026-06-04 00:00:00	\N	\N
75cbf3b8-81c1-419c-841f-46d8290233ea	a1003312-7511-483f-8163-1deb296f8e5c	fd21d842-d122-4e90-bb30-e5b2e0fdc600	1367296.00	0.00	2026-06-04 00:00:00	\N	\N
48933c8b-8bd4-4aaf-871a-98e68af58f26	a1003312-7511-483f-8163-1deb296f8e5c	3e48e334-f497-4f44-9922-73655cbc3209	0.00	1367296.00	2026-06-04 00:00:00	\N	\N
adfcf834-07e1-4cc5-a66b-e811ad0518be	89c82fc4-b714-4284-9feb-10e0555d3177	fd21d842-d122-4e90-bb30-e5b2e0fdc600	10000.00	0.00	2026-06-04 00:00:00	\N	\N
59243f62-9277-4fc3-bbbc-febb10b3fc8e	89c82fc4-b714-4284-9feb-10e0555d3177	3e48e334-f497-4f44-9922-73655cbc3209	0.00	10000.00	2026-06-04 00:00:00	\N	\N
109426ac-9406-44df-a4ff-e04a2df305ec	21be39e8-aa00-4b16-906c-fe79c21d3e3b	8a7b7484-d542-4891-b653-a9a664b86e65	440000.00	0.00	2026-06-24 00:00:00	\N	\N
b69d72b3-6385-48d9-9c4e-39482b1acb70	21be39e8-aa00-4b16-906c-fe79c21d3e3b	3e48e334-f497-4f44-9922-73655cbc3209	0.00	440000.00	2026-06-24 00:00:00	\N	\N
317d8fb8-0746-4e5c-abcb-23a345c6db49	d3b7b6ff-39ed-4f60-b72a-cb0f5ef56e51	3e48e334-f497-4f44-9922-73655cbc3209	0.00	11760000.00	2026-06-09 00:00:00	\N	\N
dd49c693-9c47-45cf-8436-cd19eaeec372	f1791b1a-0bfc-400c-9174-bf34095b8ee1	3e48e334-f497-4f44-9922-73655cbc3209	12900000.00	0.00	2026-06-01 00:00:00	\N	\N
2b8b5f29-4fe9-4d11-9a42-9901e6a6bc0d	f1791b1a-0bfc-400c-9174-bf34095b8ee1	eb197584-ae22-48da-b174-b20e66aa595f	0.00	12900000.00	2026-06-01 00:00:00	\N	\N
a5f8dcde-f008-4352-af13-a675560c601b	ac054429-ae2a-4031-8118-ff6aee3e0307	8a7b7484-d542-4891-b653-a9a664b86e65	17230131.20	0.00	2026-06-11 00:00:00	\N	\N
b5df0fac-d58a-4609-b7a0-893ede0580f6	ac054429-ae2a-4031-8118-ff6aee3e0307	3e48e334-f497-4f44-9922-73655cbc3209	0.00	17230131.20	2026-06-11 00:00:00	\N	\N
50e3277c-52a0-4b5d-a7f1-ceff33524c97	01b8648a-010f-42a3-b6ec-54288965b3d2	3e48e334-f497-4f44-9922-73655cbc3209	3244000.00	0.00	2026-06-16 00:00:00	\N	\N
cfdaabec-8df6-4c80-8239-14f1df84fc99	01b8648a-010f-42a3-b6ec-54288965b3d2	eb197584-ae22-48da-b174-b20e66aa595f	0.00	3244000.00	2026-06-16 00:00:00	\N	\N
ebad0808-10f9-4a53-9f1f-001e63e2efb1	68431629-82a5-4424-8513-0a353d73847a	69358c02-20df-4da7-ba57-3564120994f6	3000000.00	0.00	2026-06-02 00:00:00	\N	\N
87973d2c-5a5f-4063-815a-da695545fc05	68431629-82a5-4424-8513-0a353d73847a	3e48e334-f497-4f44-9922-73655cbc3209	0.00	3000000.00	2026-06-02 00:00:00	\N	\N
d5b2e15b-9965-4f35-83e2-ca2ac4f2ab71	20968e04-8198-489b-9bf2-0c2137596932	3e48e334-f497-4f44-9922-73655cbc3209	3000000.00	0.00	2026-06-12 00:00:00	\N	\N
7ba4e9a9-c20a-4598-b640-10042b6ede19	20968e04-8198-489b-9bf2-0c2137596932	7295850d-efdd-46ab-bba0-50379da90c85	0.00	3000000.00	2026-06-12 00:00:00	\N	\N
69ebb950-d654-4d7d-b144-bfe58e4c595c	077b80f7-1e33-45f9-9e92-81dc082d6a78	7295850d-efdd-46ab-bba0-50379da90c85	10000000.00	0.00	2026-06-19 00:00:00	\N	\N
05112ab6-3f75-425a-bd9d-cc0de7d275af	077b80f7-1e33-45f9-9e92-81dc082d6a78	3e48e334-f497-4f44-9922-73655cbc3209	0.00	10000000.00	2026-06-19 00:00:00	\N	\N
e0b74f16-58e7-4272-b817-b71b1915968c	bdd58d95-d287-401f-8d36-56a41b35faa0	fa6ea877-5e4a-4444-b5bb-c46eea3294d2	30000000.00	0.00	2026-06-05 00:00:00	\N	\N
69d85e95-7e75-4905-a937-eb3dc740e437	bdd58d95-d287-401f-8d36-56a41b35faa0	3e48e334-f497-4f44-9922-73655cbc3209	0.00	30000000.00	2026-06-05 00:00:00	\N	\N
92fe04ac-9d55-4e46-a982-557701ceaaef	5506b7cd-c391-49ec-8b80-36fb8c102c5e	fa6ea877-5e4a-4444-b5bb-c46eea3294d2	30000000.00	0.00	2026-06-04 00:00:00	\N	\N
f982aa01-0955-4b05-807a-27d236284ea6	5506b7cd-c391-49ec-8b80-36fb8c102c5e	3e48e334-f497-4f44-9922-73655cbc3209	0.00	30000000.00	2026-06-04 00:00:00	\N	\N
2539bb49-e165-4188-a7e7-588d442877b2	7b65e3d5-7721-4e6b-ad83-8e745596fdf4	3e48e334-f497-4f44-9922-73655cbc3209	69090000.00	0.00	2026-06-05 00:00:00	\N	\N
8f00b2c4-aaa3-49f6-a424-471c6832f29a	7b65e3d5-7721-4e6b-ad83-8e745596fdf4	eb197584-ae22-48da-b174-b20e66aa595f	0.00	69090000.00	2026-06-05 00:00:00	\N	\N
015378ab-883b-4a0f-aa15-462bf0f087c2	d9882e12-e27a-4f4d-beeb-a5b4102befc6	3e48e334-f497-4f44-9922-73655cbc3209	5376000.00	0.00	2026-06-04 00:00:00	\N	\N
2320fa94-bb35-4519-9cf9-009052a068d9	d9882e12-e27a-4f4d-beeb-a5b4102befc6	eb197584-ae22-48da-b174-b20e66aa595f	0.00	5376000.00	2026-06-04 00:00:00	\N	\N
c031b722-b7a9-491c-8fdd-25fefcb59953	821ff739-ceb3-468b-a469-3188c9c2adfe	3e48e334-f497-4f44-9922-73655cbc3209	0.00	273459200.00	2026-06-04 00:00:00	\N	\N
d065e74a-775c-4856-8467-430cc05750d6	b0b6bda9-3e50-483f-96e1-68599833266f	1f64b4e5-72ea-4403-bfe9-91fc7083ad80	864586.29	0.00	2026-06-01 00:00:00	\N	\N
5cb42a2b-3dcf-43d0-b8c8-726c95922b37	b0b6bda9-3e50-483f-96e1-68599833266f	3e48e334-f497-4f44-9922-73655cbc3209	0.00	864586.29	2026-06-01 00:00:00	\N	\N
e4556371-4033-45cf-b789-9bfc2c7cc633	53761d90-2d33-4fe6-ae87-ba0ffd3c1264	1f64b4e5-72ea-4403-bfe9-91fc7083ad80	37812.25	0.00	2026-06-01 00:00:00	\N	\N
bd8d8791-9d30-4121-9b12-e0b58a0e3582	53761d90-2d33-4fe6-ae87-ba0ffd3c1264	3e48e334-f497-4f44-9922-73655cbc3209	0.00	37812.25	2026-06-01 00:00:00	\N	\N
63977387-077d-45f1-90bf-12f551296160	cf27399b-5ba6-4d9c-a193-aed14256a4af	1f64b4e5-72ea-4403-bfe9-91fc7083ad80	38130.00	0.00	2026-06-01 00:00:00	\N	\N
ddea1ddf-6b70-4e0c-ac35-3e2c003f1606	cf27399b-5ba6-4d9c-a193-aed14256a4af	3e48e334-f497-4f44-9922-73655cbc3209	0.00	38130.00	2026-06-01 00:00:00	\N	\N
12a1e7ee-7f17-4116-b0ef-f9acdfc3fe7d	a67fe804-1e2b-4797-8e39-d7131fbef04b	9ef38108-e7d4-4119-9f24-9c65d501967d	2000000.00	0.00	2026-06-04 00:00:00	\N	\N
7fd1ec6e-5b2f-42a7-9a59-269771247358	a67fe804-1e2b-4797-8e39-d7131fbef04b	3e48e334-f497-4f44-9922-73655cbc3209	0.00	2000000.00	2026-06-04 00:00:00	\N	\N
aed6b5cf-f2a9-46ad-8874-7a03e4c31602	550d7573-4c1f-47b7-8e1d-e141883d295d	fd21d842-d122-4e90-bb30-e5b2e0fdc600	540.00	0.00	2026-06-03 00:00:00	\N	\N
7d9ddce3-12e2-4b92-90c9-82d16d2fac8c	550d7573-4c1f-47b7-8e1d-e141883d295d	3e48e334-f497-4f44-9922-73655cbc3209	0.00	540.00	2026-06-03 00:00:00	\N	\N
6cd31fd4-383b-4c3b-8ce8-35de2ceee03a	41de570d-fbc4-456a-a719-283eb13c744d	8a7b7484-d542-4891-b653-a9a664b86e65	317.50	0.00	2026-06-01 00:00:00	\N	\N
c5f400b0-94a6-4c12-9118-7694873c9e21	41de570d-fbc4-456a-a719-283eb13c744d	3e48e334-f497-4f44-9922-73655cbc3209	0.00	317.50	2026-06-01 00:00:00	\N	\N
f618f512-dc0e-4fe7-8ae7-4c3134435ad9	cb806713-eb7e-4d54-bdda-1275cdfd268a	fd21d842-d122-4e90-bb30-e5b2e0fdc600	15000.00	0.00	2026-06-02 00:00:00	\N	\N
935f68a7-d9c7-4fab-b081-ce76ce8635f3	cb806713-eb7e-4d54-bdda-1275cdfd268a	3e48e334-f497-4f44-9922-73655cbc3209	0.00	15000.00	2026-06-02 00:00:00	\N	\N
92def10d-0213-44ff-9acd-93e32b1bb119	e83e6bc6-2603-4e58-a51d-d69857399d3b	3e48e334-f497-4f44-9922-73655cbc3209	292640000.00	0.00	2026-06-03 00:00:00	\N	\N
b38cee86-8aaa-4e5d-a1ce-dade9291f3b4	e83e6bc6-2603-4e58-a51d-d69857399d3b	eb197584-ae22-48da-b174-b20e66aa595f	0.00	292640000.00	2026-06-03 00:00:00	\N	\N
d76d9d64-2ae0-4fb7-a134-c2ee7b3696df	aae08362-44ef-44be-90db-010c074c39c7	8a7b7484-d542-4891-b653-a9a664b86e65	108000.00	0.00	2026-06-03 00:00:00	\N	\N
1f24e1cf-e5e1-4ac9-beb2-7b201b3132b8	aae08362-44ef-44be-90db-010c074c39c7	3e48e334-f497-4f44-9922-73655cbc3209	0.00	108000.00	2026-06-03 00:00:00	\N	\N
0f8edbe6-77fe-4d7a-ab6f-17b7c877fc81	34dadae4-87ee-4ee0-9e84-dc7b95a1587b	ab80894d-7a79-41be-92ba-540fc52787d8	29299200.00	0.00	2026-06-04 00:00:00	\N	\N
0ea58bf5-2b5b-47e7-9870-6fb4f635a7ff	34dadae4-87ee-4ee0-9e84-dc7b95a1587b	ab232e94-529e-422b-8590-adeddd18bbac	244160000.00	0.00	2026-06-04 00:00:00	\N	\N
a29b7281-69c9-4028-ad77-dba1bfd794db	34dadae4-87ee-4ee0-9e84-dc7b95a1587b	10acb533-72b4-46dc-8b19-38c57f6f2fe3	0.00	273459200.00	2026-06-04 00:00:00	\N	\N
5cdcf3a9-95de-4008-84af-392dd7626bc2	48ed7424-5e3c-4432-88e6-04b225b5598c	ab80894d-7a79-41be-92ba-540fc52787d8	1260000.00	0.00	2026-06-10 00:00:00	\N	\N
2baad35f-3ebd-43c7-95ab-c09d3cd749e3	48ed7424-5e3c-4432-88e6-04b225b5598c	10acb533-72b4-46dc-8b19-38c57f6f2fe3	0.00	11760000.00	2026-06-10 00:00:00	\N	\N
3995a792-69f9-42f6-a865-7bedb6db9dcd	7b56f596-91c7-4e2c-818d-98435eab1dc0	ab80894d-7a79-41be-92ba-540fc52787d8	3560371.20	0.00	2026-06-11 00:00:00	\N	\N
1e747323-21e7-4cf9-9972-605df346feff	7b56f596-91c7-4e2c-818d-98435eab1dc0	8a7b7484-d542-4891-b653-a9a664b86e65	0.00	33230131.20	2026-06-11 00:00:00	\N	\N
84cb8c94-a6a0-4037-9b6e-db7940583b65	affdb512-06c1-4966-ae81-2be136f20bde	eb197584-ae22-48da-b174-b20e66aa595f	5376000.00	0.00	2026-06-04 00:00:00	\N	\N
ddc8da20-769e-4b4c-97c7-87be11631065	affdb512-06c1-4966-ae81-2be136f20bde	44feaa92-cf1d-4fbb-9023-f1f9e73def55	0.00	4800000.00	2026-06-04 00:00:00	\N	\N
8f6bd587-22ed-4a4d-a9fc-18a44bf13c58	affdb512-06c1-4966-ae81-2be136f20bde	1f64b4e5-72ea-4403-bfe9-91fc7083ad80	0.00	576000.00	2026-06-04 00:00:00	\N	\N
82612a97-14fc-4678-b0dc-bab13b080349	03e09997-e6b7-4ce0-8dad-6a8f2111b944	eb197584-ae22-48da-b174-b20e66aa595f	3244000.00	0.00	2026-06-19 00:00:00	\N	\N
b6c503ec-ae3a-4b35-9103-db3b36101f5b	03e09997-e6b7-4ce0-8dad-6a8f2111b944	44feaa92-cf1d-4fbb-9023-f1f9e73def55	0.00	2896428.57	2026-06-19 00:00:00	\N	\N
47821529-5b30-41f3-b1bf-7d560e1dd0d1	03e09997-e6b7-4ce0-8dad-6a8f2111b944	1f64b4e5-72ea-4403-bfe9-91fc7083ad80	0.00	347571.43	2026-06-19 00:00:00	\N	\N
6dfc7b7b-cd6e-4b2e-8051-b4694c17c60b	48ed7424-5e3c-4432-88e6-04b225b5598c	ab232e94-529e-422b-8590-adeddd18bbac	10500000.00	0.00	2026-06-10 00:00:00	\N	\N
1b3f8f2d-8d2c-4345-9834-4c332c1e6517	7b56f596-91c7-4e2c-818d-98435eab1dc0	ab232e94-529e-422b-8590-adeddd18bbac	29669760.00	0.00	2026-06-11 00:00:00	\N	\N
c698b6ec-09a3-442c-9e93-daf1c651be08	3c9de340-150a-4e66-8913-55b583fc3309	9ef38108-e7d4-4119-9f24-9c65d501967d	4000000.00	0.00	2026-06-28 00:00:00	\N	\N
9d4b4970-cb52-40a2-b5a8-db584a5faf05	3c9de340-150a-4e66-8913-55b583fc3309	e2b61343-45fb-43da-9974-d800b5fcbb93	0.00	4000000.00	2026-06-28 00:00:00	\N	\N
74c2392e-33e0-4231-a5ff-65f991ffdd3f	3c9de340-150a-4e66-8913-55b583fc3309	e2b61343-45fb-43da-9974-d800b5fcbb93	4000.00	0.00	2026-06-28 00:00:00	\N	\N
06484942-1587-4505-b6c1-b776320653a7	3c9de340-150a-4e66-8913-55b583fc3309	d4c91fda-45de-4c62-928c-8025f856ed94	0.00	4000.00	2026-06-28 00:00:00	\N	\N
d5a5adbc-1d21-4e56-9407-8fa3f297cf14	3c9de340-150a-4e66-8913-55b583fc3309	e2b61343-45fb-43da-9974-d800b5fcbb93	476000.00	0.00	2026-06-28 00:00:00	\N	\N
47e2e1df-7d9b-4a8e-ab59-2503fe223444	3c9de340-150a-4e66-8913-55b583fc3309	1f64b4e5-72ea-4403-bfe9-91fc7083ad80	0.00	476000.00	2026-06-28 00:00:00	\N	\N
6a007f59-1c10-4da6-8c65-dd55507f8a2e	3c9de340-150a-4e66-8913-55b583fc3309	9ef38108-e7d4-4119-9f24-9c65d501967d	480000.00	0.00	2026-06-28 00:00:00	\N	\N
b747e6fc-2796-4dd5-8271-66ad7c6f0fd2	3c9de340-150a-4e66-8913-55b583fc3309	aeaaad4b-dd56-464d-9758-06fc97f6d453	0.00	480000.00	2026-06-28 00:00:00	\N	\N
c79ea410-45c1-42ff-a2d2-fc4d947f6e49	7373fd1c-0fb0-41ce-bfc1-b11797f2851c	e2b61343-45fb-43da-9974-d800b5fcbb93	3520000.00	0.00	2026-06-28 00:00:00	\N	\N
3d750597-2f1e-4afe-b594-77ab2ba564d9	7373fd1c-0fb0-41ce-bfc1-b11797f2851c	fa6ea877-5e4a-4444-b5bb-c46eea3294d2	0.00	3520000.00	2026-06-28 00:00:00	\N	\N
899be08c-d356-4447-b431-4b9848361559	15207693-c1bc-412a-a894-117e37e82294	7dee97f8-ef28-489b-8b18-e9ff0a1b9ba3	1889986.66	0.00	2026-06-28 00:00:00	\N	\N
d0f0d929-0c2f-4a08-a01d-aad8610d0c9b	15207693-c1bc-412a-a894-117e37e82294	fd21d842-d122-4e90-bb30-e5b2e0fdc600	0.00	1889986.66	2026-06-28 00:00:00	\N	\N
bccfa7e6-5baa-46f9-ba5c-d3cf550a1273	15207693-c1bc-412a-a894-117e37e82294	7dee97f8-ef28-489b-8b18-e9ff0a1b9ba3	6480000.00	0.00	2026-06-28 00:00:00	\N	\N
097dc842-26f1-4e02-a17e-da1e88fd6dce	15207693-c1bc-412a-a894-117e37e82294	9ef38108-e7d4-4119-9f24-9c65d501967d	0.00	6480000.00	2026-06-28 00:00:00	\N	\N
97aee418-a5ba-434a-8ca9-86c2106c083a	15207693-c1bc-412a-a894-117e37e82294	44feaa92-cf1d-4fbb-9023-f1f9e73def55	7696428.57	0.00	2026-06-28 00:00:00	\N	\N
4f0d0b65-6cda-49ff-8307-b0ea138d9a08	15207693-c1bc-412a-a894-117e37e82294	7dee97f8-ef28-489b-8b18-e9ff0a1b9ba3	0.00	7696428.57	2026-06-28 00:00:00	\N	\N
8e87f56a-7a39-4e45-acda-0730c6aeb913	af31e6c4-e24e-4565-baa5-438168e57987	10acb533-72b4-46dc-8b19-38c57f6f2fe3	718928.00	0.00	2026-04-28 00:00:00	\N	\N
16fb708a-9301-4d23-b81c-9860344ac304	d3b7b6ff-39ed-4f60-b72a-cb0f5ef56e51	10acb533-72b4-46dc-8b19-38c57f6f2fe3	11760000.00	0.00	2026-06-09 00:00:00	\N	\N
a1e055a4-68eb-49ff-acce-6220f8bf811f	821ff739-ceb3-468b-a469-3188c9c2adfe	10acb533-72b4-46dc-8b19-38c57f6f2fe3	273459200.00	0.00	2026-06-04 00:00:00	\N	\N
\.


--
-- Data for Name: OpenItem; Type: TABLE DATA; Schema: public; Owner: user
--

COPY public."OpenItem" (id, "orgId", "accountId", "counterpartyId", "openingDocumentId", amount, "dateOpened", status, "riskDeadline", "closingDocumentId", "dateClosed", "affectedPeriodId", "awaitingInvoiceSign") FROM stdin;
fe5fe86e-b1df-498e-bc09-b467ae258d99	9b41b1b5-f6bf-4d28-a299-f645126d578b	7295850d-efdd-46ab-bba0-50379da90c85	d0fab1a1-01c7-4ac8-a6be-83d3fded6723	efdbb8f1-05d5-4df3-bbe9-1524268aa2fb	196000.00	2026-05-04 00:00:00	CLOSED	2027-05-04 00:00:00	42d646e5-429b-4461-bb52-0125c13fedf9	2026-05-02 00:00:00	f623fd76-5028-4900-b760-b70090905288	f
1d6e4919-9b76-4965-ae99-f8644ac9b511	9b41b1b5-f6bf-4d28-a299-f645126d578b	a01dc215-847e-4ae7-9665-6e598d6d0cf6	2b9a27b0-138b-40b6-a311-97fcdd3f0a3d	3607742a-a5b4-4ab8-ae50-1bd960fda873	18000000.00	2026-06-10 00:00:00	OPEN	2027-06-10 00:00:00	\N	\N	4f03361b-3c66-4bd6-9343-0876d6d8ac74	f
12cdbd93-b06b-4098-b7d8-b572fe79c8eb	9b41b1b5-f6bf-4d28-a299-f645126d578b	8a7b7484-d542-4891-b653-a9a664b86e65	da3d3e6f-8dd8-42d1-9397-fe3b4ea32069	06d94365-67e1-4555-86dc-c4f840233e28	14569896.00	2026-05-12 00:00:00	RISK	2026-06-11 00:00:00	\N	\N	f623fd76-5028-4900-b760-b70090905288	f
9adbd8e9-953f-4a05-a71a-d6ef2ce9d121	228045b1-34d6-4a27-8034-8a9860ab013e	a01dc215-847e-4ae7-9665-6e598d6d0cf6	80865cc4-fd02-4f9e-8608-aae41e98021c	627dc252-7fd6-4287-9cfe-abed79ff56a1	1000000.00	2026-04-09 00:00:00	OPEN	2027-04-09 00:00:00	\N	\N	7f6821e4-96d7-4c4f-82e9-713c49232527	f
d5845fc7-d792-4e1e-9b3c-4e351e79b836	228045b1-34d6-4a27-8034-8a9860ab013e	eb197584-ae22-48da-b174-b20e66aa595f	8efb7065-213b-4c62-838b-2c5b5393f736	63da4762-7555-4693-b2fc-a2ea7da1b1cd	2200000.00	2026-04-09 00:00:00	CLOSED	2026-05-09 00:00:00	\N	2026-07-09 13:02:13.688	7f6821e4-96d7-4c4f-82e9-713c49232527	f
db66c79b-6db0-4371-9829-63561a30d709	228045b1-34d6-4a27-8034-8a9860ab013e	fa6ea877-5e4a-4444-b5bb-c46eea3294d2	41373d41-012d-4406-aa8a-2c8d0ac3fa00	c4b78d9a-9d79-4fd1-bd2e-4a320f43dcc3	23000000.00	2026-05-18 00:00:00	OPEN	2026-06-17 00:00:00	\N	\N	12c40a94-ca5e-4587-a825-336e0034921e	f
22cf6afd-25e4-4349-bb37-b4ee44b67518	228045b1-34d6-4a27-8034-8a9860ab013e	7295850d-efdd-46ab-bba0-50379da90c85	bd3939c2-7f7e-4ea7-a3a7-a8527ffa4191	3fe7aafa-78ab-4d78-89a1-9294678c3503	9800.00	2026-05-18 00:00:00	OPEN	2027-05-18 00:00:00	\N	\N	12c40a94-ca5e-4587-a825-336e0034921e	f
a9d867c5-6e30-49c6-92bf-0be007c64e95	228045b1-34d6-4a27-8034-8a9860ab013e	eb197584-ae22-48da-b174-b20e66aa595f	cb65d521-7e19-4c2d-b42a-3f752a991e72	78e4fdc3-f8d3-4994-aa1f-190e2cf23341	22000000.00	2026-05-07 00:00:00	OPEN	2026-06-06 00:00:00	\N	\N	12c40a94-ca5e-4587-a825-336e0034921e	f
fa4340d1-6748-41c9-9851-5164a3ad74c7	228045b1-34d6-4a27-8034-8a9860ab013e	eb197584-ae22-48da-b174-b20e66aa595f	583304d1-9194-4ecd-af6c-e58fd2b1bc9a	2e51fd5a-212c-4cba-a3d5-afa2e97c54b9	8758400.00	2026-04-29 00:00:00	CLOSED	2026-05-29 00:00:00	0bd3a180-cd59-4ea4-92ea-f3e09d3df52f	2026-05-04 00:00:00	7f6821e4-96d7-4c4f-82e9-713c49232527	f
32d45513-2e33-45f9-986d-cddad30b4146	228045b1-34d6-4a27-8034-8a9860ab013e	7295850d-efdd-46ab-bba0-50379da90c85	b1087098-dde0-4318-a196-493a5e716b1e	7d4683e1-8fe0-46d7-b92d-ae489a109a58	9800.00	2026-05-18 00:00:00	CLOSED	2027-05-18 00:00:00	c6cba1dd-ce54-4cb2-8c74-2fd6d514da37	2026-05-01 00:00:00	12c40a94-ca5e-4587-a825-336e0034921e	f
12b40158-ead6-4e55-968d-12a82bb5b875	228045b1-34d6-4a27-8034-8a9860ab013e	7295850d-efdd-46ab-bba0-50379da90c85	bd3939c2-7f7e-4ea7-a3a7-a8527ffa4191	b65d11bc-5cff-41d2-b472-57219d107a2f	9800.00	2026-05-04 00:00:00	CLOSED	2027-05-04 00:00:00	f45ceb7e-a022-4c72-b8dd-5d71d54492f8	2026-05-16 00:00:00	12c40a94-ca5e-4587-a825-336e0034921e	f
a1bef64d-11d3-4472-b7b8-ed4d32fa3213	228045b1-34d6-4a27-8034-8a9860ab013e	eb197584-ae22-48da-b174-b20e66aa595f	50116ac8-31c0-46f2-9e7f-6af654bb75b9	f1791b1a-0bfc-400c-9174-bf34095b8ee1	12900000.00	2026-06-01 00:00:00	OPEN	2026-07-01 00:00:00	\N	\N	7a927f44-73c4-42d6-a03e-73d32327dbc5	f
b2d5d021-440b-4323-8b36-7bd7d6d891b8	228045b1-34d6-4a27-8034-8a9860ab013e	69358c02-20df-4da7-ba57-3564120994f6	b1087098-dde0-4318-a196-493a5e716b1e	68431629-82a5-4424-8513-0a353d73847a	3000000.00	2026-06-02 00:00:00	OPEN	2026-07-02 00:00:00	\N	\N	7a927f44-73c4-42d6-a03e-73d32327dbc5	f
8695f504-5fcb-4ba4-adf5-4a815dad9889	228045b1-34d6-4a27-8034-8a9860ab013e	69358c02-20df-4da7-ba57-3564120994f6	b1087098-dde0-4318-a196-493a5e716b1e	077b80f7-1e33-45f9-9e92-81dc082d6a78	10000000.00	2026-06-19 00:00:00	CLOSED	2026-07-19 00:00:00	\N	2026-07-09 13:15:15.332	7a927f44-73c4-42d6-a03e-73d32327dbc5	f
95d5b172-4b9b-4b4b-b710-5529ed6b980a	228045b1-34d6-4a27-8034-8a9860ab013e	7295850d-efdd-46ab-bba0-50379da90c85	b1087098-dde0-4318-a196-493a5e716b1e	077b80f7-1e33-45f9-9e92-81dc082d6a78	10000000.00	2026-06-19 00:00:00	OPEN	2027-06-19 00:00:00	\N	\N	7a927f44-73c4-42d6-a03e-73d32327dbc5	f
46d2bcf5-e5e8-4a7a-ab13-4ef7c2ad8e44	228045b1-34d6-4a27-8034-8a9860ab013e	fa6ea877-5e4a-4444-b5bb-c46eea3294d2	41373d41-012d-4406-aa8a-2c8d0ac3fa00	bdd58d95-d287-401f-8d36-56a41b35faa0	30000000.00	2026-06-05 00:00:00	OPEN	2026-07-05 00:00:00	\N	\N	7a927f44-73c4-42d6-a03e-73d32327dbc5	f
ead02996-fa9e-47fe-9f0c-5028053b3412	228045b1-34d6-4a27-8034-8a9860ab013e	fa6ea877-5e4a-4444-b5bb-c46eea3294d2	41373d41-012d-4406-aa8a-2c8d0ac3fa00	5506b7cd-c391-49ec-8b80-36fb8c102c5e	30000000.00	2026-06-04 00:00:00	OPEN	2026-07-04 00:00:00	\N	\N	7a927f44-73c4-42d6-a03e-73d32327dbc5	f
7ef70e3c-fb41-4598-b4de-35167bae77ef	228045b1-34d6-4a27-8034-8a9860ab013e	eb197584-ae22-48da-b174-b20e66aa595f	77a71845-8115-4b48-91a1-9aa942b293d7	7b65e3d5-7721-4e6b-ad83-8e745596fdf4	69090000.00	2026-06-05 00:00:00	OPEN	2026-07-05 00:00:00	\N	\N	7a927f44-73c4-42d6-a03e-73d32327dbc5	f
90753fb6-a34a-451f-93f3-00f7c88925ff	228045b1-34d6-4a27-8034-8a9860ab013e	eb197584-ae22-48da-b174-b20e66aa595f	fa0300ce-3f55-4881-bf90-042e34a1c8b1	e83e6bc6-2603-4e58-a51d-d69857399d3b	292640000.00	2026-06-03 00:00:00	OPEN	2026-07-03 00:00:00	\N	\N	7a927f44-73c4-42d6-a03e-73d32327dbc5	f
172006e1-61d8-444e-9c90-f97736f68a92	228045b1-34d6-4a27-8034-8a9860ab013e	8a7b7484-d542-4891-b653-a9a664b86e65	d17e1182-8fe0-4ad1-886c-97b971790002	7b56f596-91c7-4e2c-818d-98435eab1dc0	33230131.20	2026-06-11 00:00:00	OPEN	2026-07-11 00:00:00	\N	\N	7a927f44-73c4-42d6-a03e-73d32327dbc5	f
70b7072d-3cdb-4c43-9d0d-09887db6ee66	228045b1-34d6-4a27-8034-8a9860ab013e	eb197584-ae22-48da-b174-b20e66aa595f	079e08b8-a737-4171-b8e0-940c158ae79e	d9882e12-e27a-4f4d-beeb-a5b4102befc6	5376000.00	2026-06-04 00:00:00	CLOSED	2026-07-04 00:00:00	affdb512-06c1-4966-ae81-2be136f20bde	2026-06-04 00:00:00	7a927f44-73c4-42d6-a03e-73d32327dbc5	f
5c8cab5f-ea87-4a87-9b87-aace1739b4cd	228045b1-34d6-4a27-8034-8a9860ab013e	eb197584-ae22-48da-b174-b20e66aa595f	68af40f5-a777-4bab-9ed0-ec9e65984883	01b8648a-010f-42a3-b6ec-54288965b3d2	3244000.00	2026-06-16 00:00:00	CLOSED	2026-07-16 00:00:00	03e09997-e6b7-4ce0-8dad-6a8f2111b944	2026-06-19 00:00:00	7a927f44-73c4-42d6-a03e-73d32327dbc5	f
\.


--
-- Data for Name: OrgMember; Type: TABLE DATA; Schema: public; Owner: user
--

COPY public."OrgMember" (id, role, "userId", "orgId") FROM stdin;
5c5b7c78-2060-4d19-b1e0-27d72efa10e7	OWNER	b6fd1a37-31da-4a14-8761-ec6b579e539c	1e996ba7-c636-4bdb-8fa9-16548f4d291e
52f7141d-5974-4a09-a4e6-23ddea4ac73a	OWNER	b6fd1a37-31da-4a14-8761-ec6b579e539c	9b41b1b5-f6bf-4d28-a299-f645126d578b
abe74a6f-6cd4-477c-bdfc-821a93f0eccd	OWNER	b6fd1a37-31da-4a14-8761-ec6b579e539c	228045b1-34d6-4a27-8034-8a9860ab013e
\.


--
-- Data for Name: Organization; Type: TABLE DATA; Schema: public; Owner: user
--

COPY public."Organization" (id, name, inn, "taxRegime", "isVatPayer", "createdAt", "activityDescription", "aiConfidenceThreshold", "maxClarificationQuestions", settings, "activityCustom", "activityGroup", "turnoverTaxRate", "charterCapitalAmount", "charterCapitalDeclaredAt", "charterCapitalFundingType", "autoAccrueProfitTax", "profitTaxRate") FROM stdin;
1e996ba7-c636-4bdb-8fa9-16548f4d291e	GP STATE UNION	\N	TURNOVER_TAX	f	2026-07-05 09:52:46.732	\N	70	50	\N	\N	\N	0.04	10000000.00	2026-07-05 10:18:18.219	NOT_PAID	t	0.15
9b41b1b5-f6bf-4d28-a299-f645126d578b	GORGEOUS PARTNERS	\N	VAT	t	2026-07-08 11:08:06.004	\N	70	50	\N	\N	\N	0.04	\N	\N	\N	t	0.15
228045b1-34d6-4a27-8034-8a9860ab013e	GP TECH UNION	312915680	VAT	t	2026-07-09 12:53:47.393	\N	70	10	\N	\N	\N	0.04	10000000.00	2026-07-09 12:54:41.599	NOT_PAID	f	0.15
\.


--
-- Data for Name: PasswordResetToken; Type: TABLE DATA; Schema: public; Owner: user
--

COPY public."PasswordResetToken" (id, "userId", token, "expiresAt", "usedAt", "createdAt") FROM stdin;
\.


--
-- Data for Name: Payment; Type: TABLE DATA; Schema: public; Owner: user
--

COPY public."Payment" (id, "orgId", provider, "externalId", amount, currency, status, "daysGranted", "createdAt", "completedAt", "cancelReason", "cancelTime", "orderCode") FROM stdin;
\.


--
-- Data for Name: Period; Type: TABLE DATA; Schema: public; Owner: user
--

COPY public."Period" (id, "orgId", year, month, mode, status, "lockDate", "closingData") FROM stdin;
5669264c-fcfe-40ae-bc30-956d12e97c10	1e996ba7-c636-4bdb-8fa9-16548f4d291e	2026	7	ACTIVE	OPEN	\N	\N
12c40a94-ca5e-4587-a825-336e0034921e	228045b1-34d6-4a27-8034-8a9860ab013e	2026	5	ACTIVE	CLOSED	2026-05-31 00:00:00	\N
7a927f44-73c4-42d6-a03e-73d32327dbc5	228045b1-34d6-4a27-8034-8a9860ab013e	2026	6	ACTIVE	CLOSED	2026-06-30 00:00:00	\N
65435e8b-7413-4034-b4a7-f5ca4651570e	228045b1-34d6-4a27-8034-8a9860ab013e	2026	7	ACTIVE	OPEN	\N	\N
f623fd76-5028-4900-b760-b70090905288	9b41b1b5-f6bf-4d28-a299-f645126d578b	2026	5	ACTIVE	CLOSED	2026-05-31 00:00:00	\N
4f03361b-3c66-4bd6-9343-0876d6d8ac74	9b41b1b5-f6bf-4d28-a299-f645126d578b	2026	6	ACTIVE	CLOSED	2026-06-30 00:00:00	\N
7f6821e4-96d7-4c4f-82e9-713c49232527	228045b1-34d6-4a27-8034-8a9860ab013e	2026	4	ACTIVE	CLOSED	2026-04-30 00:00:00	\N
\.


--
-- Data for Name: Rule; Type: TABLE DATA; Schema: public; Owner: user
--

COPY public."Rule" (id, "orgId", "matchType", "matchValue", "categoryId", "createdFrom", "createdAt", "order", direction) FROM stdin;
b8759ebe-ab75-4731-ae2b-13faf2ae21f2	9b41b1b5-f6bf-4d28-a299-f645126d578b	INN	200540423	28c8c399-9da5-4b55-a645-e8a884e9293f	USER_ANSWER	2026-07-08 11:14:19.519	0	DEBIT
acb58101-4add-49cc-914e-dac313440ee9	9b41b1b5-f6bf-4d28-a299-f645126d578b	INN	308718135	285a86d8-bd31-4db1-974d-776806e52f09	USER_ANSWER	2026-07-08 11:20:41.55	0	\N
706a7eb0-faff-489f-ba93-8995e684bad4	9b41b1b5-f6bf-4d28-a299-f645126d578b	INN	306180825	348b6a91-2055-4cd8-b96a-613eede381c7	USER_ANSWER	2026-07-08 11:21:03.486	0	\N
30a2c533-1d89-4970-af59-ed3964f15082	9b41b1b5-f6bf-4d28-a299-f645126d578b	INN	201122919	11153a82-fa3f-4228-9376-e6ba3e88a335	USER_ANSWER	2026-07-08 11:27:14.752	0	\N
a8354f53-dc55-4591-a2aa-af00adfd1aeb	228045b1-34d6-4a27-8034-8a9860ab013e	INN	306230564	a945e1d9-4ba7-4f05-a073-4f7b82fe1f30	USER_ANSWER	2026-07-09 13:00:26.027	0	\N
772f7725-eed2-415b-873e-406ebc3296d3	228045b1-34d6-4a27-8034-8a9860ab013e	INN	309935428	98d89959-6f0c-4e37-8f4a-73f191630df3	USER_ANSWER	2026-07-09 13:01:43.704	0	\N
932f0afe-52aa-4080-8208-f48ebcabf7a2	228045b1-34d6-4a27-8034-8a9860ab013e	INN	312915680	6c00d577-1c7a-4512-971c-91a3156659be	USER_ANSWER	2026-07-09 13:03:28.568	0	DEBIT
375a9569-e635-485a-bd45-a14ee7ef634b	228045b1-34d6-4a27-8034-8a9860ab013e	INN	308710993	98d89959-6f0c-4e37-8f4a-73f191630df3	USER_ANSWER	2026-07-09 13:03:51.226	0	\N
a336e7e8-4906-42c8-882b-b0735e26cbcc	228045b1-34d6-4a27-8034-8a9860ab013e	INN	207086151	a8764508-ec8a-49ab-b12f-f18f38dd6493	USER_ANSWER	2026-07-09 13:07:42.505	0	\N
bbae16a9-2aeb-4b86-9a3c-e1728b1551db	228045b1-34d6-4a27-8034-8a9860ab013e	INN	302134733	285a86d8-bd31-4db1-974d-776806e52f09	USER_ANSWER	2026-07-09 13:08:16.676	0	CREDIT
4954e99d-2937-4386-b5de-f7f6bc247687	228045b1-34d6-4a27-8034-8a9860ab013e	INN	301551793	7d5bc76f-1bf4-4d51-9f41-bb19759698ee	USER_ANSWER	2026-07-09 13:08:44.043	0	\N
71b7297b-fa38-4806-a2fa-3762faaa5c9e	228045b1-34d6-4a27-8034-8a9860ab013e	INN	310332959	98d89959-6f0c-4e37-8f4a-73f191630df3	USER_ANSWER	2026-07-09 13:09:11.47	0	\N
c8dc418d-6f41-4612-aae3-afac718c86fd	228045b1-34d6-4a27-8034-8a9860ab013e	INN	200540423	7d5bc76f-1bf4-4d51-9f41-bb19759698ee	USER_ANSWER	2026-07-09 13:09:35.703	0	\N
b62d13ec-ff95-4a4b-bb6f-ce89a9f66851	228045b1-34d6-4a27-8034-8a9860ab013e	INN	201122919	1394e1a8-b539-48bb-95c9-2069b3f95ee8	USER_ANSWER	2026-07-09 13:09:43.369	0	DEBIT
11eea38d-e0cf-42c4-a8cb-406bfad1dd34	228045b1-34d6-4a27-8034-8a9860ab013e	INN	310783571	8fdc07dc-89f5-4d8e-81e4-ce54fb6dc7b0	USER_ANSWER	2026-07-09 13:10:03.541	0	\N
0d6cdc7b-e610-4a9a-bf8f-956707aefc71	228045b1-34d6-4a27-8034-8a9860ab013e	INN	201535024	7d5bc76f-1bf4-4d51-9f41-bb19759698ee	USER_ANSWER	2026-07-09 13:12:03.15	0	\N
86faf746-30fe-4d1e-8ec6-863fec57dfd5	228045b1-34d6-4a27-8034-8a9860ab013e	INN	311010005	98d89959-6f0c-4e37-8f4a-73f191630df3	USER_ANSWER	2026-07-09 13:13:06.256	0	\N
456e6f0b-43ad-4bca-8ae9-fa5bdf50cca4	228045b1-34d6-4a27-8034-8a9860ab013e	INN	200642271	98d89959-6f0c-4e37-8f4a-73f191630df3	USER_ANSWER	2026-07-09 13:13:36.262	0	\N
7b957688-6abc-48dc-92ed-d87d13399ff4	228045b1-34d6-4a27-8034-8a9860ab013e	INN	200933985	bc137b43-5986-4ac0-afa5-51eb8f0cbf67	USER_ANSWER	2026-07-09 13:15:00.786	0	\N
29c3d0da-d277-4c7a-9d49-3848be39ac1b	228045b1-34d6-4a27-8034-8a9860ab013e	INN	202288236	98d89959-6f0c-4e37-8f4a-73f191630df3	USER_ANSWER	2026-07-09 13:15:48.066	0	\N
73254572-0553-4f75-9448-58723be11ef1	228045b1-34d6-4a27-8034-8a9860ab013e	INN	312384465	98d89959-6f0c-4e37-8f4a-73f191630df3	USER_ANSWER	2026-07-09 13:15:57.802	0	\N
e75e4eb5-ca3d-4cb1-b19b-a917e2a49032	228045b1-34d6-4a27-8034-8a9860ab013e	INN	303303592	98d89959-6f0c-4e37-8f4a-73f191630df3	USER_ANSWER	2026-07-09 13:18:33.966	0	\N
c7f46c50-6b6a-4267-8f76-5a098e932eb8	228045b1-34d6-4a27-8034-8a9860ab013e	INN	305774212	0e155225-1f9f-48ce-b303-a1c8852453d8	USER_ANSWER	2026-07-09 13:04:10.371	0	\N
98b99c79-6d84-436e-99e2-8ec5b8575963	228045b1-34d6-4a27-8034-8a9860ab013e	INN	311149962	0e155225-1f9f-48ce-b303-a1c8852453d8	USER_ANSWER	2026-07-09 13:12:25.636	0	\N
22749ed7-9a9a-4501-a5cf-54b34a1ec231	228045b1-34d6-4a27-8034-8a9860ab013e	INN	311509237	0e155225-1f9f-48ce-b303-a1c8852453d8	USER_ANSWER	2026-07-09 13:13:17.081	0	\N
\.


--
-- Data for Name: StagedTransaction; Type: TABLE DATA; Schema: public; Owner: user
--

COPY public."StagedTransaction" (id, "orgId", "bankAccountId", "periodId", date, amount, direction, description, "counterpartyHint", "counterpartyInn", hash, status, "aiSuggestion", "documentId", "importBatchId", "createdAt") FROM stdin;
595a4c57-19cc-4b29-a3db-2cfb7b421f52	228045b1-34d6-4a27-8034-8a9860ab013e	5801bb14-ff63-4873-84b5-649306c350a8	7a927f44-73c4-42d6-a03e-73d32327dbc5	2026-06-01 00:00:00	38130.00	DEBIT	08102~2001108606262693212160093~200540423~Оплата Социальный налог за май 2026 г. $TAX_ID$26152000707144	Казначейство Министерства финансов Республика Узбекистан	201122919	6c7050cbe6699adb946e3ca456eab21ba6c3c393fc18bf2e152a7557fcf791f0	CONFIRMED	\N	cf27399b-5ba6-4d9c-a193-aed14256a4af	f71ecf7b-2091-4898-a2eb-3f65a4b4b218	2026-07-09 13:11:03.762+00
2d89bcb5-e711-4edf-9ac5-dc9a4313dd1a	9b41b1b5-f6bf-4d28-a299-f645126d578b	f89191ed-f456-4648-a8ac-c98c649f7b18	f623fd76-5028-4900-b760-b70090905288	2026-05-14 00:00:00	2000.00	DEBIT	08102 Оплата Отчисление в ИНПС апрель 2026 $TAX_ID$26134002007583	Mirzo-Ulug'bek Tumani DSI	200540423	a2ab8c0e02c27b27c85a1aedd730c60adf2faf3e8fffbdf742a1415a954fd99e	CONFIRMED	\N	159f6645-8246-461a-bc4c-0ec53537c116	52db8aaa-dde6-43ed-b770-b8f1adc380d1	2026-07-08 11:12:54.594+00
ee5fe381-0ee4-4277-9c0f-da781e8b0631	9b41b1b5-f6bf-4d28-a299-f645126d578b	f89191ed-f456-4648-a8ac-c98c649f7b18	f623fd76-5028-4900-b760-b70090905288	2026-05-04 00:00:00	196000.00	CREDIT	00634Зачисление денежных средств поставщику MCHJ GORGEOUS PARTNERS (ИНН: 308718135) от PAYME за 02-05-2026 за услуги или товары через HUMO. С автоудержанем (Без оплат) 2% с поставщика CID: 697e51b8fbe4c888a5b95013 EXT: 69f6afdb7637906f27569aed MID: 63b7ac7cd3af34dee9986e01	Транзитный счёт для рассчёта с коммерсантами (Payme)	308718135	160c5e4524508bf26785239d0c4abf9c66898166fc43621d8e39b72e603f316b	CONFIRMED	\N	efdbb8f1-05d5-4df3-bbe9-1524268aa2fb	52db8aaa-dde6-43ed-b770-b8f1adc380d1	2026-07-08 11:12:54.56+00
5da9b376-09cf-4d97-99cf-6e0cf066177a	9b41b1b5-f6bf-4d28-a299-f645126d578b	f89191ed-f456-4648-a8ac-c98c649f7b18	f623fd76-5028-4900-b760-b70090905288	2026-05-04 00:00:00	1049019.42	DEBIT	00668 M365 Fmily Subscr PK Lic 1YR Online Centrl/Estern Euro Only ESD C, право на использование	ИП ООО "MONT CLOUD"	306180825	ae7f021ec2e2282d8ca5d8c59029423476a46d5c30d4f1b67461c688873451bf	CONFIRMED	\N	9268de84-f08b-4d84-b163-65ec38d4c648	52db8aaa-dde6-43ed-b770-b8f1adc380d1	2026-07-08 11:12:54.585+00
0ad5c36c-e1a0-40f3-8e87-b4dba284af99	9b41b1b5-f6bf-4d28-a299-f645126d578b	f89191ed-f456-4648-a8ac-c98c649f7b18	f623fd76-5028-4900-b760-b70090905288	2026-05-04 00:00:00	964000.00	DEBIT	08102~1000218602262693112525093~200540423~Оплата за Налог с оборота за Апрель 2026 г $TAX_ID$26124000082528	Казначейство Министерства финансов Республика Узбекистан	201122919	5b02a013b41e9aac18897591400bcffaec9ce90af8921ef4e6daf663cb9e5ac6	CONFIRMED	\N	36e951a7-2516-471a-b799-2bfc70e9a924	52db8aaa-dde6-43ed-b770-b8f1adc380d1	2026-07-08 11:12:54.577+00
0c645a83-0653-43de-aa9f-0ecb02ff5fc3	9b41b1b5-f6bf-4d28-a299-f645126d578b	f89191ed-f456-4648-a8ac-c98c649f7b18	f623fd76-5028-4900-b760-b70090905288	2026-05-04 00:00:00	148000.00	DEBIT	08102~1000218604262693111103093~200540423~Оплата за Налог на доходы физических лиц (НДФЛ) за Апрель 2026 г $TAX_ID$26124000082746	Казначейство Министерства финансов Республика Узбекистан	201122919	89147c3090a513b3870a963d894a1837d4b741c996aa60ad93882f5b5d64b58c	CONFIRMED	\N	f002e9c8-ae69-46fb-8120-5b0f279334c7	52db8aaa-dde6-43ed-b770-b8f1adc380d1	2026-07-08 11:12:54.572+00
1d8e6909-c059-4adc-ad40-030978d473ab	9b41b1b5-f6bf-4d28-a299-f645126d578b	f89191ed-f456-4648-a8ac-c98c649f7b18	f623fd76-5028-4900-b760-b70090905288	2026-05-04 00:00:00	5245.10	DEBIT	00668 BC 04.05.2026 погашение Дебет айланма(банкаро) -5245.10 от суммы 1049019.42  от 04.05.2026	Начисленные %% ООО "GORGEOUS PARTNERS"	308718135	3125b89a4a52591548b3bd7c753d1a3835ec726c27a11241ff3f1800c9465faa	CONFIRMED	\N	927502bf-9d13-4cf6-87d8-552637d7215e	52db8aaa-dde6-43ed-b770-b8f1adc380d1	2026-07-08 11:12:54.566+00
a56d42fc-6a63-40f7-9d14-2c031042b556	9b41b1b5-f6bf-4d28-a299-f645126d578b	f89191ed-f456-4648-a8ac-c98c649f7b18	4f03361b-3c66-4bd6-9343-0876d6d8ac74	2026-06-10 00:00:00	4120.00	DEBIT	00111 BC 10.06.2026 погашение Дебет айланма(банкаро) -4120.00 от суммы 824000.00  от 10.06.2026	Начисленные %% ООО "GORGEOUS PARTNERS"	308718135	1117e3b4b40154c2d369c4f4345a72c7bd368aaf30d2250b05f5d3151cac0fb2	CONFIRMED	\N	708b6914-40c9-4839-af68-b05fee50e414	18fe5996-e198-4029-8170-07777d62d7cf	2026-07-08 11:23:30.341+00
71e1ec8b-1ea5-4a9b-9dc5-2d608ef504ad	9b41b1b5-f6bf-4d28-a299-f645126d578b	f89191ed-f456-4648-a8ac-c98c649f7b18	4f03361b-3c66-4bd6-9343-0876d6d8ac74	2026-06-10 00:00:00	1210.00	DEBIT	00111 BC 10.06.2026 погашение Дебет айланма(банкаро) -1210.00 от суммы 242000.00  от 10.06.2026	Начисленные %% ООО "GORGEOUS PARTNERS"	308718135	ecc2c79737ac9fe98d02af293450392da5126feae30b17aaec4ec97ff8a29872	CONFIRMED	\N	7bbddcd3-e108-4aa5-9e4e-8375f029cbb0	18fe5996-e198-4029-8170-07777d62d7cf	2026-07-08 11:23:30.336+00
54032d8a-07b5-4d49-8e9b-ff65aa820df2	9b41b1b5-f6bf-4d28-a299-f645126d578b	f89191ed-f456-4648-a8ac-c98c649f7b18	4f03361b-3c66-4bd6-9343-0876d6d8ac74	2026-06-10 00:00:00	824000.00	DEBIT	00111 Оплата за услуги Виртуального офиса по договору №220 от 01.04.2026 года за июнь 2026 г.	DASTURIY MAHSULOTLAR VA AXBOROT TEXNOLOGIYALARI TEXNOLOGIK PARKI DIREKSIYASI	305975326	1835185a4a78e7489d3567263d57b309141a1ccc03aaa14c1ddfce337ef21fb1	CONFIRMED	\N	8132dded-5210-4de0-9e2a-7fb0330c6420	18fe5996-e198-4029-8170-07777d62d7cf	2026-07-08 11:23:30.356+00
9998a5cc-4602-4353-b8c6-ed21f1588cfc	9b41b1b5-f6bf-4d28-a299-f645126d578b	f89191ed-f456-4648-a8ac-c98c649f7b18	4f03361b-3c66-4bd6-9343-0876d6d8ac74	2026-06-10 00:00:00	242000.00	DEBIT	00111 Взаиморасчет по отчислениям ИНН: 308718135	DASTURIY MAHSULOTLAR VA AXBOROT TEXNOLOGIYALARI TEXNOLOGIK PARKI DIREKSIYASI	308718135	c58122465d27c621afbb9767c9dd64b4e575276c574f7cfb8aa7b3f5e627b3b4	CONFIRMED	\N	d303133e-e42c-49c3-94e5-1d4896961fe7	18fe5996-e198-4029-8170-07777d62d7cf	2026-07-08 11:23:30.351+00
bebb2ad3-7f91-4dbe-9e4b-18d09120b73c	9b41b1b5-f6bf-4d28-a299-f645126d578b	f89191ed-f456-4648-a8ac-c98c649f7b18	4f03361b-3c66-4bd6-9343-0876d6d8ac74	2026-06-01 00:00:00	148000.00	DEBIT	08102~1000218604262693111103093~200540423~Оплата Налог на доходы физических лиц (НДФЛ) за май 2026 г $TAX_ID$26152000712833	Казначейство Министерства финансов Республика Узбекистан	201122919	6cc8250ca88d012fd1f07751ff78a550f651bc5372b11a7f126f7f9c92d25237	CONFIRMED	\N	ca007879-8cca-494d-b844-915675cfad3f	18fe5996-e198-4029-8170-07777d62d7cf	2026-07-08 11:23:30.315+00
3e8d928e-e435-4663-b35f-ff87c59e2e05	9b41b1b5-f6bf-4d28-a299-f645126d578b	f89191ed-f456-4648-a8ac-c98c649f7b18	4f03361b-3c66-4bd6-9343-0876d6d8ac74	2026-06-01 00:00:00	2000.00	DEBIT	00717 Оплата Отчисление в ИНПС за май 2026 г $TAX_ID$26152000712669	Mirzo-Ulug`bek Tumani DSI boshlig`i USMANOV D.А.	200540423	bcb614cb37daf72a088a6faa0feadc92eae83fb5db61edcf5671b96742c825e8	CONFIRMED	\N	0d127988-dbfe-42dd-a5c7-cb1fbb1ea1e0	18fe5996-e198-4029-8170-07777d62d7cf	2026-07-08 11:23:30.298+00
b215ae13-69f1-4e29-b077-a4911d9f6653	9b41b1b5-f6bf-4d28-a299-f645126d578b	f89191ed-f456-4648-a8ac-c98c649f7b18	4f03361b-3c66-4bd6-9343-0876d6d8ac74	2026-06-10 00:00:00	72849.48	DEBIT	00111 BC 10.06.2026 погашение Дебет айланма(банкаро) -72849.48 от суммы 14569896.00  от 10.06.2026	Начисленные %% ООО "GORGEOUS PARTNERS"	308718135	c68c4b8d2653d76091d13c863f8907f49eead9746052227da57836f7d9a50780	CONFIRMED	\N	b6344b4d-48a9-4301-9390-ea4310821ec3	18fe5996-e198-4029-8170-07777d62d7cf	2026-07-08 11:23:30.346+00
3906666e-cf76-4685-b2fb-a523714b1a89	9b41b1b5-f6bf-4d28-a299-f645126d578b	f89191ed-f456-4648-a8ac-c98c649f7b18	4f03361b-3c66-4bd6-9343-0876d6d8ac74	2026-06-10 00:00:00	14569896.00	DEBIT	00112 Creative Cloud Pro for teams ALL Multiple Platforms Multi European Languages Subscription New счет № 524 от 12.05.2026 к договору № 82П/24 от 24.10.2024	ИП ООО "MONT CLOUD"	306180825	6f90b12a1200ad1c633e322cbb55e4279c17eca4af1f97d0f97685bd6954e149	CONFIRMED	\N	369d18f6-3b01-424c-9549-0f8f62cd8f9f	18fe5996-e198-4029-8170-07777d62d7cf	2026-07-08 11:23:30.36+00
3d5172b9-e7af-43cb-aa79-7b00e273c1ba	9b41b1b5-f6bf-4d28-a299-f645126d578b	f89191ed-f456-4648-a8ac-c98c649f7b18	4f03361b-3c66-4bd6-9343-0876d6d8ac74	2026-06-10 00:00:00	18000000.00	CREDIT	00659БУРАНОВ АХМАДЖОН Пополнение уставного фонда RRN (029997368296)  За 10.06.2026	Бошка ташкилотлар хизматлари учун жис.шахслардан кабул килинган туловлар	207086151	3f606e8d201f4c17ca20f16b73d95971e546ffa6cbfae7b4210a11645112a6a0	CONFIRMED	\N	3607742a-a5b4-4ab8-ae50-1bd960fda873	18fe5996-e198-4029-8170-07777d62d7cf	2026-07-08 11:23:30.365+00
bb74e133-e87b-4664-b87d-807b8671b461	228045b1-34d6-4a27-8034-8a9860ab013e	5801bb14-ff63-4873-84b5-649306c350a8	7f6821e4-96d7-4c4f-82e9-713c49232527	2026-04-09 00:00:00	1000000.00	CREDIT	00668  Buranov Axmadjon Maxmudovich. пополнение уставного фонда 609911411732	BURANOV AXMADJON MAXMUDOVICH	306230564	c8aab1f65efd7d51904038ade7db700e6e2d97556e3b418e497942a5293942c6	CONFIRMED	\N	627dc252-7fd6-4287-9cfe-abed79ff56a1	c64fd4dc-8078-424f-8d39-20e0cee5e23f	2026-07-09 12:59:16.634+00
dd5edf46-74b2-49a8-83a9-4c73791d396a	228045b1-34d6-4a27-8034-8a9860ab013e	5801bb14-ff63-4873-84b5-649306c350a8	7f6821e4-96d7-4c4f-82e9-713c49232527	2026-04-09 00:00:00	2200000.00	CREDIT	00668 Предоплата 100% по договору №07042026-1 от 07.04.2026 за Zoom Workplace Professional подписка на 12 месяцев	ООО "AKSEL MWD"	309935428	592b812e24ae431c2388194a5c135866744d54a426b832479c754f0332700453	SKIPPED	\N	\N	c64fd4dc-8078-424f-8d39-20e0cee5e23f	2026-07-09 12:59:16.643+00
3534513d-cbb3-4e4f-8c34-f4751aa6ecb0	228045b1-34d6-4a27-8034-8a9860ab013e	5801bb14-ff63-4873-84b5-649306c350a8	7f6821e4-96d7-4c4f-82e9-713c49232527	2026-04-10 00:00:00	2200000.00	DEBIT	00658 Возврат ошибочно отправленного платежа	ООО "AKSEL MWD"	309935428	4c857edbe61239d5f868409a1a9f908dba364ac0fda1576d6d84b2805fa65f8b	SKIPPED	\N	\N	c64fd4dc-8078-424f-8d39-20e0cee5e23f	2026-07-09 12:59:16.656+00
23e2b62a-ad63-40bf-b579-a4265b3278ab	228045b1-34d6-4a27-8034-8a9860ab013e	5801bb14-ff63-4873-84b5-649306c350a8	7f6821e4-96d7-4c4f-82e9-713c49232527	2026-04-28 00:00:00	3594.64	DEBIT	00668 BC 28.04.2026 погашение Дебет айланма(банкаро) -3594.64 от суммы 718928.00  от 28.04.2026	Начисленные %% GP TECH UNION	312915680	230c4716f03a65c17327bb60c176cf209a165544e25190669425545fa881be05	CONFIRMED	\N	aa0dad12-d8c4-4d52-94c2-2fe81086545e	c64fd4dc-8078-424f-8d39-20e0cee5e23f	2026-07-09 12:59:16.672+00
2fbbb8f8-50b5-4e85-afe1-be6a0cd8e0f1	228045b1-34d6-4a27-8034-8a9860ab013e	5801bb14-ff63-4873-84b5-649306c350a8	7f6821e4-96d7-4c4f-82e9-713c49232527	2026-04-16 00:00:00	250.00	DEBIT	00668 BC 16.04.2026 погашение Дебет айланма(банкаро) -250.00 от суммы 50000.00  от 16.04.2026	Начисленные %% GP TECH UNION	312915680	6e4bd3851a79e2775a551bff3341fc0b6f8f13c4814efad1ed2adbd6ecdcc9c1	CONFIRMED	\N	ed998172-0562-425c-9a66-1ac60d0759b2	c64fd4dc-8078-424f-8d39-20e0cee5e23f	2026-07-09 12:59:16.661+00
e90a47bc-31b4-4107-b975-78260203efec	228045b1-34d6-4a27-8034-8a9860ab013e	5801bb14-ff63-4873-84b5-649306c350a8	7f6821e4-96d7-4c4f-82e9-713c49232527	2026-04-10 00:00:00	11000.00	DEBIT	00668 BC 10.04.2026 погашение Дебет айланма(ички) -11000.00 от суммы 2200000.00  от 10.04.2026	Начисленные %% GP TECH UNION	312915680	e7db178c1182e6f127b8a9b8838ee055b8555e5bd88ce8772b48055478f10576	CONFIRMED	\N	d97199c4-8389-4192-9d7b-0ae587eb0af4	c64fd4dc-8078-424f-8d39-20e0cee5e23f	2026-07-09 12:59:16.648+00
f8e32686-f661-4150-a451-8f295b6ac024	228045b1-34d6-4a27-8034-8a9860ab013e	5801bb14-ff63-4873-84b5-649306c350a8	7f6821e4-96d7-4c4f-82e9-713c49232527	2026-04-29 00:00:00	8758400.00	CREDIT	00523Пред 100 % за праграмму windows 10 Pro для АДМ с-но дог 28042026-1 от 28042026 года с учетом НДС	MCHJ CASHGENICS	308710993	4961aa16bf5fcc244867e09a9c1cdec8584b5a859321727e4069a75b90508f12	CONFIRMED	\N	2e51fd5a-212c-4cba-a3d5-afa2e97c54b9	c64fd4dc-8078-424f-8d39-20e0cee5e23f	2026-07-09 12:59:16.682+00
e30751aa-4e37-440b-ae93-fe6eab405f56	228045b1-34d6-4a27-8034-8a9860ab013e	5801bb14-ff63-4873-84b5-649306c350a8	7f6821e4-96d7-4c4f-82e9-713c49232527	2026-04-28 00:00:00	718928.00	DEBIT	00668 Оплата по счету №Af000010849 от 28.04.2026	AXOFT MCHJ	305774212	90b945962c9de289fe423d912157af8eb73257509f62b4c91619a0e9fa1bae5b	CONFIRMED	\N	af31e6c4-e24e-4565-baa5-438168e57987	c64fd4dc-8078-424f-8d39-20e0cee5e23f	2026-07-09 12:59:16.676+00
85f8e755-0eba-445f-83ff-7501dcc93d99	228045b1-34d6-4a27-8034-8a9860ab013e	5801bb14-ff63-4873-84b5-649306c350a8	7f6821e4-96d7-4c4f-82e9-713c49232527	2026-04-16 00:00:00	50000.00	DEBIT	00668 ИНН 312915680 за услуги электронного документооборота Didox.uz согласно Публичной оферте	ООО Didox Tech	312915680	8b89b791d0cdd2b93555a9ca834c5b4853a74d268ceebc0a833897a7de9beeb3	CONFIRMED	\N	3265a466-9bd0-4b8b-b69c-13f1b18f5ca0	c64fd4dc-8078-424f-8d39-20e0cee5e23f	2026-07-09 12:59:16.667+00
b3ef3e42-7c16-4009-8e0e-0443730245a5	228045b1-34d6-4a27-8034-8a9860ab013e	5801bb14-ff63-4873-84b5-649306c350a8	12c40a94-ca5e-4587-a825-336e0034921e	2026-05-04 00:00:00	317.50	DEBIT	00717 Оплата Отчисление в ИНПС за апрель 2026 г $TAX_ID$26124000090370	Mirzo-Ulug`bek Tumani DSI boshlig`i USMANOV D.А.	200540423	90d6973d6a5677e752892cbbc3e55500911a1e6468f2f7d15810aee5486f0e9e	CONFIRMED	\N	2b3e652d-fb0e-4281-9400-80e74c9e4e88	31b0b237-7650-4443-88c4-464f8d3a92fc	2026-07-09 13:05:58.912+00
01d03459-bd47-4abe-a200-2eb664ba60c7	228045b1-34d6-4a27-8034-8a9860ab013e	5801bb14-ff63-4873-84b5-649306c350a8	12c40a94-ca5e-4587-a825-336e0034921e	2026-05-22 00:00:00	67600.00	DEBIT	00668 BC 22.05.2026 погашение Дебет айланма(банкаро) -67600.00 от суммы 13520000.00  от 22.05.2026	Начисленные %% GP TECH UNION	312915680	590dbdcc4ffa00af53397091c58fa65bf8405be974fde6d95954f7929fdc0799	CONFIRMED	\N	de23966a-d8bc-4c74-abec-cbe0c5699600	31b0b237-7650-4443-88c4-464f8d3a92fc	2026-07-09 13:05:58.994+00
a707fa37-6c92-465c-b6d3-3b21de659b1f	228045b1-34d6-4a27-8034-8a9860ab013e	5801bb14-ff63-4873-84b5-649306c350a8	12c40a94-ca5e-4587-a825-336e0034921e	2026-05-18 00:00:00	115000.00	DEBIT	00668 BC 18.05.2026 погашение Дебет айланма(ички) -115000.00 от суммы 23000000.00  от 18.05.2026	Начисленные %% GP TECH UNION	312915680	7ce9ada1fc0841e8872835af542888a9f9e317e9bd249f70bc83bdd7bc9c792d	CONFIRMED	\N	cf54202e-1701-49a3-95d9-e9e4812eeaf7	31b0b237-7650-4443-88c4-464f8d3a92fc	2026-07-09 13:05:58.971+00
c9f12f02-fb9a-4b75-b721-a51b19b95529	228045b1-34d6-4a27-8034-8a9860ab013e	5801bb14-ff63-4873-84b5-649306c350a8	12c40a94-ca5e-4587-a825-336e0034921e	2026-05-22 00:00:00	13520000.00	DEBIT	00658 Возврат ошибочно отправленного платежа	ООО "PHARMIQ ACADEMY"	309799613	3495875feaadaf167576a64852da5cc5bce6040a98638b63500e5fd17dbe7ed5	SKIPPED	\N	\N	31b0b237-7650-4443-88c4-464f8d3a92fc	2026-07-09 13:05:58.999+00
af5821c5-33ac-4a22-906e-23f91cab958b	228045b1-34d6-4a27-8034-8a9860ab013e	5801bb14-ff63-4873-84b5-649306c350a8	12c40a94-ca5e-4587-a825-336e0034921e	2026-05-21 00:00:00	13520000.00	CREDIT	00668Оплата согласно договору №21052026-1 от 21.05.2026г. 100% предоплата	ООО "PHARMIQ ACADEMY"	309799613	7285aeb9b5a2a3f89b379032c670df3160671a3b3267909eef4784d0a1103ce3	SKIPPED	\N	\N	31b0b237-7650-4443-88c4-464f8d3a92fc	2026-07-09 13:05:58.988+00
ee105e52-2a32-4052-ad8b-4e84db02eef1	228045b1-34d6-4a27-8034-8a9860ab013e	5801bb14-ff63-4873-84b5-649306c350a8	12c40a94-ca5e-4587-a825-336e0034921e	2026-05-18 00:00:00	23000000.00	DEBIT	00634 ОПЛАТА ПО ДОГОВОРУ ССУДЫ 18052026-1С от 18.05.2026 НА КАРТУ ДИР 5614682900908783 BURANOV AXMADJON	ORIENT FINANS BANK	207086151	04081e2846f0be158f529805c6e8e72ee5ec215a226a9113b0b0ab836db8163a	CONFIRMED	\N	c4b78d9a-9d79-4fd1-bd2e-4a320f43dcc3	31b0b237-7650-4443-88c4-464f8d3a92fc	2026-07-09 13:05:58.976+00
4d24f983-a951-4d9e-a6ab-54d6f8d823d9	228045b1-34d6-4a27-8034-8a9860ab013e	5801bb14-ff63-4873-84b5-649306c350a8	12c40a94-ca5e-4587-a825-336e0034921e	2026-05-18 00:00:00	9800.00	CREDIT	00634Зачисление денежных средств поставщику "GP TECH UNION" MCHJ (ИНН: 312915680) от PAYME за 16-05-2026 за услуги или товары через UZCARD. С автоудержанем (Без оплат) 2% с поставщика CID: 6a057eec7e93e0c8ccbd6b71 EXT: 6a092aab96f1798a3ad5a0af MID: 69f9bb9fdb2327ee51ec9b20	Транзитный счёт для рассчёта с коммерсантами (Payme)	312915680	096da35c919be054b5440d34610688d4615f84e779430e61bea12a4330038b58	CONFIRMED	\N	7d4683e1-8fe0-46d7-b92d-ae489a109a58	31b0b237-7650-4443-88c4-464f8d3a92fc	2026-07-09 13:05:58.966+00
b2a676ff-405a-433a-bd64-7f7fd32fc377	228045b1-34d6-4a27-8034-8a9860ab013e	5801bb14-ff63-4873-84b5-649306c350a8	12c40a94-ca5e-4587-a825-336e0034921e	2026-05-18 00:00:00	9800.00	CREDIT	00668П/О, ОПЛАТА ЗА ТОВАРЫ, УСЛУГИ ЗА 16.05.2026 ПО СЕРВИСУ №101318 ОПЛАТА ЗА УСЛУГИ NAMO WALLET CОГ-НО ДОГ.№BI/D 30017\\TASH ОТ 2026-04-06 ЧЕРЕЗ CLICK. СУММА ПРОДАЖ 10000.00 СУМ. УДЕРЖАНО ОТ СУММЫ ПЛАТЕЖА: -КОМИССИЯ С ПЛАТЕЖА 200.00 СУМ;  . (№2361525, ОБЩ. СУММА 9800 UZS, ОТ 18.05.2026Г.)	"CLICK" AJ	302134733	aa79857a6fc2d226eefd7623ce8e335bbfd1dd74e89cf707d6ef0f79ec2eb455	CONFIRMED	\N	3fe7aafa-78ab-4d78-89a1-9294678c3503	31b0b237-7650-4443-88c4-464f8d3a92fc	2026-07-09 13:05:58.981+00
000728fd-59c3-4672-bcb7-8877c1c5860e	228045b1-34d6-4a27-8034-8a9860ab013e	5801bb14-ff63-4873-84b5-649306c350a8	12c40a94-ca5e-4587-a825-336e0034921e	2026-05-04 00:00:00	9800.00	CREDIT	00668П/О, ОПЛАТА ЗА ТОВАРЫ, УСЛУГИ ЗА 02.05.2026 ПО СЕРВИСУ №101318 ОПЛАТА ЗА УСЛУГИ NAMO WALLET CОГ-НО ДОГ.№BI/D 30017\\TASH ОТ 2026-04-06 ЧЕРЕЗ CLICK. СУММА ПРОДАЖ 10000.00 СУМ. УДЕРЖАНО ОТ СУММЫ ПЛАТЕЖА: -КОМИССИЯ С ПЛАТЕЖА 200.00 СУМ;  . (№2151952, ОБЩ. СУММА 9800 UZS, ОТ 04.05.2026Г.)	"CLICK" AJ	302134733	22faa5ba8ae347619c72ccf9a9cd2219ae3e34dd5c77745e6e9c321881ce29a2	CONFIRMED	\N	b65d11bc-5cff-41d2-b472-57219d107a2f	31b0b237-7650-4443-88c4-464f8d3a92fc	2026-07-09 13:05:58.945+00
8e91b516-4f82-4c00-899e-1978c0e232ab	228045b1-34d6-4a27-8034-8a9860ab013e	5801bb14-ff63-4873-84b5-649306c350a8	12c40a94-ca5e-4587-a825-336e0034921e	2026-05-12 00:00:00	27000.00	DEBIT	00668 СЧЕТ НА ОПЛАТУ № 573749 от 11.05.2026 к Договору № ДХ-2848-05/26 от 11.05.2026	ООО "SUVAN NET"	301551793	55f38154b134ab3a1642f0a26b5007706ba9744cb4bb91eccc48ad24e56e019a	CONFIRMED	\N	316bf16a-1bf7-44ce-8321-35a237c99395	31b0b237-7650-4443-88c4-464f8d3a92fc	2026-07-09 13:05:58.961+00
c7f5362e-e9dd-4c54-bbe6-9f8a4c0864ad	228045b1-34d6-4a27-8034-8a9860ab013e	5801bb14-ff63-4873-84b5-649306c350a8	12c40a94-ca5e-4587-a825-336e0034921e	2026-05-07 00:00:00	22000000.00	CREDIT	0066800668 Оплата 100% согл дог № 05052026-3 от 05.05.2026 за услуги по предоставлению лицензий на программное обеспечение Creative Cloud Pro for teams ALL Multiple Platforms	ИП ООО "SMART SOLUTIONS INTERNATIONAL"	310332959	a8767167529e6b224204cddb37f31d82be193bb2069ae1dc60fb2394f58e10be	CONFIRMED	\N	78e4fdc3-f8d3-4994-aa1f-190e2cf23341	31b0b237-7650-4443-88c4-464f8d3a92fc	2026-07-09 13:05:58.95+00
55c8b472-22c1-4648-bf9a-056ca0dfa1b9	228045b1-34d6-4a27-8034-8a9860ab013e	5801bb14-ff63-4873-84b5-649306c350a8	12c40a94-ca5e-4587-a825-336e0034921e	2026-05-04 00:00:00	317750.00	DEBIT	08102~1000218604262693111103093~200540423~Оплата Налог на доходы физических лиц (НДФЛ) за апрель 2026 г $TAX_ID$26124000090564	Казначейство Министерства финансов Республика Узбекистан	201122919	82b10b2334711f3272f412c582f0a856fa4992542fbfa728a59d90254f5f393d	CONFIRMED	\N	e8bc4baa-35fc-438b-8940-3f02fdc94e81	31b0b237-7650-4443-88c4-464f8d3a92fc	2026-07-09 13:05:58.93+00
f507ab1e-0774-425d-bf33-d5560b013039	228045b1-34d6-4a27-8034-8a9860ab013e	5801bb14-ff63-4873-84b5-649306c350a8	12c40a94-ca5e-4587-a825-336e0034921e	2026-05-04 00:00:00	2000000.00	DEBIT	00647 Оплата аренды по договору № 3 01.04.2026й	VIDIMO MCHJ	310783571	9c54d79bb5de654198efa586a3dfc59a487d5df868bd2082dc9055f3bf0e9254	CONFIRMED	\N	be229a41-64c1-43e5-8059-e20e000adc71	31b0b237-7650-4443-88c4-464f8d3a92fc	2026-07-09 13:05:58.938+00
eedbdcb1-d191-4314-a6eb-72c72ccd0f77	228045b1-34d6-4a27-8034-8a9860ab013e	5801bb14-ff63-4873-84b5-649306c350a8	12c40a94-ca5e-4587-a825-336e0034921e	2026-05-12 00:00:00	135.00	DEBIT	00668 BC 12.05.2026 погашение Дебет айланма(банкаро) -135.00 от суммы 27000.00  от 12.05.2026	Начисленные %% GP TECH UNION	312915680	98403dc98d2036a88f7c3d1e0c831fcc30e376199fb95da16c7d1cc126b8fc4a	CONFIRMED	\N	219c3b57-72b1-40f6-a85d-a5222efc6c40	31b0b237-7650-4443-88c4-464f8d3a92fc	2026-07-09 13:05:58.956+00
f69df85a-7b28-4876-bdec-df241e0570dd	228045b1-34d6-4a27-8034-8a9860ab013e	5801bb14-ff63-4873-84b5-649306c350a8	12c40a94-ca5e-4587-a825-336e0034921e	2026-05-04 00:00:00	10000.00	DEBIT	00668 BC 04.05.2026 погашение Дебет айланма(банкаро) -10000.00 от суммы 2000000.00  от 04.05.2026	Начисленные %% GP TECH UNION	312915680	1b0da3175a104f1f33e8583122538dbdba8f0650211933c3ee662c592aff7e2f	CONFIRMED	\N	6878037d-e213-42b4-8a3f-abfa8418cd3d	31b0b237-7650-4443-88c4-464f8d3a92fc	2026-07-09 13:05:58.917+00
b990a33f-588d-4043-a035-41b17fff4cfb	228045b1-34d6-4a27-8034-8a9860ab013e	5801bb14-ff63-4873-84b5-649306c350a8	12c40a94-ca5e-4587-a825-336e0034921e	2026-05-04 00:00:00	38130.00	DEBIT	08102~2001108606262693212160093~200540423~Оплата Социальный налог за апрель 2026 г $TAX_ID$26124000090434	Казначейство Министерства финансов Республика Узбекистан	201122919	7a63ce4d29e8cdd69b3546da93b87ac129d99cd1a4e4070b11474e5c85606147	CONFIRMED	\N	f2de3f2a-a296-4918-b407-7dd1c17de6aa	31b0b237-7650-4443-88c4-464f8d3a92fc	2026-07-09 13:05:58.923+00
4402e5e0-04e4-4fd5-a065-40c1a4752038	228045b1-34d6-4a27-8034-8a9860ab013e	5801bb14-ff63-4873-84b5-649306c350a8	7a927f44-73c4-42d6-a03e-73d32327dbc5	2026-06-01 00:00:00	864586.29	DEBIT	08102~1000228609262693141102093~200540423~Оплата Налог на добавленную стоимость за май 2026 г $TAX_ID$26152000706734	Казначейство Министерства финансов Республика Узбекистан	201122919	996dfe83bf59fb1f3d852dd18ae7d7fa90f24f4c22247d5ee1fa43a7d335158a	CONFIRMED	\N	b0b6bda9-3e50-483f-96e1-68599833266f	f71ecf7b-2091-4898-a2eb-3f65a4b4b218	2026-07-09 13:11:03.767+00
e1c5e1f8-2469-4c46-9e15-48c59065428d	228045b1-34d6-4a27-8034-8a9860ab013e	5801bb14-ff63-4873-84b5-649306c350a8	7a927f44-73c4-42d6-a03e-73d32327dbc5	2026-06-01 00:00:00	37812.25	DEBIT	08102~1000218604262693111103093~200540423~Оплата Налог на доходы физических лиц (НДФЛ) за май 2026 г $TAX_ID$26152000707678	Казначейство Министерства финансов Республика Узбекистан	201122919	1bc36baabda57166ca949723407c58e19fe7d13f6722035b9ec9a63dd470dead	CONFIRMED	\N	53761d90-2d33-4fe6-ae87-ba0ffd3c1264	f71ecf7b-2091-4898-a2eb-3f65a4b4b218	2026-07-09 13:11:03.754+00
0c2dcb1a-f801-4835-9e1b-0bdde11dd2d9	228045b1-34d6-4a27-8034-8a9860ab013e	5801bb14-ff63-4873-84b5-649306c350a8	7a927f44-73c4-42d6-a03e-73d32327dbc5	2026-06-03 00:00:00	540.00	DEBIT	00111 BC 03.06.2026 погашение Дебет айланма(банкаро) -540.00 от суммы 108000.00  от 03.06.2026	Начисленные %% GP TECH UNION	312915680	b9366957ce00321e12e85e86f588328ef6aa3d736043cd2c49164522a91123f5	CONFIRMED	\N	550d7573-4c1f-47b7-8e1d-e141883d295d	f71ecf7b-2091-4898-a2eb-3f65a4b4b218	2026-07-09 13:11:03.786+00
91f41346-ab8a-43f6-9ccd-e296f2e94946	228045b1-34d6-4a27-8034-8a9860ab013e	5801bb14-ff63-4873-84b5-649306c350a8	7a927f44-73c4-42d6-a03e-73d32327dbc5	2026-06-01 00:00:00	317.50	DEBIT	00717 Оплата Отчисление в ИНПС за май 2026 г $TAX_ID$26152000707018	Mirzo-Ulug`bek Tumani DSI boshlig`i USMANOV D.А.	200540423	c495995a0221170a10a262d7b984ca5f33ed137e98e833ffbe4d62d9bffceca3	CONFIRMED	\N	41de570d-fbc4-456a-a719-283eb13c744d	f71ecf7b-2091-4898-a2eb-3f65a4b4b218	2026-07-09 13:11:03.748+00
70b2e66e-6209-4f63-9ccc-99543c3a09a6	228045b1-34d6-4a27-8034-8a9860ab013e	5801bb14-ff63-4873-84b5-649306c350a8	7a927f44-73c4-42d6-a03e-73d32327dbc5	2026-06-01 00:00:00	12900000.00	CREDIT	00111П/О, 01.06.2026ЙИЛДАГИ ШАРТНОМА№ №1062026-1ГА АСОСАН  GOOGLE ISH  MAYDONI BIZNES BOSHLANG`ICH - 10 FOYDALANUVCHI UCHUN 12 OY УЧУН ТУЛОВ.. (№1213, ОБЩ. СУММА 12900000 UZS, ОТ 01.06.2026Г.)	"MEGATON" MCHJ	311010005	0b31db07843a7c63f1c75665063ec497de9236b4f855417c4749d1f3f01d0d40	CONFIRMED	\N	f1791b1a-0bfc-400c-9174-bf34095b8ee1	f71ecf7b-2091-4898-a2eb-3f65a4b4b218	2026-07-09 13:11:03.772+00
f51e607d-6e71-4489-9a24-e212106915f8	228045b1-34d6-4a27-8034-8a9860ab013e	5801bb14-ff63-4873-84b5-649306c350a8	7a927f44-73c4-42d6-a03e-73d32327dbc5	2026-06-02 00:00:00	3000000.00	DEBIT	00111 Залог по ИНН 312915680 GP TECH UNION	АО Узбекская Республиканская товарно-сырьевая биржа	312915680	16a2225168afc1e0b05a7e41c2eba626efd5be789cbbe08c4c26ac24b5c1bc27	CONFIRMED	\N	68431629-82a5-4424-8513-0a353d73847a	f71ecf7b-2091-4898-a2eb-3f65a4b4b218	2026-07-09 13:11:03.782+00
50716515-cb7d-4a00-8fce-877fe053ea29	228045b1-34d6-4a27-8034-8a9860ab013e	5801bb14-ff63-4873-84b5-649306c350a8	7a927f44-73c4-42d6-a03e-73d32327dbc5	2026-06-02 00:00:00	15000.00	DEBIT	00111 BC 02.06.2026 погашение Дебет айланма(банкаро) -15000.00 от суммы 3000000.00  от 02.06.2026	Начисленные %% GP TECH UNION	312915680	940caed5610b6f455f8d2d6fafbcd2b6aede4ad0c970338d11b666f63e64d501	CONFIRMED	\N	cb806713-eb7e-4d54-bdda-1275cdfd268a	f71ecf7b-2091-4898-a2eb-3f65a4b4b218	2026-07-09 13:11:03.777+00
08d55234-48e5-4025-b0de-dc41c7127520	228045b1-34d6-4a27-8034-8a9860ab013e	5801bb14-ff63-4873-84b5-649306c350a8	7a927f44-73c4-42d6-a03e-73d32327dbc5	2026-06-03 00:00:00	292640000.00	CREDIT	00111Каспер по дог.№21052026-1 от 21.05.2026г.	GRAND  PHARM  TRADE MCHJ	303303592	1e1a2310dc3e4508d9c03e2a72090e66b501cebd1375d257250875096226b7d8	CONFIRMED	\N	e83e6bc6-2603-4e58-a51d-d69857399d3b	f71ecf7b-2091-4898-a2eb-3f65a4b4b218	2026-07-09 13:11:03.795+00
baf548b1-d4cd-471b-8e22-e421e0b4a600	228045b1-34d6-4a27-8034-8a9860ab013e	5801bb14-ff63-4873-84b5-649306c350a8	7a927f44-73c4-42d6-a03e-73d32327dbc5	2026-06-03 00:00:00	108000.00	DEBIT	00103 СЧЕТ НА ОПЛАТУ № 581649 от 03.06.2026 к Договору № ДХ-2848-05/26 от 11.05.2026	ООО "SUVAN NET"	301551793	1fca82437f84f0880b5447e4c0f7f3524df320f80ca51bb3233bce7f0e28531d	CONFIRMED	\N	aae08362-44ef-44be-90db-010c074c39c7	f71ecf7b-2091-4898-a2eb-3f65a4b4b218	2026-07-09 13:11:03.79+00
8906a42c-2fd5-4be9-89bc-156b5d3737c8	228045b1-34d6-4a27-8034-8a9860ab013e	5801bb14-ff63-4873-84b5-649306c350a8	7a927f44-73c4-42d6-a03e-73d32327dbc5	2026-06-05 00:00:00	69090000.00	CREDIT	42110Оплата по договору №05062026-1 от 04.06.2026г  Microsoft 365 Business Standart. Рапорт №12-04/922 от 04.06.2026	"KAFOLAT SUGURTA KOMPANIYASI AJ"	202288236	07328e32c8cb9949c3319aee900b7a607478b8c566a9d3d845d18b645f002e3a	CONFIRMED	\N	7b65e3d5-7721-4e6b-ad83-8e745596fdf4	f71ecf7b-2091-4898-a2eb-3f65a4b4b218	2026-07-09 13:11:03.846+00
c6c32e37-eefa-4e99-a69a-96703f458c35	228045b1-34d6-4a27-8034-8a9860ab013e	5801bb14-ff63-4873-84b5-649306c350a8	7a927f44-73c4-42d6-a03e-73d32327dbc5	2026-06-04 00:00:00	5376000.00	CREDIT	0011100111 За услуги приобретения лицензий на программное обеспечение Microsoft Windows 11 Professional Retail  сог. дог. № 04062026-1 от 04.06.2027г. Предоплата 100%.	ООО CALLIE LIMITED	312384465	e0ea139c39460bf0e49d19c7ee5df4771308fda8eb04bd28eb99035623bc9517	CONFIRMED	\N	d9882e12-e27a-4f4d-beeb-a5b4102befc6	f71ecf7b-2091-4898-a2eb-3f65a4b4b218	2026-07-09 13:11:03.829+00
9ca5b2c3-d34d-46d7-98b8-4dad81583ce5	228045b1-34d6-4a27-8034-8a9860ab013e	5801bb14-ff63-4873-84b5-649306c350a8	7a927f44-73c4-42d6-a03e-73d32327dbc5	2026-06-04 00:00:00	273459200.00	DEBIT	00103 Оплата по счету №Af000011293 от 04.06.2026	AXOFT MCHJ	305774212	428fb0deb8b74a5a9e8e80cfb2c21632a9f5565433ce4f2b9cd4c08c4d092262	CONFIRMED	\N	821ff739-ceb3-468b-a469-3188c9c2adfe	f71ecf7b-2091-4898-a2eb-3f65a4b4b218	2026-07-09 13:11:03.825+00
4eee711b-7df4-4381-9f96-881b2ae311e1	228045b1-34d6-4a27-8034-8a9860ab013e	5801bb14-ff63-4873-84b5-649306c350a8	7a927f44-73c4-42d6-a03e-73d32327dbc5	2026-06-04 00:00:00	2000000.00	DEBIT	00647 Оплата аренды по договору № 3 01.04.2026й	VIDIMO MCHJ	310783571	8b71a08f799f8c3f42dd557fc9c65b84e748713161956d67cebc4ad6b455ee1a	CONFIRMED	\N	a67fe804-1e2b-4797-8e39-d7131fbef04b	f71ecf7b-2091-4898-a2eb-3f65a4b4b218	2026-07-09 13:11:03.815+00
de11b2de-3c6b-4209-8f24-a38e9e860de6	228045b1-34d6-4a27-8034-8a9860ab013e	5801bb14-ff63-4873-84b5-649306c350a8	7a927f44-73c4-42d6-a03e-73d32327dbc5	2026-06-09 00:00:00	11760000.00	DEBIT	00112 Оплата за Google Workspace Business Starter -1 Y (12 месяцев) по Договору №2026-37	SOFTPROM MCHJ	311149962	520244e2b45aa11cdd7d6207c6342dd5a9163fc71e9b807f2b41d13500254578	CONFIRMED	\N	d3b7b6ff-39ed-4f60-b72a-cb0f5ef56e51	f71ecf7b-2091-4898-a2eb-3f65a4b4b218	2026-07-09 13:11:03.857+00
1afab132-9ec0-48c0-b402-a6a8bc135233	228045b1-34d6-4a27-8034-8a9860ab013e	5801bb14-ff63-4873-84b5-649306c350a8	7a927f44-73c4-42d6-a03e-73d32327dbc5	2026-06-11 00:00:00	17230131.20	DEBIT	00112 Оплата CFQ7TTC0LDPB:0001:YY Microsoft 365 Business Standard № 81 от 11.06.2026 к договору № 41 от 08.06.2026	APN PROMISE ARAL MCHJ XK	311509237	bbdb96758c597a0401b143c76e2b7471357b1ef8030872fd2dca37930c82ea1b	CONFIRMED	\N	ac054429-ae2a-4031-8118-ff6aee3e0307	f71ecf7b-2091-4898-a2eb-3f65a4b4b218	2026-07-09 13:11:03.871+00
a2c05b22-289a-4139-acbb-4c4a19d50009	228045b1-34d6-4a27-8034-8a9860ab013e	5801bb14-ff63-4873-84b5-649306c350a8	7a927f44-73c4-42d6-a03e-73d32327dbc5	2026-06-16 00:00:00	3244000.00	CREDIT	00098 Предоплата 100% за программное обеспечение Kaspersky Small согл. дог. №15062026-1 от 15.06.26г. В т.ч. НДС.	ООО "CENTRAL ASIA MEGASTAR" - основной депозитный счет до востребовани	200642271	44578ae14f443c062e09889733793b17dd656e66ae9c4ae0b1cf811e977c295a	CONFIRMED	\N	01b8648a-010f-42a3-b6ec-54288965b3d2	f71ecf7b-2091-4898-a2eb-3f65a4b4b218	2026-07-09 13:11:03.881+00
96bd0766-7f55-45ae-8b90-6497235f57e0	228045b1-34d6-4a27-8034-8a9860ab013e	5801bb14-ff63-4873-84b5-649306c350a8	7a927f44-73c4-42d6-a03e-73d32327dbc5	2026-06-12 00:00:00	3000000.00	CREDIT	00658 Возврат д/с с лиц/счета №20-10-01-0613342-860-001, согл поручения клиента от с перс кабинета 312915680 ?GP TECH UNION MCHJ?	AO UZRTSB	200933985	f69b83e8a15bc94a9562657cf5ec662ee713ddfa4ebca9f859082689b8614480	CONFIRMED	\N	20968e04-8198-489b-9bf2-0c2137596932	f71ecf7b-2091-4898-a2eb-3f65a4b4b218	2026-07-09 13:11:03.876+00
4d9540a9-c177-41f0-9983-ab9a5d96c474	228045b1-34d6-4a27-8034-8a9860ab013e	5801bb14-ff63-4873-84b5-649306c350a8	7a927f44-73c4-42d6-a03e-73d32327dbc5	2026-06-05 00:00:00	30000000.00	DEBIT	00634 ОПЛАТА ПО ДОГОВОРУ ССУДЫ 18052026-1С от 18.05.2026 НА КАРТУ ДИР 5614682900908783 BURANOV AXMADJON	ORIENT FINANS BANK	207086151	03171cd3f5a82a58a1ec1376aa65276b4bcd73da2455c844b6368f969f186a36	CONFIRMED	\N	bdd58d95-d287-401f-8d36-56a41b35faa0	f71ecf7b-2091-4898-a2eb-3f65a4b4b218	2026-07-09 13:11:03.841+00
2a8c969d-9efe-4a87-b837-7208144f149c	228045b1-34d6-4a27-8034-8a9860ab013e	5801bb14-ff63-4873-84b5-649306c350a8	7a927f44-73c4-42d6-a03e-73d32327dbc5	2026-06-04 00:00:00	30000000.00	DEBIT	00634 ОПЛАТА ПО ДОГОВОРУ ССУДЫ 18052026-1С от 18.05.2026 НА КАРТУ ДИР 5614682900908783 BURANOV AXMADJON	ORIENT FINANS BANK	207086151	03997dd71c2b9fe6b948265da9ee3aba414d53bbc2032c097bcf8a91882938bc	CONFIRMED	\N	5506b7cd-c391-49ec-8b80-36fb8c102c5e	f71ecf7b-2091-4898-a2eb-3f65a4b4b218	2026-07-09 13:11:03.82+00
a2f84a5c-ff2f-4324-92f5-ae10c0e4843f	228045b1-34d6-4a27-8034-8a9860ab013e	5801bb14-ff63-4873-84b5-649306c350a8	7a927f44-73c4-42d6-a03e-73d32327dbc5	2026-06-24 00:00:00	2200.00	DEBIT	00111 BC 24.06.2026 погашение Дебет айланма(банкаро) -2200.00 от суммы 440000.00  от 24.06.2026	Начисленные %% GP TECH UNION	312915680	8e65cfbe3316c0e22e7760d5ada75fd3454753287166dd30673e3662f3e5b04b	CONFIRMED	\N	7d1d1831-85dd-4a60-8dca-0c57933c315d	f71ecf7b-2091-4898-a2eb-3f65a4b4b218	2026-07-09 13:11:03.903+00
cd5d09ed-60f8-4180-b954-362bd3b1526c	228045b1-34d6-4a27-8034-8a9860ab013e	5801bb14-ff63-4873-84b5-649306c350a8	7a927f44-73c4-42d6-a03e-73d32327dbc5	2026-06-05 00:00:00	150000.00	DEBIT	00111 BC 05.06.2026 погашение Дебет айланма(ички) -150000.00 от суммы 30000000.00  от 05.06.2026	Начисленные %% GP TECH UNION	312915680	0dc17b2782e7b20af03fcd7e958d5277717bb144566e1fed9c971407d5c58a06	CONFIRMED	\N	91a3ebac-7df7-4486-b822-70297179e97e	f71ecf7b-2091-4898-a2eb-3f65a4b4b218	2026-07-09 13:11:03.836+00
ef789af1-f043-4c0f-8520-9663a9592114	228045b1-34d6-4a27-8034-8a9860ab013e	5801bb14-ff63-4873-84b5-649306c350a8	7a927f44-73c4-42d6-a03e-73d32327dbc5	2026-06-09 00:00:00	58800.00	DEBIT	00111 BC 09.06.2026 погашение Дебет айланма(банкаро) -58800.00 от суммы 11760000.00  от 09.06.2026	Начисленные %% GP TECH UNION	312915680	d2e6e3fbec5e3321f81ec35b6b513ea0b1b3a9fbed9d3804b4105bb3799e772f	CONFIRMED	\N	b1d210e7-b80d-4ea8-90a1-9ffebade3b93	f71ecf7b-2091-4898-a2eb-3f65a4b4b218	2026-07-09 13:11:03.852+00
b52b68a4-c939-410c-90da-3e32af40a1d9	228045b1-34d6-4a27-8034-8a9860ab013e	5801bb14-ff63-4873-84b5-649306c350a8	7a927f44-73c4-42d6-a03e-73d32327dbc5	2026-06-11 00:00:00	86150.66	DEBIT	00111 BC 11.06.2026 погашение Дебет айланма(банкаро) -86150.66 от суммы 17230131.20  от 11.06.2026	Начисленные %% GP TECH UNION	312915680	d3624c6c9e67937a95c71c0b5b098fb6c9ffa77df0504615b458b81bcdd0dcd4	CONFIRMED	\N	d9ce31f7-dd4e-4c95-966b-773f593b0375	f71ecf7b-2091-4898-a2eb-3f65a4b4b218	2026-07-09 13:11:03.866+00
91cfeae4-951c-414b-9f1f-3e17753b252b	228045b1-34d6-4a27-8034-8a9860ab013e	5801bb14-ff63-4873-84b5-649306c350a8	7a927f44-73c4-42d6-a03e-73d32327dbc5	2026-06-19 00:00:00	50000.00	DEBIT	00111 BC 19.06.2026 погашение Дебет айланма(банкаро) -50000.00 от суммы 10000000.00  от 19.06.2026	Начисленные %% GP TECH UNION	312915680	a2071461012478433e107c704c3017120fb38e9ebf4bb4ee5dd52561df4454a4	CONFIRMED	\N	1a42d156-cfc7-42d4-8857-69eb740375bc	f71ecf7b-2091-4898-a2eb-3f65a4b4b218	2026-07-09 13:11:03.885+00
1c30e254-b8d6-48ca-bc5f-345e514f97ae	228045b1-34d6-4a27-8034-8a9860ab013e	5801bb14-ff63-4873-84b5-649306c350a8	7a927f44-73c4-42d6-a03e-73d32327dbc5	2026-06-04 00:00:00	150000.00	DEBIT	00111 BC 04.06.2026 погашение Дебет айланма(ички) -150000.00 от суммы 30000000.00  от 04.06.2026	Начисленные %% GP TECH UNION	312915680	2ef2645f915a57fa0a8314b095b4235ecb4dca70fe5c698dcd38b706566363d1	CONFIRMED	\N	e7b9c4f6-4f29-473d-9773-4efb4e829728	f71ecf7b-2091-4898-a2eb-3f65a4b4b218	2026-07-09 13:11:03.806+00
185bc366-dc2c-4711-9911-fc10c251381a	228045b1-34d6-4a27-8034-8a9860ab013e	5801bb14-ff63-4873-84b5-649306c350a8	7a927f44-73c4-42d6-a03e-73d32327dbc5	2026-06-04 00:00:00	1367296.00	DEBIT	00111 BC 04.06.2026 погашение Дебет айланма(банкаро) -1367296.00 от суммы 273459200.00  от 04.06.2026	Начисленные %% GP TECH UNION	312915680	c22247d0383eefe6ba3f59da16be258b81e90ba6d48b022fbcea5dafb8698fa1	CONFIRMED	\N	a1003312-7511-483f-8163-1deb296f8e5c	f71ecf7b-2091-4898-a2eb-3f65a4b4b218	2026-07-09 13:11:03.811+00
41165517-fad6-4b4a-a231-9ea9fee47ce1	228045b1-34d6-4a27-8034-8a9860ab013e	5801bb14-ff63-4873-84b5-649306c350a8	7a927f44-73c4-42d6-a03e-73d32327dbc5	2026-06-04 00:00:00	10000.00	DEBIT	00111 BC 04.06.2026 погашение Дебет айланма(банкаро) -10000.00 от суммы 2000000.00  от 04.06.2026	Начисленные %% GP TECH UNION	312915680	85ffc1ac03a91046b2ce505824dbc0bdae57e903356ed6fb4c6148ad9abd1549	CONFIRMED	\N	89c82fc4-b714-4284-9feb-10e0555d3177	f71ecf7b-2091-4898-a2eb-3f65a4b4b218	2026-07-09 13:11:03.801+00
0da87071-3bbc-4493-9182-23f68e323f4d	228045b1-34d6-4a27-8034-8a9860ab013e	5801bb14-ff63-4873-84b5-649306c350a8	7a927f44-73c4-42d6-a03e-73d32327dbc5	2026-06-24 00:00:00	440000.00	DEBIT	00098 Оплата за Карточка ф.100х140мм, бумага: 300гр/м2, печать: 4+4 + вырубка по контуру~~~	"SEAL MAG" AJ	201535024	401061ffe42c00fcf20668c3812dc6ad06acc0d76b88029706edca45a865ebfb	CONFIRMED	\N	21be39e8-aa00-4b16-906c-fe79c21d3e3b	f71ecf7b-2091-4898-a2eb-3f65a4b4b218	2026-07-09 13:11:03.908+00
365bd283-77e9-4cd7-a8b7-a986d24bb36f	228045b1-34d6-4a27-8034-8a9860ab013e	5801bb14-ff63-4873-84b5-649306c350a8	7a927f44-73c4-42d6-a03e-73d32327dbc5	2026-06-19 00:00:00	10000000.00	DEBIT	00111 Оплата залога ИНН: 312915680	АО Узбекская Республиканская товарно-сырьевая биржа	312915680	88258685571796061d385fb215c2f9aa43e14bbec73e7bc9f6a76a5cfd214341	CONFIRMED	\N	077b80f7-1e33-45f9-9e92-81dc082d6a78	f71ecf7b-2091-4898-a2eb-3f65a4b4b218	2026-07-09 13:11:03.893+00
\.


--
-- Data for Name: Subscription; Type: TABLE DATA; Schema: public; Owner: user
--

COPY public."Subscription" (id, "orgId", plan, "validUntil", "customApiKey", "updatedAt") FROM stdin;
cb28dff6-c93a-404d-879e-84756b745ef0	1e996ba7-c636-4bdb-8fa9-16548f4d291e	PRO	2027-07-08 11:07:43.406	\N	2026-07-08 11:07:43.407
3e34b7ee-86f4-4c86-9e07-c7300bde00f5	9b41b1b5-f6bf-4d28-a299-f645126d578b	PRO	2027-07-08 11:07:43.406	\N	2026-07-08 11:08:06.01
04278d80-d408-4586-a077-d71521648d06	228045b1-34d6-4a27-8034-8a9860ab013e	PRO	2027-07-08 11:07:43.406	\N	2026-07-09 12:53:47.399
\.


--
-- Data for Name: TaxCalendarEvent; Type: TABLE DATA; Schema: public; Owner: user
--

COPY public."TaxCalendarEvent" (id, "orgId", "periodId", type, "dueDate", status, "estimatedAmount", note) FROM stdin;
5c3a5a9d-4d49-4d0a-909b-6edfab4f9578	9b41b1b5-f6bf-4d28-a299-f645126d578b	f623fd76-5028-4900-b760-b70090905288	PERSONAL_INCOME_TAX	2026-06-20 00:00:00	PENDING	238000.00	Рассчитано при закрытии 5/2026
cd04d460-86b1-44c8-99d9-a00c1f683cfd	9b41b1b5-f6bf-4d28-a299-f645126d578b	f623fd76-5028-4900-b760-b70090905288	INPS	2026-06-20 00:00:00	PENDING	2000.00	Рассчитано при закрытии 5/2026
6ae2bb6f-37c4-464c-a4ab-a18266d94f79	9b41b1b5-f6bf-4d28-a299-f645126d578b	f623fd76-5028-4900-b760-b70090905288	SOCIAL_TAX	2026-06-20 00:00:00	PENDING	240000.00	Рассчитано при закрытии 5/2026
ab14fc43-9463-4306-883b-85f023f05ed4	9b41b1b5-f6bf-4d28-a299-f645126d578b	4f03361b-3c66-4bd6-9343-0876d6d8ac74	PERSONAL_INCOME_TAX	2026-07-20 00:00:00	PENDING	238000.00	Рассчитано при закрытии 6/2026
40b41a31-6a82-41dc-abd2-3a66a6ed43b8	9b41b1b5-f6bf-4d28-a299-f645126d578b	4f03361b-3c66-4bd6-9343-0876d6d8ac74	INPS	2026-07-20 00:00:00	PENDING	2000.00	Рассчитано при закрытии 6/2026
3b094f80-5f91-4fab-a009-12dc6c76724c	9b41b1b5-f6bf-4d28-a299-f645126d578b	4f03361b-3c66-4bd6-9343-0876d6d8ac74	SOCIAL_TAX	2026-07-20 00:00:00	PENDING	240000.00	Рассчитано при закрытии 6/2026
f93986ad-cfd9-429b-9151-d670bb011f6d	228045b1-34d6-4a27-8034-8a9860ab013e	7f6821e4-96d7-4c4f-82e9-713c49232527	INPS	2026-05-20 00:00:00	PENDING	317.75	Рассчитано при закрытии 4/2026
839cd444-2288-4883-aeb8-ff47f6e794d0	228045b1-34d6-4a27-8034-8a9860ab013e	7f6821e4-96d7-4c4f-82e9-713c49232527	SOCIAL_TAX	2026-05-20 00:00:00	PENDING	38130.00	Рассчитано при закрытии 4/2026
09c7f23d-3b2c-49c9-b0a3-9366bf892f7b	228045b1-34d6-4a27-8034-8a9860ab013e	7f6821e4-96d7-4c4f-82e9-713c49232527	PERSONAL_INCOME_TAX	2026-05-20 00:00:00	DONE	37812.25	Рассчитано при закрытии 4/2026
3ec8c4d7-bfac-4e71-aa5d-91a87eb676c3	228045b1-34d6-4a27-8034-8a9860ab013e	7a927f44-73c4-42d6-a03e-73d32327dbc5	PERSONAL_INCOME_TAX	2026-07-20 00:00:00	PENDING	476000.00	Рассчитано при закрытии 6/2026
1468deee-4a4e-43f2-9bd3-d8b1fac31a45	228045b1-34d6-4a27-8034-8a9860ab013e	7a927f44-73c4-42d6-a03e-73d32327dbc5	INPS	2026-07-20 00:00:00	PENDING	4000.00	Рассчитано при закрытии 6/2026
05bbea41-9b5e-44d6-8392-bbcf5871c2d5	228045b1-34d6-4a27-8034-8a9860ab013e	7a927f44-73c4-42d6-a03e-73d32327dbc5	SOCIAL_TAX	2026-07-20 00:00:00	PENDING	480000.00	Рассчитано при закрытии 6/2026
\.


--
-- Data for Name: TaxDeadlineTemplate; Type: TABLE DATA; Schema: public; Owner: user
--

COPY public."TaxDeadlineTemplate" (id, "orgId", type, "dayOfMonth", frequency, "taxRegime", "isActive") FROM stdin;
\.


--
-- Data for Name: User; Type: TABLE DATA; Schema: public; Owner: user
--

COPY public."User" (id, email, "passwordHash", name, "createdAt", "activeOrgId") FROM stdin;
b6fd1a37-31da-4a14-8761-ec6b579e539c	buranov.gpunion@gmail.com	$2b$10$dX/OK7VfPzlWhSb1RmRBi.vq/iLlJQ1rzaCJNPP9UNMXEFvAFKeMK	Ahmad	2026-06-15 11:27:48.297	228045b1-34d6-4a27-8034-8a9860ab013e
\.


--
-- Data for Name: Voucher; Type: TABLE DATA; Schema: public; Owner: user
--

COPY public."Voucher" (id, code, "daysGranted", "usedByOrgId", "usedAt", "createdAt") FROM stdin;
1e451c07-6623-424e-8d85-2b30a8ebc167	CV2-A1BFF4-AF53CD	30	\N	\N	2026-06-16 08:29:03.439
3e883189-999c-4efd-b97b-3be093936f12	CV2-B7571D-8A4ADD	30	\N	\N	2026-06-16 08:29:03.439
48453a88-e2be-48c5-9087-63e35a1bcac5	CV2-74F5B2-2840DD	30	\N	2026-06-16 08:42:20.673	2026-06-16 08:29:03.439
43071633-ff1f-42dd-a63a-e748b05dfb4e	CV2-C8852F-CD26C2	15	\N	\N	2026-06-23 09:14:43.205
23f1e79d-1fb8-4572-92ba-26d7f645584a	CV2-1A4D33-F7DC9F	30	\N	2026-06-23 09:14:25.548	2026-06-23 09:14:13.553
bef2ff4a-c1c4-46c2-bd29-e689e5fd19bc	CV2-B1476A-83972C	7	\N	2026-06-23 09:15:24.817	2026-06-23 09:15:24.748
\.


--
-- Name: Account Account_pkey; Type: CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public."Account"
    ADD CONSTRAINT "Account_pkey" PRIMARY KEY (id);


--
-- Name: AuditLog AuditLog_pkey; Type: CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public."AuditLog"
    ADD CONSTRAINT "AuditLog_pkey" PRIMARY KEY (id);


--
-- Name: BankAccount BankAccount_pkey; Type: CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public."BankAccount"
    ADD CONSTRAINT "BankAccount_pkey" PRIMARY KEY (id);


--
-- Name: ClassificationJob ClassificationJob_pkey; Type: CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public."ClassificationJob"
    ADD CONSTRAINT "ClassificationJob_pkey" PRIMARY KEY (id);


--
-- Name: ClosingJob ClosingJob_pkey; Type: CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public."ClosingJob"
    ADD CONSTRAINT "ClosingJob_pkey" PRIMARY KEY (id);


--
-- Name: Counterparty Counterparty_pkey; Type: CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public."Counterparty"
    ADD CONSTRAINT "Counterparty_pkey" PRIMARY KEY (id);


--
-- Name: DocumentType DocumentType_pkey; Type: CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public."DocumentType"
    ADD CONSTRAINT "DocumentType_pkey" PRIMARY KEY (id);


--
-- Name: Document Document_pkey; Type: CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public."Document"
    ADD CONSTRAINT "Document_pkey" PRIMARY KEY (id);


--
-- Name: JournalEntry JournalEntry_pkey; Type: CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public."JournalEntry"
    ADD CONSTRAINT "JournalEntry_pkey" PRIMARY KEY (id);


--
-- Name: OpenItem OpenItem_pkey; Type: CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public."OpenItem"
    ADD CONSTRAINT "OpenItem_pkey" PRIMARY KEY (id);


--
-- Name: OrgMember OrgMember_pkey; Type: CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public."OrgMember"
    ADD CONSTRAINT "OrgMember_pkey" PRIMARY KEY (id);


--
-- Name: Organization Organization_pkey; Type: CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public."Organization"
    ADD CONSTRAINT "Organization_pkey" PRIMARY KEY (id);


--
-- Name: PasswordResetToken PasswordResetToken_pkey; Type: CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public."PasswordResetToken"
    ADD CONSTRAINT "PasswordResetToken_pkey" PRIMARY KEY (id);


--
-- Name: Payment Payment_pkey; Type: CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public."Payment"
    ADD CONSTRAINT "Payment_pkey" PRIMARY KEY (id);


--
-- Name: Period Period_pkey; Type: CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public."Period"
    ADD CONSTRAINT "Period_pkey" PRIMARY KEY (id);


--
-- Name: Rule Rule_pkey; Type: CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public."Rule"
    ADD CONSTRAINT "Rule_pkey" PRIMARY KEY (id);


--
-- Name: StagedTransaction StagedTransaction_pkey; Type: CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public."StagedTransaction"
    ADD CONSTRAINT "StagedTransaction_pkey" PRIMARY KEY (id);


--
-- Name: Subscription Subscription_pkey; Type: CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public."Subscription"
    ADD CONSTRAINT "Subscription_pkey" PRIMARY KEY (id);


--
-- Name: TaxCalendarEvent TaxCalendarEvent_pkey; Type: CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public."TaxCalendarEvent"
    ADD CONSTRAINT "TaxCalendarEvent_pkey" PRIMARY KEY (id);


--
-- Name: TaxDeadlineTemplate TaxDeadlineTemplate_pkey; Type: CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public."TaxDeadlineTemplate"
    ADD CONSTRAINT "TaxDeadlineTemplate_pkey" PRIMARY KEY (id);


--
-- Name: User User_pkey; Type: CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public."User"
    ADD CONSTRAINT "User_pkey" PRIMARY KEY (id);


--
-- Name: Voucher Voucher_pkey; Type: CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public."Voucher"
    ADD CONSTRAINT "Voucher_pkey" PRIMARY KEY (id);


--
-- Name: Account_code_idx; Type: INDEX; Schema: public; Owner: user
--

CREATE INDEX "Account_code_idx" ON public."Account" USING btree (code);


--
-- Name: Account_code_key; Type: INDEX; Schema: public; Owner: user
--

CREATE UNIQUE INDEX "Account_code_key" ON public."Account" USING btree (code);


--
-- Name: Account_parentId_idx; Type: INDEX; Schema: public; Owner: user
--

CREATE INDEX "Account_parentId_idx" ON public."Account" USING btree ("parentId");


--
-- Name: AuditLog_orgId_createdAt_idx; Type: INDEX; Schema: public; Owner: user
--

CREATE INDEX "AuditLog_orgId_createdAt_idx" ON public."AuditLog" USING btree ("orgId", "createdAt");


--
-- Name: BankAccount_orgId_idx; Type: INDEX; Schema: public; Owner: user
--

CREATE INDEX "BankAccount_orgId_idx" ON public."BankAccount" USING btree ("orgId");


--
-- Name: ClassificationJob_orgId_idx; Type: INDEX; Schema: public; Owner: user
--

CREATE INDEX "ClassificationJob_orgId_idx" ON public."ClassificationJob" USING btree ("orgId");


--
-- Name: ClosingJob_orgId_idx; Type: INDEX; Schema: public; Owner: user
--

CREATE INDEX "ClosingJob_orgId_idx" ON public."ClosingJob" USING btree ("orgId");


--
-- Name: ClosingJob_periodId_orgId_key; Type: INDEX; Schema: public; Owner: user
--

CREATE UNIQUE INDEX "ClosingJob_periodId_orgId_key" ON public."ClosingJob" USING btree ("periodId", "orgId");


--
-- Name: ClosingJob_status_idx; Type: INDEX; Schema: public; Owner: user
--

CREATE INDEX "ClosingJob_status_idx" ON public."ClosingJob" USING btree (status);


--
-- Name: Counterparty_orgId_idx; Type: INDEX; Schema: public; Owner: user
--

CREATE INDEX "Counterparty_orgId_idx" ON public."Counterparty" USING btree ("orgId");


--
-- Name: DocumentType_code_key; Type: INDEX; Schema: public; Owner: user
--

CREATE UNIQUE INDEX "DocumentType_code_key" ON public."DocumentType" USING btree (code);


--
-- Name: Document_orgId_date_idx; Type: INDEX; Schema: public; Owner: user
--

CREATE INDEX "Document_orgId_date_idx" ON public."Document" USING btree ("orgId", date);


--
-- Name: Document_orgId_periodId_idx; Type: INDEX; Schema: public; Owner: user
--

CREATE INDEX "Document_orgId_periodId_idx" ON public."Document" USING btree ("orgId", "periodId");


--
-- Name: Document_sourceTransactionId_key; Type: INDEX; Schema: public; Owner: user
--

CREATE UNIQUE INDEX "Document_sourceTransactionId_key" ON public."Document" USING btree ("sourceTransactionId");


--
-- Name: JournalEntry_accountId_date_idx; Type: INDEX; Schema: public; Owner: user
--

CREATE INDEX "JournalEntry_accountId_date_idx" ON public."JournalEntry" USING btree ("accountId", date);


--
-- Name: JournalEntry_counterpartyId_idx; Type: INDEX; Schema: public; Owner: user
--

CREATE INDEX "JournalEntry_counterpartyId_idx" ON public."JournalEntry" USING btree ("counterpartyId");


--
-- Name: JournalEntry_documentId_idx; Type: INDEX; Schema: public; Owner: user
--

CREATE INDEX "JournalEntry_documentId_idx" ON public."JournalEntry" USING btree ("documentId");


--
-- Name: OpenItem_orgId_affectedPeriodId_idx; Type: INDEX; Schema: public; Owner: user
--

CREATE INDEX "OpenItem_orgId_affectedPeriodId_idx" ON public."OpenItem" USING btree ("orgId", "affectedPeriodId");


--
-- Name: OpenItem_orgId_status_idx; Type: INDEX; Schema: public; Owner: user
--

CREATE INDEX "OpenItem_orgId_status_idx" ON public."OpenItem" USING btree ("orgId", status);


--
-- Name: OrgMember_userId_orgId_key; Type: INDEX; Schema: public; Owner: user
--

CREATE UNIQUE INDEX "OrgMember_userId_orgId_key" ON public."OrgMember" USING btree ("userId", "orgId");


--
-- Name: PasswordResetToken_token_idx; Type: INDEX; Schema: public; Owner: user
--

CREATE INDEX "PasswordResetToken_token_idx" ON public."PasswordResetToken" USING btree (token);


--
-- Name: PasswordResetToken_token_key; Type: INDEX; Schema: public; Owner: user
--

CREATE UNIQUE INDEX "PasswordResetToken_token_key" ON public."PasswordResetToken" USING btree (token);


--
-- Name: PasswordResetToken_userId_idx; Type: INDEX; Schema: public; Owner: user
--

CREATE INDEX "PasswordResetToken_userId_idx" ON public."PasswordResetToken" USING btree ("userId");


--
-- Name: Payment_externalId_idx; Type: INDEX; Schema: public; Owner: user
--

CREATE INDEX "Payment_externalId_idx" ON public."Payment" USING btree ("externalId");


--
-- Name: Payment_externalId_key; Type: INDEX; Schema: public; Owner: user
--

CREATE UNIQUE INDEX "Payment_externalId_key" ON public."Payment" USING btree ("externalId");


--
-- Name: Payment_orderCode_idx; Type: INDEX; Schema: public; Owner: user
--

CREATE INDEX "Payment_orderCode_idx" ON public."Payment" USING btree ("orderCode");


--
-- Name: Payment_orderCode_key; Type: INDEX; Schema: public; Owner: user
--

CREATE UNIQUE INDEX "Payment_orderCode_key" ON public."Payment" USING btree ("orderCode");


--
-- Name: Payment_orgId_idx; Type: INDEX; Schema: public; Owner: user
--

CREATE INDEX "Payment_orgId_idx" ON public."Payment" USING btree ("orgId");


--
-- Name: Period_orgId_idx; Type: INDEX; Schema: public; Owner: user
--

CREATE INDEX "Period_orgId_idx" ON public."Period" USING btree ("orgId");


--
-- Name: Period_orgId_year_month_key; Type: INDEX; Schema: public; Owner: user
--

CREATE UNIQUE INDEX "Period_orgId_year_month_key" ON public."Period" USING btree ("orgId", year, month);


--
-- Name: Rule_orgId_idx; Type: INDEX; Schema: public; Owner: user
--

CREATE INDEX "Rule_orgId_idx" ON public."Rule" USING btree ("orgId");


--
-- Name: Rule_orgId_matchType_matchValue_key; Type: INDEX; Schema: public; Owner: user
--

CREATE UNIQUE INDEX "Rule_orgId_matchType_matchValue_key" ON public."Rule" USING btree ("orgId", "matchType", "matchValue");


--
-- Name: StagedTransaction_importBatchId_idx; Type: INDEX; Schema: public; Owner: user
--

CREATE INDEX "StagedTransaction_importBatchId_idx" ON public."StagedTransaction" USING btree ("importBatchId");


--
-- Name: StagedTransaction_orgId_hash_key; Type: INDEX; Schema: public; Owner: user
--

CREATE UNIQUE INDEX "StagedTransaction_orgId_hash_key" ON public."StagedTransaction" USING btree ("orgId", hash);


--
-- Name: StagedTransaction_orgId_periodId_idx; Type: INDEX; Schema: public; Owner: user
--

CREATE INDEX "StagedTransaction_orgId_periodId_idx" ON public."StagedTransaction" USING btree ("orgId", "periodId");


--
-- Name: StagedTransaction_status_idx; Type: INDEX; Schema: public; Owner: user
--

CREATE INDEX "StagedTransaction_status_idx" ON public."StagedTransaction" USING btree (status);


--
-- Name: Subscription_orgId_key; Type: INDEX; Schema: public; Owner: user
--

CREATE UNIQUE INDEX "Subscription_orgId_key" ON public."Subscription" USING btree ("orgId");


--
-- Name: TaxCalendarEvent_orgId_dueDate_idx; Type: INDEX; Schema: public; Owner: user
--

CREATE INDEX "TaxCalendarEvent_orgId_dueDate_idx" ON public."TaxCalendarEvent" USING btree ("orgId", "dueDate");


--
-- Name: TaxDeadlineTemplate_orgId_idx; Type: INDEX; Schema: public; Owner: user
--

CREATE INDEX "TaxDeadlineTemplate_orgId_idx" ON public."TaxDeadlineTemplate" USING btree ("orgId");


--
-- Name: User_email_key; Type: INDEX; Schema: public; Owner: user
--

CREATE UNIQUE INDEX "User_email_key" ON public."User" USING btree (email);


--
-- Name: Voucher_code_key; Type: INDEX; Schema: public; Owner: user
--

CREATE UNIQUE INDEX "Voucher_code_key" ON public."Voucher" USING btree (code);


--
-- Name: Account Account_parentId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public."Account"
    ADD CONSTRAINT "Account_parentId_fkey" FOREIGN KEY ("parentId") REFERENCES public."Account"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: AuditLog AuditLog_orgId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public."AuditLog"
    ADD CONSTRAINT "AuditLog_orgId_fkey" FOREIGN KEY ("orgId") REFERENCES public."Organization"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: BankAccount BankAccount_orgId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public."BankAccount"
    ADD CONSTRAINT "BankAccount_orgId_fkey" FOREIGN KEY ("orgId") REFERENCES public."Organization"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: ClassificationJob ClassificationJob_orgId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public."ClassificationJob"
    ADD CONSTRAINT "ClassificationJob_orgId_fkey" FOREIGN KEY ("orgId") REFERENCES public."Organization"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: ClosingJob ClosingJob_orgId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public."ClosingJob"
    ADD CONSTRAINT "ClosingJob_orgId_fkey" FOREIGN KEY ("orgId") REFERENCES public."Organization"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: ClosingJob ClosingJob_periodId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public."ClosingJob"
    ADD CONSTRAINT "ClosingJob_periodId_fkey" FOREIGN KEY ("periodId") REFERENCES public."Period"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Counterparty Counterparty_orgId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public."Counterparty"
    ADD CONSTRAINT "Counterparty_orgId_fkey" FOREIGN KEY ("orgId") REFERENCES public."Organization"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Document Document_orgId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public."Document"
    ADD CONSTRAINT "Document_orgId_fkey" FOREIGN KEY ("orgId") REFERENCES public."Organization"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Document Document_periodId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public."Document"
    ADD CONSTRAINT "Document_periodId_fkey" FOREIGN KEY ("periodId") REFERENCES public."Period"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: Document Document_typeId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public."Document"
    ADD CONSTRAINT "Document_typeId_fkey" FOREIGN KEY ("typeId") REFERENCES public."DocumentType"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: JournalEntry JournalEntry_accountId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public."JournalEntry"
    ADD CONSTRAINT "JournalEntry_accountId_fkey" FOREIGN KEY ("accountId") REFERENCES public."Account"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: JournalEntry JournalEntry_counterpartyId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public."JournalEntry"
    ADD CONSTRAINT "JournalEntry_counterpartyId_fkey" FOREIGN KEY ("counterpartyId") REFERENCES public."Counterparty"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: JournalEntry JournalEntry_documentId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public."JournalEntry"
    ADD CONSTRAINT "JournalEntry_documentId_fkey" FOREIGN KEY ("documentId") REFERENCES public."Document"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: OpenItem OpenItem_accountId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public."OpenItem"
    ADD CONSTRAINT "OpenItem_accountId_fkey" FOREIGN KEY ("accountId") REFERENCES public."Account"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: OpenItem OpenItem_closingDocumentId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public."OpenItem"
    ADD CONSTRAINT "OpenItem_closingDocumentId_fkey" FOREIGN KEY ("closingDocumentId") REFERENCES public."Document"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: OpenItem OpenItem_counterpartyId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public."OpenItem"
    ADD CONSTRAINT "OpenItem_counterpartyId_fkey" FOREIGN KEY ("counterpartyId") REFERENCES public."Counterparty"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: OpenItem OpenItem_openingDocumentId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public."OpenItem"
    ADD CONSTRAINT "OpenItem_openingDocumentId_fkey" FOREIGN KEY ("openingDocumentId") REFERENCES public."Document"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: OpenItem OpenItem_orgId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public."OpenItem"
    ADD CONSTRAINT "OpenItem_orgId_fkey" FOREIGN KEY ("orgId") REFERENCES public."Organization"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: OrgMember OrgMember_orgId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public."OrgMember"
    ADD CONSTRAINT "OrgMember_orgId_fkey" FOREIGN KEY ("orgId") REFERENCES public."Organization"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: OrgMember OrgMember_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public."OrgMember"
    ADD CONSTRAINT "OrgMember_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: PasswordResetToken PasswordResetToken_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public."PasswordResetToken"
    ADD CONSTRAINT "PasswordResetToken_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Payment Payment_orgId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public."Payment"
    ADD CONSTRAINT "Payment_orgId_fkey" FOREIGN KEY ("orgId") REFERENCES public."Organization"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Period Period_orgId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public."Period"
    ADD CONSTRAINT "Period_orgId_fkey" FOREIGN KEY ("orgId") REFERENCES public."Organization"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Rule Rule_categoryId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public."Rule"
    ADD CONSTRAINT "Rule_categoryId_fkey" FOREIGN KEY ("categoryId") REFERENCES public."DocumentType"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: Rule Rule_orgId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public."Rule"
    ADD CONSTRAINT "Rule_orgId_fkey" FOREIGN KEY ("orgId") REFERENCES public."Organization"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: StagedTransaction StagedTransaction_bankAccountId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public."StagedTransaction"
    ADD CONSTRAINT "StagedTransaction_bankAccountId_fkey" FOREIGN KEY ("bankAccountId") REFERENCES public."BankAccount"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: StagedTransaction StagedTransaction_documentId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public."StagedTransaction"
    ADD CONSTRAINT "StagedTransaction_documentId_fkey" FOREIGN KEY ("documentId") REFERENCES public."Document"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: StagedTransaction StagedTransaction_periodId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public."StagedTransaction"
    ADD CONSTRAINT "StagedTransaction_periodId_fkey" FOREIGN KEY ("periodId") REFERENCES public."Period"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: Subscription Subscription_orgId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public."Subscription"
    ADD CONSTRAINT "Subscription_orgId_fkey" FOREIGN KEY ("orgId") REFERENCES public."Organization"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: TaxCalendarEvent TaxCalendarEvent_orgId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public."TaxCalendarEvent"
    ADD CONSTRAINT "TaxCalendarEvent_orgId_fkey" FOREIGN KEY ("orgId") REFERENCES public."Organization"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: TaxCalendarEvent TaxCalendarEvent_periodId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public."TaxCalendarEvent"
    ADD CONSTRAINT "TaxCalendarEvent_periodId_fkey" FOREIGN KEY ("periodId") REFERENCES public."Period"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: TaxDeadlineTemplate TaxDeadlineTemplate_orgId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public."TaxDeadlineTemplate"
    ADD CONSTRAINT "TaxDeadlineTemplate_orgId_fkey" FOREIGN KEY ("orgId") REFERENCES public."Organization"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Voucher Voucher_usedByOrgId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public."Voucher"
    ADD CONSTRAINT "Voucher_usedByOrgId_fkey" FOREIGN KEY ("usedByOrgId") REFERENCES public."Organization"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- PostgreSQL database dump complete
--

\unrestrict emc4E2QxdUg7PJSMyNpFR6h0T6hfav7zNQEuRjDRCiN4NCkHpAQ378f0xYnKsOa

